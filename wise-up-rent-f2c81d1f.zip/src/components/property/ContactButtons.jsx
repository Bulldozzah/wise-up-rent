
import React from "react";
import { Button } from "@/components/ui/button";
import { Phone, MessageSquare, Mail, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ContactButtons({ landlord, property }) {
  const owner = landlord;
  
  if (!owner) return null;

  const createMessage = () => {
    if (!property) return "";
    
    let message = `Hello, I'm interested in your listing:\n\n`;
    message += `Title: ${property.title}\n`;
    
    if (property.listing_type) {
      message += `Type: For ${property.listing_type === 'rent' ? 'Rent' : 'Sale'}\n`;
    }
    
    if (property.listing_type === 'rent' && property.rent_amount) {
      message += `Price: ${property.rent_amount.toLocaleString()}`;
      if (property.payment_frequency) message += ` / ${property.payment_frequency}`;
      message += `\n`;
    } else if (property.sale_price) {
      message += `Price: ${property.sale_price.toLocaleString()}\n`;
    }
    
    if (property.city) {
      message += `Location: ${property.city}`;
      if (property.neighborhood) message += `, ${property.neighborhood}`;
      if (property.state) message += `, ${property.state}`;
      message += `\n`;
    }
    
    if (property.bedrooms) {
      message += `Bedrooms: ${property.bedrooms}\n`;
    }
    
    if (property.brand) {
      message += `Brand: ${property.brand}\n`;
    }
    
    if (property.model) {
      message += `Model: ${property.model}\n`;
    }
    
    if (property.category) {
      message += `Category: ${property.category.replace('_', ' ')}\n`;
    }
    
    if (property.subcategory) {
      message += `Type: ${property.subcategory}\n`;
    }
    
    message += `\nPlease share more details. Thank you!`;
    
    return message;
  };

  const handleCall = () => {
    if (owner?.phone) {
      window.location.href = `tel:${owner.phone}`;
    }
  };

  const handleSMS = () => {
    if (owner?.phone) {
      const message = encodeURIComponent(createMessage());
      window.location.href = `sms:${owner.phone}${message ? `?body=${message}` : ''}`;
    }
  };

  const handleWhatsApp = () => {
    if (owner?.whatsapp) {
      const message = encodeURIComponent(createMessage());
      const cleanNumber = owner.whatsapp.replace(/[^0-9]/g, '');
      window.open(`https://wa.me/${cleanNumber}${message ? `?text=${message}` : ''}`, '_blank');
    }
  };

  const handleEmail = () => {
    if (owner?.email) {
      const subject = encodeURIComponent(`Inquiry about: ${property.title}`);
      const body = encodeURIComponent(createMessage());
      window.location.href = `mailto:${owner.email}?subject=${subject}&body=${body}`;
    }
  };

  const hasPhone = owner?.phone;
  const hasWhatsApp = owner?.whatsapp;
  const hasEmail = owner?.email;

  if (!hasPhone && !hasWhatsApp && !hasEmail) {
    return (
      <Alert className="border-orange-200 bg-orange-50">
        <AlertCircle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-900 text-sm">
          Owner has not provided contact information yet. Please check back later or contact support.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-3">
      {hasPhone && (
        <>
          <Button
            className="w-full bg-indigo-600 hover:bg-indigo-700 gap-2 text-base py-6"
            onClick={handleCall}
          >
            <Phone className="w-5 h-5" />
            Call Owner
          </Button>
          <Button
            variant="outline"
            className="w-full gap-2 text-base py-6 border-2"
            onClick={handleSMS}
          >
            <MessageSquare className="w-5 h-5" />
            Send SMS
          </Button>
        </>
      )}
      {hasWhatsApp && (
        <Button
          className="w-full bg-green-600 hover:bg-green-700 gap-2 text-base py-6"
          onClick={handleWhatsApp}
        >
          <MessageSquare className="w-5 h-5" />
          WhatsApp
        </Button>
      )}
      {hasEmail && (
        <Button
          variant="outline"
          className="w-full border-slate-300 hover:bg-slate-50 gap-2 text-base py-6 border-2"
          onClick={handleEmail}
        >
          <Mail className="w-5 h-5" />
          Send Email
        </Button>
      )}
    </div>
  );
}
