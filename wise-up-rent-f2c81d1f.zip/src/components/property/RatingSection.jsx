import React, { useState } from "react";
import { Rating } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Star } from "lucide-react";
import { format } from "date-fns";

export default function RatingSection({ property, landlord, currentUser, ratings, onRatingSubmitted }) {
  const [showRatingForm, setShowRatingForm] = useState(false);
  const [ratingValue, setRatingValue] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmitRating = async () => {
    if (!currentUser || ratingValue === 0) return;

    setSubmitting(true);
    
    await Rating.create({
      rater_id: currentUser.id,
      rater_name: currentUser.full_name,
      rated_user_id: landlord.id,
      rated_user_name: landlord.full_name,
      rating: ratingValue,
      comment,
      property_id: property.id
    });

    const allRatings = await Rating.filter({ rated_user_id: landlord.id });
    const avgRating = allRatings.reduce((sum, r) => sum + r.rating, 0) / allRatings.length;

    await User.update(landlord.id, {
      rating_average: avgRating,
      rating_count: allRatings.length
    });

    setShowRatingForm(false);
    setRatingValue(0);
    setComment("");
    setSubmitting(false);
    onRatingSubmitted();
  };

  return (
    <>
      <div>
        <h3 className="font-semibold mb-3">Vendor Reviews</h3>
        
        {currentUser && landlord && currentUser.id !== landlord.id && (
          <Button
            variant="outline"
            className="w-full mb-4"
            onClick={() => setShowRatingForm(!showRatingForm)}
          >
            <Star className="w-4 h-4 mr-2" />
            Write a Review
          </Button>
        )}

        {showRatingForm && (
          <div className="mb-4 p-4 border rounded-lg space-y-3">
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRatingValue(star)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-6 h-6 ${
                      star <= ratingValue
                        ? "text-yellow-500 fill-yellow-500"
                        : "text-gray-300"
                    }`}
                  />
                </button>
              ))}
            </div>
            <Textarea
              placeholder="Share your experience..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="min-h-20"
            />
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={handleSubmitRating}
                disabled={submitting || ratingValue === 0}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                Submit
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setShowRatingForm(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-3 max-h-64 overflow-y-auto">
          {ratings.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-4">No reviews yet</p>
          ) : (
            ratings.map((rating) => (
              <div key={rating.id} className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-sm">{rating.rater_name}</span>
                  <div className="flex gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < rating.rating
                            ? "text-yellow-500 fill-yellow-500"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                </div>
                {rating.comment && (
                  <p className="text-sm text-slate-600">{rating.comment}</p>
                )}
                <p className="text-xs text-slate-400 mt-1">
                  {format(new Date(rating.created_date), "MMM d, yyyy")}
                </p>
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
}