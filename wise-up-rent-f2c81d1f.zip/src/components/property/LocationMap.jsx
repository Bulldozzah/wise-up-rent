
import React, { useState, useEffect, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, useMap } from "react-leaflet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation, Loader2 } from "lucide-react";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Fix for default marker icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

function LocationMarker({ position, setPosition, editable }) {
  useMapEvents({
    click(e) {
      if (editable && setPosition) {
        setPosition([e.latlng.lat, e.latlng.lng]);
      }
    },
  });

  return position ? (
    <Marker position={position}>
      <Popup>
        {editable ? "Click on map to change location" : "Property location"}
      </Popup>
    </Marker>
  ) : null;
}

// Helper component to invalidate Leaflet map size when its container becomes visible (e.g., in a modal)
function MapInvalidateSize() {
  const map = useMap();
  useEffect(() => {
    // A small delay ensures the dialog animation has completed and
    // the map container is fully visible before invalidating size.
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 200);
    return () => clearTimeout(timer);
  }, [map]);
  return null;
}

export default function LocationMap({ 
  latitude, 
  longitude,
  country,
  state,
  city,
  neighborhood,
  address,
  onLocationChange, 
  onAddressFound,
  editable = true 
}) {
  const [position, setPosition] = useState(
    latitude && longitude ? [latitude, longitude] : null
  );
  const [loading, setLoading] = useState(false);
  // autoGeocodingDone is retained to reset when lat/lon props change,
  // even though auto-geocoding itself has been removed.
  // It now implicitly means 'manual geocoding done'.
  const [autoGeocodingDone, setAutoGeocodingDone] = useState(false);

  // Update map position when latitude/longitude props change
  useEffect(() => {
    if (latitude && longitude) {
      setPosition([latitude, longitude]);
    } else {
      // If lat/lon props are cleared, reset map position and auto-geocoding status
      setPosition(null);
      setAutoGeocodingDone(false);
    }
  }, [latitude, longitude]);

  const reverseGeocode = async (lat, lon) => {
    if (!onAddressFound || !editable) return;

    try {
      // Add a small delay to avoid hitting API rate limits
      await new Promise(resolve => setTimeout(resolve, 1000));
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}`,
        {
          headers: {
            'Accept': 'application/json',
          }
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();

      if (data && data.address) {
        onAddressFound({
          country: data.address.country || "",
          state: data.address.state || "",
          city: data.address.city || data.address.town || data.address.village || "",
          neighborhood: data.address.suburb || data.address.neighbourhood || data.address.quarter || ""
        });
      }
    } catch (error) {
      console.error("Reverse geocoding error:", error);
      // Fail silently, as this is an enhancement, not critical functionality
    }
  };

  // Callback to handle position changes from map interaction or geocoding
  const handlePositionChange = useCallback((newPosition) => {
    setPosition(newPosition);
    if (onLocationChange && editable) { // Only call onLocationChange if the map is in editable mode
      onLocationChange(newPosition[0], newPosition[1]);

      // Trigger reverse geocoding to auto-fill address fields
      if (onAddressFound) {
        reverseGeocode(newPosition[0], newPosition[1]);
      }
    }
  }, [onLocationChange, onAddressFound, editable]);

  // Removed automatic geocoding on mount/field changes to avoid fetch errors.
  // Users must click "Find Location" button manually.

  // Function to manually trigger geocoding
  const geocodeLocation = async () => {
    let searchQuery = "";
    const locationParts = [address, neighborhood, city, state, country].filter(Boolean).map(s => s.trim());
    if (locationParts.length > 0) {
      searchQuery = locationParts.join(', ');
    }

    if (!searchQuery) {
      alert("Please enter location details first");
      return;
    }

    setLoading(true);
    try {
      // Add a small delay to respect API rate limits and avoid hitting them too quickly
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`,
        {
          headers: {
            'Accept': 'application/json', // Ensure JSON response is requested
          }
        }
      );
      
      if (!response.ok) {
        // Handle non-2xx HTTP responses
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }
      
      const data = await response.json();
      
      if (data && data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lon = parseFloat(data[0].lon);
        handlePositionChange([lat, lon]);
        setAutoGeocodingDone(true); // Mark as done after manual geocode too
      } else {
        alert("Location not found. Please try a different search or click on the map.");
      }
    } catch (error) {
      console.error("Geocoding error:", error);
      alert("Error finding location. Please check your internet connection, try again, or click on the map manually.");
    } finally {
      setLoading(false);
    }
  };

  const defaultCenter = [-6.7924, 39.2083]; // Dar es Salaam, Tanzania

  // If not in editable mode, render a button that opens the map in a modal
  if (!editable) {
    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-2">
            <MapPin className="w-4 h-4" /> View Map
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[800px] h-[calc(100vh-100px)] flex flex-col p-6">
          <DialogHeader>
            <DialogTitle>Property Location</DialogTitle>
          </DialogHeader>
          <div className="flex-grow rounded-lg overflow-hidden border-2 border-slate-200 mt-4">
            <MapContainer
              center={position || defaultCenter}
              zoom={position ? 13 : 7}
              style={{ height: "100%", width: "100%" }}
              key={position ? `${position[0]}-${position[1]}` : "default-modal"}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <LocationMarker 
                position={position} 
                // setPosition is not needed in view-only mode as map is not editable
                editable={false} // Ensure marker is not editable
              />
              <MapInvalidateSize /> {/* Invalidate size when modal opens */}
            </MapContainer>
          </div>
          {position && (
            <div className="mt-3 text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
              <p><strong>Coordinates:</strong> {position[0].toFixed(6)}, {position[1].toFixed(6)}</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    );
  }

  // Default rendering for editable mode
  return (
    <Card className="border-0 shadow-xl">
      <CardHeader>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Property Location on Map
          </CardTitle>
          {editable && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={geocodeLocation}
              disabled={loading}
              className="gap-2 whitespace-nowrap"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Navigation className="w-4 h-4" />
              )}
              {loading ? "Finding..." : "Find Location"}
            </Button>
          )}
        </div>
        {editable && (
          <p className="text-sm text-slate-600 mt-2">
            Click "Find Location" to search, or click directly on the map to set the exact location.
          </p>
        )}
      </CardHeader>
      <CardContent>
        <div className="rounded-lg overflow-hidden border-2 border-slate-200" style={{ height: "400px" }}>
          <MapContainer
            center={position || defaultCenter}
            zoom={position ? 13 : 7}
            style={{ height: "100%", width: "100%" }}
            key={position ? `${position[0]}-${position[1]}` : "default"}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <LocationMarker 
              position={position} 
              setPosition={handlePositionChange} 
              editable={editable}
            />
          </MapContainer>
        </div>
        {position && (
          <div className="mt-3 text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
            <p><strong>Coordinates:</strong> {position[0].toFixed(6)}, {position[1].toFixed(6)}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
