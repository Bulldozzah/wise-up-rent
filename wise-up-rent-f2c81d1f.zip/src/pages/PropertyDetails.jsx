
import React, { useState, useEffect, useCallback } from "react";
import { Property } from "@/api/entities";
import { User } from "@/api/entities";
import { Rating } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Building2,
  MapPin,
  Bed,
  DollarSign,
  Phone,
  MessageSquare,
  Star,
  Check,
  X,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import ContactButtons from "../components/property/ContactButtons";
import RatingSection from "../components/property/RatingSection";

export default function PropertyDetails() {
  const navigate = useNavigate();
  const [property, setProperty] = useState(null);
  const [landlord, setLandlord] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [ratings, setRatings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const loadData = useCallback(async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const propertyId = urlParams.get("id");

    if (!propertyId) {
      navigate(createPageUrl("PropertySearch"));
      return;
    }

    const propertyData = await Property.get(propertyId);
    setProperty(propertyData);

    await Property.update(propertyId, {
      views: (propertyData.views || 0) + 1
    });

    const landlordData = await User.get(propertyData.landlord_id);
    setLandlord(landlordData);

    const landlordRatings = await Rating.filter({ rated_user_id: propertyData.landlord_id });
    setRatings(landlordRatings);

    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      setCurrentUser(null);
    }

    setLoading(false);
  }, [navigate]); // Added navigate as a dependency

  useEffect(() => {
    loadData();
  }, [loadData]); // Added loadData as a dependency

  const nextImage = () => {
    if (property.images) {
      setCurrentImageIndex((prev) => (prev + 1) % property.images.length);
    }
  };

  const prevImage = () => {
    if (property.images) {
      setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card>
          <CardContent className="pt-6">
            <p>Property not found</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="pb-12">
      <div className="relative h-96 bg-slate-900">
        {property.images && property.images.length > 0 ? (
          <>
            <img
              src={property.images[currentImageIndex]}
              alt={property.title}
              className="w-full h-full object-cover opacity-90"
            />
            {property.images.length > 1 && (
              <>
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                  onClick={prevImage}
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                  onClick={nextImage}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {property.images.map((_, index) => (
                    <div
                      key={index}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentImageIndex ? "bg-white w-8" : "bg-white/50"
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Building2 className="w-24 h-24 text-slate-400" />
          </div>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-8 -mt-20 relative z-10">
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-0 shadow-2xl">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-3xl mb-2">{property.title}</CardTitle>
                    <div className="flex items-center gap-2 text-slate-600">
                      <MapPin className="w-5 h-5" />
                      <span>{property.address}, {property.city}</span>
                    </div>
                  </div>
                  <Badge className="bg-green-500 text-lg px-4 py-2">
                    {property.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-6 h-6 text-indigo-600" />
                  <span className="text-4xl font-bold text-indigo-600">{property.rent_amount}</span>
                  <span className="text-xl text-slate-500">/ {property.payment_frequency}</span>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-3">Description</h3>
                  <p className="text-slate-600">{property.description}</p>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-4">Property Details</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3">
                      <Bed className="w-5 h-5 text-indigo-600" />
                      <span><strong>{property.bedrooms}</strong> Bedrooms</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-5 h-5 text-indigo-600" />
                      <span><strong>${property.security_deposit}</strong> Security Deposit</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-4">Additional Rooms</h3>
                  <div className="grid md:grid-cols-2 gap-3">
                    {property.has_kitchen && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Kitchen</span>
                      </div>
                    )}
                    {property.has_dining && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Dining Room</span>
                      </div>
                    )}
                    {property.has_study && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Study Room</span>
                      </div>
                    )}
                    {property.has_garage && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Garage</span>
                      </div>
                    )}
                    {property.has_garden && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Garden</span>
                      </div>
                    )}
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-4">Utilities Included</h3>
                  <div className="grid md:grid-cols-3 gap-3">
                    <div className="flex items-center gap-2">
                      {property.water_included ? (
                        <Check className="w-4 h-4 text-green-600" />
                      ) : (
                        <X className="w-4 h-4 text-red-500" />
                      )}
                      <span>Water Bill</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {property.electricity_included ? (
                        <Check className="w-4 h-4 text-green-600" />
                      ) : (
                        <X className="w-4 h-4 text-red-500" />
                      )}
                      <span>Electricity Bill</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {property.garbage_included ? (
                        <Check className="w-4 h-4 text-green-600" />
                      ) : (
                        <X className="w-4 h-4 text-red-500" />
                      )}
                      <span>Garbage Collection</span>
                    </div>
                  </div>
                </div>

                {property.is_fenced && (
                  <>
                    <Separator />
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Security</h3>
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Fenced ({property.fence_type} fence)</span>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-0 shadow-2xl sticky top-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="w-5 h-5" />
                  Landlord
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      {landlord?.full_name?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-semibold text-lg">{landlord?.full_name}</p>
                    {landlord?.rating_average > 0 && (
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span className="text-sm">{landlord.rating_average.toFixed(1)}</span>
                        <span className="text-xs text-slate-500">({landlord.rating_count} reviews)</span>
                      </div>
                    )}
                  </div>
                </div>

                <ContactButtons landlord={landlord} />

                <RatingSection
                  property={property}
                  landlord={landlord}
                  currentUser={currentUser}
                  ratings={ratings}
                  onRatingSubmitted={loadData}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
