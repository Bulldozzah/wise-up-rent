
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Property } from "@/api/entities";
import { Listing } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Building2, Eye, MapPin, Plus, Trash2, Car, Music, Laptop, Shirt, Wrench, Camera, Bed, Pencil } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const categoryIcons = {
  transport_vehicles: Car,
  events_entertainment: Music,
  home_office_equipment: Laptop,
  personal_lifestyle: Shirt,
  construction_tools: Wrench,
  media_technology: Camera
};

export default function MyListings() {
  const [user, setUser] = useState(null);
  const [properties, setProperties] = useState([]);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(null);
  const [updatingStatus, setUpdatingStatus] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const currentUser = await User.me();
    setUser(currentUser);

    // If vendor, load their own listings. If admin, load all.
    if (currentUser.account_type === "admin") {
      const allProperties = await Property.list("-created_date");
      const allItems = await Listing.list("-created_date");
      setProperties(allProperties);
      setItems(allItems);
    } else if (currentUser.account_type === "vendor") {
      const myProperties = await Property.filter({ vendor_id: currentUser.id }, "-created_date");
      const myItems = await Listing.filter({ owner_id: currentUser.id }, "-created_date");
      setProperties(myProperties);
      setItems(myItems);
    } else {
      // Tenant - show all available
      const allProperties = await Property.filter({ status: "available" }, "-created_date");
      const allItems = await Listing.filter({ status: "available" }, "-created_date");
      setProperties(allProperties);
      setItems(allItems);
    }

    setLoading(false);
  };

  const handleDeleteProperty = async (propertyId) => {
    if (!confirm("Are you sure you want to delete this property? This action cannot be undone.")) {
      return;
    }

    setDeleting(propertyId);
    try {
      await Property.delete(propertyId);
      await loadData();
    } catch (error) {
      console.error("Error deleting property:", error);
      alert("Error deleting property. Please try again.");
    }
    setDeleting(null);
  };

  const handleDeleteItem = async (itemId) => {
    if (!confirm("Are you sure you want to delete this item? This action cannot be undone.")) {
      return;
    }

    setDeleting(itemId);
    try {
      await Listing.delete(itemId);
      await loadData();
    } catch (error) {
      console.error("Error deleting item:", error);
      alert("Error deleting item. Please try again.");
    }
    setDeleting(null);
  };

  const handleStatusChange = async (id, newStatus, type) => {
    if (!confirm(`Are you sure you want to mark this ${type} as "${newStatus}"?`)) {
      return;
    }

    setUpdatingStatus(id);
    try {
      if (type === "property") {
        await Property.update(id, { status: newStatus });
      } else {
        await Listing.update(id, { status: newStatus });
      }
      await loadData();
    } catch (error) {
      console.error(`Error updating ${type} status:`, error);
      alert(`Error updating status. Please try again.`);
    }
    setUpdatingStatus(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const isVendor = user.account_type === "vendor";
  const isAdmin = user.account_type === "admin";
  const userCurrency = user?.currency || "TZS";

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            {isVendor ? "My Listings" : isAdmin ? "All Listings" : "Browse Listings"}
          </h1>
          <p className="text-slate-600">
            {isVendor ? "Manage your properties and items" : isAdmin ? "All platform listings" : "All available properties and items"}
          </p>
        </div>
        {isVendor && (
          <div className="flex gap-3">
            <Link to={createPageUrl("AddProperty")}>
              <Button className="bg-indigo-600 hover:bg-indigo-700 gap-2 shadow-lg">
                <Plus className="w-5 h-5" />
                Add Property
              </Button>
            </Link>
            <Link to={createPageUrl("AddItem")}>
              <Button className="bg-purple-600 hover:bg-purple-700 gap-2 shadow-lg">
                <Plus className="w-5 h-5" />
                Add Item
              </Button>
            </Link>
          </div>
        )}
      </div>

      <Tabs defaultValue="properties" className="space-y-6">
        <TabsList className="bg-white border border-slate-200">
          <TabsTrigger value="properties" className="gap-2">
            <Building2 className="w-4 h-4" />
            Properties ({properties.length})
          </TabsTrigger>
          <TabsTrigger value="items" className="gap-2">
            <Car className="w-4 h-4" />
            Items ({items.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="properties">
          {properties.length === 0 ? (
            <Card className="border-0 shadow-xl">
              <CardContent className="text-center py-16">
                <Building2 className="w-20 h-20 mx-auto mb-4 text-slate-300" />
                <h3 className="text-2xl font-semibold text-slate-900 mb-2">
                  {isVendor ? "No Properties Yet" : "No Properties Available"}
                </h3>
                <p className="text-slate-600 mb-6">
                  {isVendor ? "Start earning by listing your first property" : "Check back soon for new listings!"}
                </p>
                {isVendor && (
                  <Link to={createPageUrl("AddProperty")}>
                    <Button className="bg-indigo-600 hover:bg-indigo-700 gap-2">
                      <Plus className="w-5 h-5" />
                      Add Property
                    </Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.map((property) => (
                <Card key={property.id} className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
                  <Link to={createPageUrl(`Property?id=${property.id}`)}>
                    <div className="relative h-56 bg-slate-200">
                      {property.images?.[0] ? (
                        <img src={property.images[0]} alt={property.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Building2 className="w-16 h-16 text-slate-400" />
                        </div>
                      )}
                      <div className="absolute top-3 left-3 flex gap-2">
                        <Badge className={property.listing_type === "rent" ? "bg-indigo-600" : "bg-purple-600"}>
                          {property.listing_type === "rent" ? "For Rent" : "For Sale"}
                        </Badge>
                      </div>
                      <Badge className={`absolute top-3 right-3 ${
                        property.status === "available" ? "bg-green-500" :
                        property.status === "rented" ? "bg-blue-500" :
                        property.status === "sold" ? "bg-gray-500" :
                        property.status === "maintenance" ? "bg-orange-500" : "bg-slate-500"
                      }`}>
                        {property.status}
                      </Badge>
                    </div>
                  </Link>

                  <CardContent className="p-6">
                    <Link to={createPageUrl(`Property?id=${property.id}`)}>
                      <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-2 min-h-[3.5rem] hover:text-indigo-600">
                        {property.title}
                      </h3>
                    </Link>

                    {isAdmin && (
                      <div className="mb-3 pb-3 border-b text-sm">
                        <span className="text-slate-600">Owner:</span> <span className="font-semibold">{property.vendor_name}</span>
                      </div>
                    )}

                    <div className="flex items-center gap-2 text-slate-600 mb-3">
                      <MapPin className="w-4 h-4 flex-shrink-0" />
                      <span className="text-sm line-clamp-1">
                        {property.neighborhood && `${property.neighborhood}, `}
                        {property.city}
                      </span>
                    </div>

                    {property.bedrooms && (
                      <div className="flex items-center gap-2 text-slate-600 mb-3">
                        <Bed className="w-4 h-4" />
                        <span className="text-sm">{property.bedrooms} Bedrooms</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-4 border-t">
                      <div>
                        <span className="font-bold text-xl text-indigo-600">
                          {userCurrency} {property.listing_type === "rent"
                            ? property.rent_amount?.toLocaleString()
                            : property.sale_price?.toLocaleString()
                          }
                        </span>
                        {property.listing_type === "rent" && (
                          <span className="text-sm text-slate-500 ml-1">/mo</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-slate-500">
                        <Eye className="w-4 h-4" />
                        <span className="text-sm">{property.views || 0}</span>
                      </div>
                    </div>

                    {(isVendor || isAdmin) && (
                      <div className="space-y-2 mt-4 pt-4 border-t">
                        <Select
                          value={property.status}
                          onValueChange={(value) => handleStatusChange(property.id, value, "property")}
                          disabled={updatingStatus === property.id}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="available">Available</SelectItem>
                            <SelectItem value="rented">Rented</SelectItem>
                            <SelectItem value="sold">Sold</SelectItem>
                            <SelectItem value="maintenance">Maintenance</SelectItem>
                          </SelectContent>
                        </Select>

                        <div className="flex gap-2">
                          <Link to={createPageUrl(`AddProperty?id=${property.id}`)} className="flex-1">
                            <Button variant="outline" size="sm" className="w-full gap-2">
                              <Pencil className="w-4 h-4" />
                              Edit
                            </Button>
                          </Link>
                          <Link to={createPageUrl(`Property?id=${property.id}`)}>
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                          </Link>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-red-600 border-red-300 hover:bg-red-50"
                                disabled={deleting === property.id}
                              >
                                {deleting === property.id ? (
                                  <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
                                ) : (
                                  <Trash2 className="w-4 h-4" />
                                )}
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Property?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete "{property.title}". This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteProperty(property.id)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="items">
          {items.length === 0 ? (
            <Card className="border-0 shadow-xl">
              <CardContent className="text-center py-16">
                <Car className="w-20 h-20 mx-auto mb-4 text-slate-300" />
                <h3 className="text-2xl font-semibold text-slate-900 mb-2">
                  {isVendor ? "No Items Yet" : "No Items Available"}
                </h3>
                <p className="text-slate-600 mb-6">
                  {isVendor ? "Start earning by listing your first item" : "Check back soon for new listings!"}
                </p>
                {isVendor && (
                  <Link to={createPageUrl("AddItem")}>
                    <Button className="bg-purple-600 hover:bg-purple-700 gap-2">
                      <Plus className="w-5 h-5" />
                      Add Item
                    </Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {items.map((item) => {
                const CategoryIcon = categoryIcons[item.category] || Car;
                return (
                  <Card key={item.id} className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
                    <Link to={createPageUrl(`Listing?id=${item.id}`)}>
                      <div className="relative h-56 bg-slate-200">
                        {item.images?.[0] ? (
                          <img src={item.images[0]} alt={item.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <CategoryIcon className="w-16 h-16 text-slate-400" />
                          </div>
                        )}
                        <div className="absolute top-3 left-3 flex gap-2">
                          <Badge className={item.listing_type === "rent" ? "bg-indigo-600" : "bg-purple-600"}>
                            {item.listing_type === "rent" ? "For Rent" : "For Sale"}
                          </Badge>
                          {item.condition && (
                            <Badge variant="secondary" className="capitalize">
                              {item.condition.replace('_', ' ')}
                            </Badge>
                          )}
                        </div>
                        <Badge className={`absolute top-3 right-3 ${
                          item.status === "available" ? "bg-green-500" :
                          item.status === "rented" ? "bg-blue-500" :
                          item.status === "sold" ? "bg-gray-500" :
                          item.status === "reserved" ? "bg-yellow-500" :
                          item.status === "maintenance" ? "bg-orange-500" : "bg-slate-500"
                        }`}>
                          {item.status}
                        </Badge>
                      </div>
                    </Link>

                    <CardContent className="p-6">
                      <div className="flex items-center gap-2 mb-2">
                        <CategoryIcon className="w-4 h-4 text-indigo-600" />
                        <span className="text-xs text-slate-600 capitalize">
                          {item.category?.replace('_', ' ')}
                        </span>
                      </div>

                      <Link to={createPageUrl(`Listing?id=${item.id}`)}>
                        <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-2 min-h-[3.5rem] hover:text-indigo-600">
                          {item.title}
                        </h3>
                      </Link>

                      {isAdmin && (
                        <div className="mb-3 pb-3 border-b text-sm">
                          <span className="text-slate-600">Owner:</span> <span className="font-semibold">{item.owner_name}</span>
                        </div>
                      )}

                      <div className="flex items-center gap-2 text-slate-600 mb-3">
                        <MapPin className="w-4 h-4 flex-shrink-0" />
                        <span className="text-sm line-clamp-1">{item.city}</span>
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t">
                        <div>
                          <span className="font-bold text-xl text-indigo-600">
                            {userCurrency} {item.listing_type === "rent"
                              ? item.rent_amount?.toLocaleString()
                              : item.sale_price?.toLocaleString()
                            }
                          </span>
                          {item.listing_type === "rent" && item.payment_frequency && (
                            <span className="text-sm text-slate-500 ml-1">
                              /{item.payment_frequency}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1 text-slate-500">
                          <Eye className="w-4 h-4" />
                          <span className="text-sm">{item.views || 0}</span>
                        </div>
                      </div>

                      {(isVendor || isAdmin) && (
                        <div className="space-y-2 mt-4 pt-4 border-t">
                          <Select
                            value={item.status}
                            onValueChange={(value) => handleStatusChange(item.id, value, "item")}
                            disabled={updatingStatus === item.id}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="available">Available</SelectItem>
                              <SelectItem value="rented">Rented</SelectItem>
                              <SelectItem value="sold">Sold</SelectItem>
                              <SelectItem value="reserved">Reserved</SelectItem>
                              <SelectItem value="maintenance">Maintenance</SelectItem>
                            </SelectContent>
                          </Select>

                          <div className="flex gap-2">
                            <Link to={createPageUrl(`AddItem?id=${item.id}`)} className="flex-1">
                              <Button variant="outline" size="sm" className="w-full gap-2">
                                <Pencil className="w-4 h-4" />
                                Edit
                              </Button>
                            </Link>
                            <Link to={createPageUrl(`Listing?id=${item.id}`)}>
                              <Button variant="outline" size="sm">
                                View
                              </Button>
                            </Link>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-red-600 border-red-300 hover:bg-red-50"
                                  disabled={deleting === item.id}
                                >
                                  {deleting === item.id ? (
                                    <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
                                  ) : (
                                    <Trash2 className="w-4 h-4" />
                                  )}
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete Item?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This will permanently delete "{item.title}". This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleDeleteItem(item.id)}
                                    className="bg-red-600 hover:bg-red-700"
                                  >
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
