
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Property } from "@/api/entities";
import { Rating } from "@/api/entities";
import { VendorRequest } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Users as UsersIcon,
  Search,
  Shield,
  Building2,
  UserCircle,
  Mail,
  Phone,
  Calendar,
  Star,
  CheckCircle,
  AlertCircle,
  Eye,
  Edit2
} from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function Users() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [accountTypeFilter, setAccountTypeFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(null);
  const [success, setSuccess] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [userProperties, setUserProperties] = useState({});
  const [pendingVendorRequests, setPendingVendorRequests] = useState(0);
  const [editingSubscription, setEditingSubscription] = useState(null);
  const [subscriptionForm, setSubscriptionForm] = useState({
    subscription_status: "none",
    subscription_end_date: "",
    trial_used: false
  });
  const [stats, setStats] = useState({
    total: 0,
    tenants: 0,
    vendors: 0,
    admins: 0
  });

  const loadData = useCallback(async () => {
    const user = await User.me();
    setCurrentUser(user);

    if (user.account_type !== "admin") {
      navigate(createPageUrl("Dashboard"));
      return;
    }

    const [allUsers, allProperties, vendorRequests] = await Promise.all([
      User.list("-created_date"),
      Property.list(),
      VendorRequest.filter({ status: "pending" })
    ]);

    // Count properties per user
    const propertyCounts = {};
    allProperties.forEach(prop => {
      propertyCounts[prop.vendor_id] = (propertyCounts[prop.vendor_id] || 0) + 1;
    });
    setUserProperties(propertyCounts);
    setPendingVendorRequests(vendorRequests.length);

    setUsers(allUsers);
    setFilteredUsers(allUsers);

    setStats({
      total: allUsers.length,
      tenants: allUsers.filter(u => u.account_type === "tenant").length,
      vendors: allUsers.filter(u => u.account_type === "vendor").length,
      admins: allUsers.filter(u => u.account_type === "admin").length
    });

    setLoading(false);
  }, [navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    let filtered = users;

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(user =>
        user.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by account type
    if (accountTypeFilter !== "all") {
      filtered = filtered.filter(user => user.account_type === accountTypeFilter);
    }

    setFilteredUsers(filtered);
  }, [searchQuery, accountTypeFilter, users]);

  const handleAccountTypeChange = async (userId, newType) => {
    if (userId === currentUser.id && newType !== "admin") {
      alert("You cannot change your own admin status!");
      return;
    }

    setUpdating(userId);

    try {
      await User.update(userId, { account_type: newType });
      setSuccess(`User account type updated to ${newType}`);
      setTimeout(() => setSuccess(""), 3000);
      await loadData();
    } catch (error) {
      console.error("Error updating user:", error);
    }

    setUpdating(null);
  };

  const handleSubscriptionEdit = (user) => {
    setEditingSubscription(user);
    setSubscriptionForm({
      subscription_status: user.subscription_status || "none",
      subscription_end_date: user.subscription_end_date ? format(new Date(user.subscription_end_date), "yyyy-MM-dd") : "",
      trial_used: user.trial_used || false
    });
  };

  const handleSubscriptionUpdate = async (e) => {
    e.preventDefault();
    if (!editingSubscription) return;

    setUpdating(editingSubscription.id);

    try {
      const updateData = {
        subscription_status: subscriptionForm.subscription_status,
        trial_used: subscriptionForm.trial_used
      };

      if (subscriptionForm.subscription_end_date) {
        // Ensure date is parsed correctly, even if it's already a date string
        const date = new Date(subscriptionForm.subscription_end_date);
        if (!isNaN(date.getTime())) { // Check if date is valid
            updateData.subscription_end_date = date.toISOString();
        } else {
            updateData.subscription_end_date = null; // Or handle as an error
        }
      } else {
        updateData.subscription_end_date = null; // Clear if empty
      }


      await User.update(editingSubscription.id, updateData);

      setSuccess("Subscription details updated successfully");
      setTimeout(() => setSuccess(""), 3000);
      setEditingSubscription(null);
      await loadData();
    } catch (error) {
      console.error("Error updating subscription:", error);
      alert("Error updating subscription. Please try again.");
    }

    setUpdating(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  return (
    <>
      <div className="p-6 md:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2 flex items-center gap-3">
            <Shield className="w-8 h-8 text-indigo-600" />
            User Management
          </h1>
          <p className="text-slate-600">Manage user accounts and permissions</p>
        </div>

        {/* Pending Vendor Requests Alert */}
        {pendingVendorRequests > 0 && (
          <Alert className="mb-6 border-orange-200 bg-orange-50">
            <AlertCircle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-900 flex items-center justify-between">
              <span>
                <strong>{pendingVendorRequests}</strong> {pendingVendorRequests === 1 ? 'user is' : 'users are'} requesting to become {pendingVendorRequests === 1 ? 'a vendor' : 'vendors'}
              </span>
              <Link to={createPageUrl("AdminPanel")}>
                <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                  Review Requests
                </Button>
              </Link>
            </AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-900">{success}</AlertDescription>
          </Alert>
        )}

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-blue-100 text-sm mb-1">Total Users</p>
                  <p className="text-4xl font-bold">{stats.total}</p>
                </div>
                <UsersIcon className="w-8 h-8 opacity-80" />
            </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-green-100 text-sm mb-1">Tenants</p>
                  <p className="text-4xl font-bold">{stats.tenants}</p>
                </div>
                <UserCircle className="w-8 h-8 opacity-80" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-orange-100 text-sm mb-1">Vendors</p>
                  <p className="text-4xl font-bold">{stats.vendors}</p>
                </div>
                <Building2 className="w-8 h-8 opacity-80" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-indigo-100 text-sm mb-1">Admins</p>
                  <p className="text-4xl font-bold">{stats.admins}</p>
                </div>
                <Shield className="w-8 h-8 opacity-80" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="border-0 shadow-xl mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="Search by name or email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={accountTypeFilter} onValueChange={setAccountTypeFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Users</SelectItem>
                  <SelectItem value="tenant">Tenants</SelectItem>
                  <SelectItem value="vendor">Vendors</SelectItem>
                  <SelectItem value="admin">Admins</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>
              All Users ({filteredUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredUsers.length === 0 ? (
              <div className="text-center py-12">
                <UsersIcon className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No Users Found</h3>
                <p className="text-slate-600">Try adjusting your search filters</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredUsers.map((user) => (
                  <Card key={user.id} className="border shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-white font-bold text-xl">
                              {user.full_name?.charAt(0).toUpperCase()}
                            </span>
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="font-bold text-lg text-slate-900">{user.full_name}</h3>
                              <Badge className={
                                user.account_type === "admin" ? "bg-indigo-600" :
                                user.account_type === "vendor" ? "bg-orange-600" :
                                "bg-green-600"
                              }>
                                {user.account_type}
                              </Badge>
                              {user.id === currentUser.id && (
                                <Badge variant="outline" className="text-xs">You</Badge>
                              )}
                            </div>

                            <div className="grid md:grid-cols-2 gap-2 text-sm text-slate-600">
                              <div className="flex items-center gap-2">
                                <Mail className="w-4 h-4" />
                                <span className="truncate">{user.email}</span>
                              </div>
                              {user.phone && (
                                <div className="flex items-center gap-2">
                                  <Phone className="w-4 h-4" />
                                  <span>{user.phone}</span>
                                </div>
                              )}
                              <div className="flex items-center gap-2">
                                <Calendar className="w-4 h-4" />
                                <span>Joined {format(new Date(user.created_date), "MMM d, yyyy")}</span>
                              </div>
                              {user.account_type === "vendor" && (
                                <div className="flex items-center gap-2">
                                  <Building2 className="w-4 h-4" />
                                  <span>{userProperties[user.id] || 0} Properties</span>
                                </div>
                              )}
                              {user.rating_average > 0 && (
                                <div className="flex items-center gap-2">
                                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                                  <span>{user.rating_average.toFixed(1)} ({user.rating_count} reviews)</span>
                                </div>
                              )}
                            </div>

                            {/* Vendor Subscription Info */}
                            {user.account_type === "vendor" && (user.subscription_status || user.subscription_end_date) && (
                              <div className="mt-3 p-3 bg-slate-50 rounded-lg flex items-center justify-between">
                                <div className="text-sm">
                                  <span className="text-slate-500 mr-2">Subscription: </span>
                                  <Badge variant="outline" className={
                                    user.subscription_status === "active" ? "border-green-500 text-green-700" :
                                    user.subscription_status === "expired" ? "border-red-500 text-red-700" :
                                    "border-slate-400 text-slate-600"
                                  }>
                                    {user.subscription_status || "none"}
                                  </Badge>
                                  {user.subscription_end_date && (
                                    <span className="ml-2 text-slate-700">
                                      Expires: {format(new Date(user.subscription_end_date), "MMM d, yyyy")}
                                    </span>
                                  )}
                                  {user.trial_used && (
                                    <span className="ml-2 text-slate-700">(Trial Used)</span>
                                  )}
                                </div>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleSubscriptionEdit(user)}
                                  className="text-indigo-600 border-indigo-300 hover:bg-indigo-50"
                                >
                                  <Edit2 className="w-3 h-3 mr-1" />
                                  Edit
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setSelectedUser(user)}
                              >
                                <Eye className="w-4 h-4 md:mr-2" />
                                <span className="hidden md:inline">View</span>
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>User Details</DialogTitle>
                                <DialogDescription>
                                  Detailed information about {user.full_name}
                                </DialogDescription>
                              </DialogHeader>
                              {selectedUser && (
                                <div className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <p className="text-sm text-slate-500">Full Name</p>
                                      <p className="font-semibold">{selectedUser.full_name}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-slate-500">Email</p>
                                      <p className="font-semibold">{selectedUser.email}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-slate-500">Account Type</p>
                                      <Badge className={
                                        selectedUser.account_type === "admin" ? "bg-indigo-600" :
                                        selectedUser.account_type === "vendor" ? "bg-orange-600" :
                                        "bg-green-600"
                                      }>
                                        {selectedUser.account_type}
                                      </Badge>
                                    </div>
                                    <div>
                                      <p className="text-sm text-slate-500">Joined</p>
                                      <p className="font-semibold">{format(new Date(selectedUser.created_date), "PPP")}</p>
                                    </div>
                                    {selectedUser.phone && (
                                      <div>
                                        <p className="text-sm text-slate-500">Phone</p>
                                        <p className="font-semibold">{selectedUser.phone}</p>
                                      </div>
                                    )}
                                    {selectedUser.whatsapp && (
                                      <div>
                                        <p className="text-sm text-slate-500">WhatsApp</p>
                                        <p className="font-semibold">{selectedUser.whatsapp}</p>
                                      </div>
                                    )}
                                  </div>
                                  {selectedUser.bio && (
                                    <div>
                                      <p className="text-sm text-slate-500 mb-2">Bio</p>
                                      <p className="text-slate-700">{selectedUser.bio}</p>
                                    </div>
                                  )}
                                  {selectedUser.account_type === "vendor" && (
                                    <div className="bg-indigo-50 p-4 rounded-lg">
                                      <p className="text-sm text-slate-700">
                                        <Building2 className="w-4 h-4 inline mr-2" />
                                        <strong>{userProperties[selectedUser.id] || 0}</strong> Properties Listed
                                      </p>
                                      {selectedUser.rating_average > 0 && (
                                        <p className="text-sm text-slate-700 mt-2">
                                          <Star className="w-4 h-4 inline mr-2 text-yellow-500 fill-yellow-500" />
                                          Rating: <strong>{selectedUser.rating_average.toFixed(1)}</strong> ({selectedUser.rating_count} reviews)
                                        </p>
                                      )}
                                      <p className="text-sm text-slate-700 mt-2">
                                        <Calendar className="w-4 h-4 inline mr-2" />
                                        Subscription Status:{" "}
                                        <Badge variant="outline" className={
                                          selectedUser.subscription_status === "active" ? "border-green-500 text-green-700" :
                                          selectedUser.subscription_status === "expired" ? "border-red-500 text-red-700" :
                                          "border-slate-400 text-slate-600"
                                        }>
                                          {selectedUser.subscription_status || "none"}
                                        </Badge>
                                        {selectedUser.subscription_end_date && (
                                          <span className="ml-2">Expires: {format(new Date(selectedUser.subscription_end_date), "MMM d, yyyy")}</span>
                                        )}
                                        {selectedUser.trial_used && (
                                          <span className="ml-2">(Trial Used)</span>
                                        )}
                                      </p>
                                    </div>
                                  )}
                                </div>
                              )}
                            </DialogContent>
                          </Dialog>

                          <Select
                            value={user.account_type}
                            onValueChange={(value) => handleAccountTypeChange(user.id, value)}
                            disabled={updating === user.id}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="tenant">Tenant</SelectItem>
                              <SelectItem value="vendor">Vendor</SelectItem>
                              <SelectItem value="admin">Admin</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Edit Subscription Dialog */}
      {editingSubscription && (
        <Dialog open={!!editingSubscription} onOpenChange={() => setEditingSubscription(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Subscription Details</DialogTitle>
              <DialogDescription>
                Update subscription for {editingSubscription.full_name}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubscriptionUpdate} className="space-y-4">
              <div>
                <Label htmlFor="subscription_status">Subscription Status</Label>
                <Select
                  value={subscriptionForm.subscription_status}
                  onValueChange={(value) => setSubscriptionForm({...subscriptionForm, subscription_status: value})}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="subscription_end_date">Subscription End Date</Label>
                <Input
                  id="subscription_end_date"
                  type="date"
                  value={subscriptionForm.subscription_end_date}
                  onChange={(e) => setSubscriptionForm({...subscriptionForm, subscription_end_date: e.target.value})}
                  className="mt-2"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="trial_used"
                  checked={subscriptionForm.trial_used}
                  onChange={(e) => setSubscriptionForm({...subscriptionForm, trial_used: e.target.checked})}
                  className="h-4 w-4 rounded border-slate-300"
                />
                <Label htmlFor="trial_used" className="cursor-pointer">
                  Trial Already Used
                </Label>
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setEditingSubscription(null)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updating === editingSubscription.id}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                >
                  {updating === editingSubscription.id ? "Updating..." : "Update"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
