import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Bed, Users, ImageIcon, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function ManageRooms() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [lodge, setLodge] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState(null);
  
  const [formData, setFormData] = useState({
    room_number: "",
    room_type: "double",
    description: "",
    price_per_night: "",
    max_occupancy: "2",
    bed_type: "double",
    number_of_beds: "1",
    images: [],
    amenities: [],
    bathroom_type: "private",
    has_shower: true,
    has_bathtub: false,
    has_hot_water: true,
    floor_number: "1",
    size_sqm: "",
    status: "available"
  });

  const urlParams = new URLSearchParams(window.location.search);
  const lodgeId = urlParams.get("lodgeId");

  useEffect(() => {
    loadData();
  }, [lodgeId]);

  const loadData = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      if (!lodgeId) {
        alert("No lodge selected");
        navigate(createPageUrl("MyLodges"));
        return;
      }

      const lodgeData = await base44.entities.Lodge.get(lodgeId);
      
      if (lodgeData.owner_id !== currentUser.id && currentUser.account_type !== "admin") {
        alert("You don't have permission to manage this lodge's rooms");
        navigate(createPageUrl("MyLodges"));
        return;
      }

      setLodge(lodgeData);
      setLoading(false);
    } catch (error) {
      console.error("Error loading data:", error);
      navigate(createPageUrl("MyLodges"));
    }
  };

  const { data: rooms = [], isLoading: roomsLoading } = useQuery({
    queryKey: ['rooms', lodgeId],
    queryFn: () => base44.entities.Room.filter({ lodge_id: lodgeId }),
    enabled: !!lodgeId
  });

  const createRoomMutation = useMutation({
    mutationFn: (roomData) => base44.entities.Room.create(roomData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rooms', lodgeId] });
      setDialogOpen(false);
      resetForm();
      alert("Room added successfully!");
    }
  });

  const updateRoomMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Room.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rooms', lodgeId] });
      setDialogOpen(false);
      resetForm();
      alert("Room updated successfully!");
    }
  });

  const deleteRoomMutation = useMutation({
    mutationFn: (id) => base44.entities.Room.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rooms', lodgeId] });
      alert("Room deleted successfully!");
    }
  });

  const compressImage = (file, maxSizeKB = 600) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const maxDimension = 1920;
          if (width > height && width > maxDimension) {
            height = (height / width) * maxDimension;
            width = maxDimension;
          } else if (height > maxDimension) {
            width = (width / height) * maxDimension;
            height = maxDimension;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          
          const tryCompress = (quality) => {
            canvas.toBlob((blob) => {
              const sizeKB = blob.size / 1024;
              
              if (sizeKB <= maxSizeKB || quality <= 0.3) {
                const compressedFile = new File([blob], file.name, {
                  type: 'image/jpeg',
                  lastModified: Date.now()
                });
                resolve({ file: compressedFile, overSize: sizeKB > maxSizeKB, finalSize: sizeKB });
              } else {
                tryCompress(quality - 0.1);
              }
            }, 'image/jpeg', quality);
          };
          
          tryCompress(0.8);
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
    });
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    const maxImages = 4;
    if (formData.images.length + files.length > maxImages) {
      alert(`Maximum ${maxImages} images per room`);
      return;
    }

    setUploadingImages(true);

    try {
      const uploadPromises = files.map(async (file) => {
        const { file: compressedFile, overSize, finalSize } = await compressImage(file);
        
        if (overSize) {
          alert(`Warning: "${file.name}" is ${finalSize.toFixed(0)}KB after compression.`);
        }
        
        const { file_url } = await base44.integrations.Core.UploadFile({ file: compressedFile });
        return file_url;
      });
      
      const imageUrls = await Promise.all(uploadPromises);
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...imageUrls]
      }));
    } catch (error) {
      console.error("Error uploading images:", error);
      alert("Error uploading images.");
    }

    setUploadingImages(false);
  };

  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const resetForm = () => {
    setFormData({
      room_number: "",
      room_type: "double",
      description: "",
      price_per_night: "",
      max_occupancy: "2",
      bed_type: "double",
      number_of_beds: "1",
      images: [],
      amenities: [],
      bathroom_type: "private",
      has_shower: true,
      has_bathtub: false,
      has_hot_water: true,
      floor_number: "1",
      size_sqm: "",
      status: "available"
    });
    setEditingRoom(null);
  };

  const handleEditRoom = (room) => {
    setEditingRoom(room);
    setFormData({
      room_number: room.room_number || "",
      room_type: room.room_type || "double",
      description: room.description || "",
      price_per_night: room.price_per_night?.toString() || "",
      max_occupancy: room.max_occupancy?.toString() || "2",
      bed_type: room.bed_type || "double",
      number_of_beds: room.number_of_beds?.toString() || "1",
      images: room.images || [],
      amenities: room.amenities || [],
      bathroom_type: room.bathroom_type || "private",
      has_shower: room.has_shower ?? true,
      has_bathtub: room.has_bathtub ?? false,
      has_hot_water: room.has_hot_water ?? true,
      floor_number: room.floor_number?.toString() || "1",
      size_sqm: room.size_sqm?.toString() || "",
      status: room.status || "available"
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const roomData = {
      ...formData,
      lodge_id: lodgeId,
      price_per_night: parseFloat(formData.price_per_night),
      max_occupancy: parseInt(formData.max_occupancy),
      number_of_beds: parseInt(formData.number_of_beds),
      floor_number: parseInt(formData.floor_number),
      size_sqm: formData.size_sqm ? parseFloat(formData.size_sqm) : null
    };

    if (editingRoom) {
      updateRoomMutation.mutate({ id: editingRoom.id, data: roomData });
    } else {
      createRoomMutation.mutate(roomData);
    }
  };

  const handleDeleteRoom = (roomId) => {
    if (confirm("Are you sure you want to delete this room?")) {
      deleteRoomMutation.mutate(roomId);
    }
  };

  if (loading || roomsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const amenitiesList = [
    { value: "tv", label: "TV" },
    { value: "ac", label: "Air Conditioning" },
    { value: "wifi", label: "WiFi" },
    { value: "mini_fridge", label: "Mini Fridge" },
    { value: "safe", label: "Safe" },
    { value: "balcony", label: "Balcony" },
    { value: "phone", label: "Phone" },
    { value: "desk", label: "Work Desk" },
    { value: "wardrobe", label: "Wardrobe" }
  ];

  const userCurrency = user?.currency || "TZS";

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">
              Manage Rooms - {lodge?.name}
            </h1>
            <p className="text-slate-600">Add and manage rooms for your lodge</p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700">
                <Plus className="w-5 h-5 mr-2" />
                Add Room
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingRoom ? "Edit Room" : "Add New Room"}</DialogTitle>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-6 mt-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="room_number">Room Number/Name *</Label>
                    <Input
                      id="room_number"
                      value={formData.room_number}
                      onChange={(e) => setFormData({...formData, room_number: e.target.value})}
                      placeholder="e.g., 101, Suite A"
                      required
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="room_type">Room Type *</Label>
                    <Select
                      value={formData.room_type}
                      onValueChange={(value) => setFormData({...formData, room_type: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="single">Single</SelectItem>
                        <SelectItem value="double">Double</SelectItem>
                        <SelectItem value="twin">Twin</SelectItem>
                        <SelectItem value="suite">Suite</SelectItem>
                        <SelectItem value="family">Family</SelectItem>
                        <SelectItem value="deluxe">Deluxe</SelectItem>
                        <SelectItem value="executive">Executive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="price_per_night">Price per Night ({userCurrency}) *</Label>
                    <Input
                      id="price_per_night"
                      type="number"
                      step="any"
                      value={formData.price_per_night}
                      onChange={(e) => setFormData({...formData, price_per_night: e.target.value})}
                      placeholder="e.g., 50000"
                      required
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="max_occupancy">Max Occupancy *</Label>
                    <Input
                      id="max_occupancy"
                      type="number"
                      value={formData.max_occupancy}
                      onChange={(e) => setFormData({...formData, max_occupancy: e.target.value})}
                      placeholder="Number of guests"
                      required
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="bed_type">Bed Type *</Label>
                    <Select
                      value={formData.bed_type}
                      onValueChange={(value) => setFormData({...formData, bed_type: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="single">Single</SelectItem>
                        <SelectItem value="double">Double</SelectItem>
                        <SelectItem value="queen">Queen</SelectItem>
                        <SelectItem value="king">King</SelectItem>
                        <SelectItem value="twin">Twin</SelectItem>
                        <SelectItem value="bunk">Bunk Bed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="number_of_beds">Number of Beds</Label>
                    <Input
                      id="number_of_beds"
                      type="number"
                      value={formData.number_of_beds}
                      onChange={(e) => setFormData({...formData, number_of_beds: e.target.value})}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="floor_number">Floor Number</Label>
                    <Input
                      id="floor_number"
                      type="number"
                      value={formData.floor_number}
                      onChange={(e) => setFormData({...formData, floor_number: e.target.value})}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="size_sqm">Size (sqm)</Label>
                    <Input
                      id="size_sqm"
                      type="number"
                      step="any"
                      value={formData.size_sqm}
                      onChange={(e) => setFormData({...formData, size_sqm: e.target.value})}
                      placeholder="Room size"
                      className="mt-2"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Room Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    placeholder="Describe the room features..."
                    className="h-24 mt-2"
                  />
                </div>

                <div>
                  <Label className="text-base font-semibold mb-3 block">Bathroom</Label>
                  <div className="space-y-3">
                    <Select
                      value={formData.bathroom_type}
                      onValueChange={(value) => setFormData({...formData, bathroom_type: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="private">Private Bathroom</SelectItem>
                        <SelectItem value="shared">Shared Bathroom</SelectItem>
                        <SelectItem value="ensuite">Ensuite</SelectItem>
                      </SelectContent>
                    </Select>

                    <div className="grid grid-cols-3 gap-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="has_shower"
                          checked={formData.has_shower}
                          onCheckedChange={(checked) => setFormData({...formData, has_shower: checked})}
                        />
                        <Label htmlFor="has_shower" className="cursor-pointer font-normal">Shower</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="has_bathtub"
                          checked={formData.has_bathtub}
                          onCheckedChange={(checked) => setFormData({...formData, has_bathtub: checked})}
                        />
                        <Label htmlFor="has_bathtub" className="cursor-pointer font-normal">Bathtub</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="has_hot_water"
                          checked={formData.has_hot_water}
                          onCheckedChange={(checked) => setFormData({...formData, has_hot_water: checked})}
                        />
                        <Label htmlFor="has_hot_water" className="cursor-pointer font-normal">Hot Water</Label>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-base font-semibold mb-3 block">Room Amenities</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {amenitiesList.map((amenity) => (
                      <div key={amenity.value} className="flex items-center space-x-2">
                        <Checkbox
                          id={amenity.value}
                          checked={formData.amenities.includes(amenity.value)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, amenities: [...formData.amenities, amenity.value]});
                            } else {
                              setFormData({...formData, amenities: formData.amenities.filter(a => a !== amenity.value)});
                            }
                          }}
                        />
                        <Label htmlFor={amenity.value} className="cursor-pointer font-normal text-sm">{amenity.label}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="mb-3 block">Room Images (Max 4)</Label>
                  {formData.images.length > 0 && (
                    <div className="grid grid-cols-4 gap-2 mb-3">
                      {formData.images.map((image, index) => (
                        <div key={index} className="relative group">
                          <img 
                            src={image} 
                            alt={`Room ${index + 1}`} 
                            className="w-full h-20 object-cover rounded border" 
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100"
                            onClick={() => removeImage(index)}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                  <Label htmlFor="room_images" className="cursor-pointer">
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-indigo-400 hover:bg-indigo-50/50 transition-all">
                      {uploadingImages ? (
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-indigo-600" />
                          <span className="text-sm">Uploading...</span>
                        </div>
                      ) : (
                        <>
                          <ImageIcon className="w-8 h-8 mx-auto mb-2 text-slate-400" />
                          <p className="text-sm text-slate-600">Click to upload images</p>
                          <p className="text-xs text-slate-500 mt-1">{formData.images.length} of 4 uploaded</p>
                        </>
                      )}
                    </div>
                  </Label>
                  <Input
                    id="room_images"
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageUpload}
                    className="hidden"
                    disabled={uploadingImages || formData.images.length >= 4}
                  />
                </div>

                <div>
                  <Label htmlFor="status">Room Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({...formData, status: value})}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Available</SelectItem>
                      <SelectItem value="occupied">Occupied</SelectItem>
                      <SelectItem value="maintenance">Under Maintenance</SelectItem>
                      <SelectItem value="reserved">Reserved</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createRoomMutation.isPending || updateRoomMutation.isPending}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    {editingRoom ? "Update Room" : "Add Room"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {rooms.length === 0 ? (
        <Card className="border-0 shadow-xl">
          <CardContent className="text-center py-16">
            <Bed className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-900 mb-2">No Rooms Added Yet</h3>
            <p className="text-slate-600 mb-6">Start by adding rooms to your lodge</p>
            <Button onClick={() => setDialogOpen(true)} className="bg-indigo-600 hover:bg-indigo-700">
              <Plus className="w-5 h-5 mr-2" />
              Add First Room
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room) => (
            <Card key={room.id} className="border-0 shadow-xl overflow-hidden">
              <div className="relative h-40 bg-slate-200">
                {room.images && room.images.length > 0 ? (
                  <img
                    src={room.images[0]}
                    alt={room.room_number}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Bed className="w-12 h-12 text-slate-400" />
                  </div>
                )}
                <Badge className={`absolute top-2 right-2 ${
                  room.status === 'available' ? 'bg-green-500' :
                  room.status === 'occupied' ? 'bg-red-500' :
                  room.status === 'maintenance' ? 'bg-yellow-500' :
                  'bg-blue-500'
                }`}>
                  {room.status}
                </Badge>
              </div>
              <CardContent className="p-4">
                <h3 className="font-bold text-lg mb-2">{room.room_number} - {room.room_type}</h3>
                <div className="space-y-2 text-sm text-slate-600 mb-4">
                  <div className="flex items-center gap-2">
                    <Bed className="w-4 h-4" />
                    <span>{room.bed_type} bed (x{room.number_of_beds})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span>Max {room.max_occupancy} guests</span>
                  </div>
                  <div className="font-semibold text-indigo-600 text-base">
                    {userCurrency} {room.price_per_night?.toLocaleString()} / night
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleEditRoom(room)}
                  >
                    <Edit className="w-4 h-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-red-600 hover:text-red-700"
                    onClick={() => handleDeleteRoom(room.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}