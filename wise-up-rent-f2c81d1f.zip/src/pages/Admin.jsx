
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { LandlordRequest } from "@/api/entities";
import { Property } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CheckCircle, 
  X, 
  Clock, 
  User as UserIcon,
  Mail,
  Calendar,
  MessageSquare,
  Building2,
  Users,
  Shield
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Admin() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [allRequests, setAllRequests] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(null);
  const [success, setSuccess] = useState("");

  const loadData = useCallback(async () => {
    const currentUser = await User.me();
    setUser(currentUser);

    if (currentUser.account_type !== "admin") {
      navigate(createPageUrl("Dashboard"));
      return;
    }

    const [pending, all, properties, users] = await Promise.all([
      LandlordRequest.filter({ status: "pending" }, "-created_date"),
      LandlordRequest.list("-created_date"),
      Property.list(),
      User.list()
    ]);

    setPendingRequests(pending);
    setAllRequests(all);
    setStats({
      pendingRequests: pending.length,
      totalRequests: all.length,
      approved: all.filter(r => r.status === "approved").length,
      rejected: all.filter(r => r.status === "rejected").length,
      totalProperties: properties.length,
      totalUsers: users.length,
      landlords: users.filter(u => u.account_type === "landlord").length
    });

    setLoading(false);
  }, [navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleApprove = async (request) => {
    setProcessing(request.id);

    try {
      // Update request status
      await LandlordRequest.update(request.id, {
        status: "approved",
        reviewed_by: user.id,
        reviewed_at: new Date().toISOString()
      });

      // Update user account type
      await User.update(request.user_id, {
        account_type: "landlord"
      });

      setSuccess(`Approved ${request.user_name}'s landlord request`);
      setTimeout(() => setSuccess(""), 3000);
      
      await loadData();
    } catch (error) {
      console.error("Error approving request:", error);
    }

    setProcessing(null);
  };

  const handleReject = async (request) => {
    setProcessing(request.id);

    try {
      await LandlordRequest.update(request.id, {
        status: "rejected",
        reviewed_by: user.id,
        reviewed_at: new Date().toISOString()
      });

      setSuccess(`Rejected ${request.user_name}'s landlord request`);
      setTimeout(() => setSuccess(""), 3000);
      
      await loadData();
    } catch (error) {
      console.error("Error rejecting request:", error);
    }

    setProcessing(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2 flex items-center gap-3">
          <Shield className="w-8 h-8 text-indigo-600" />
          Admin Panel
        </h1>
        <p className="text-slate-600">Manage landlord requests and monitor platform activity</p>
      </div>

      {success && (
        <Alert className="mb-6 border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-900">{success}</AlertDescription>
        </Alert>
      )}

      {/* Stats Overview */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card className="border-0 shadow-xl bg-gradient-to-br from-orange-500 to-red-500 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-orange-100 text-sm mb-1">Pending Requests</p>
                <p className="text-4xl font-bold">{stats.pendingRequests}</p>
              </div>
              <Clock className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-green-100 text-sm mb-1">Approved</p>
                <p className="text-4xl font-bold">{stats.approved}</p>
              </div>
              <CheckCircle className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-indigo-100 text-sm mb-1">Total Landlords</p>
                <p className="text-4xl font-bold">{stats.landlords}</p>
              </div>
              <Building2 className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-blue-100 text-sm mb-1">Total Users</p>
                <p className="text-4xl font-bold">{stats.totalUsers}</p>
              </div>
              <Users className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Requests */}
      <Card className="border-0 shadow-xl mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-orange-600" />
            Pending Landlord Requests ({pendingRequests.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {pendingRequests.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">All Caught Up!</h3>
              <p className="text-slate-600">No pending landlord requests at the moment.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingRequests.map((request) => (
                <Card key={request.id} className="border-2 border-orange-200 bg-orange-50/50">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-full flex items-center justify-center">
                            <span className="text-white font-bold text-lg">
                              {request.user_name?.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <h3 className="font-bold text-lg text-slate-900">{request.user_name}</h3>
                            <div className="flex items-center gap-2 text-sm text-slate-600">
                              <Mail className="w-4 h-4" />
                              {request.user_email}
                            </div>
                          </div>
                        </div>

                        <div className="bg-white p-4 rounded-lg mb-4">
                          <div className="flex items-center gap-2 mb-2">
                            <MessageSquare className="w-4 h-4 text-indigo-600" />
                            <span className="font-semibold text-sm text-slate-700">Application Reason:</span>
                          </div>
                          <p className="text-slate-600">{request.reason}</p>
                        </div>

                        <div className="flex items-center gap-2 text-sm text-slate-500">
                          <Calendar className="w-4 h-4" />
                          Applied on {new Date(request.created_date).toLocaleDateString()}
                        </div>
                      </div>

                      <div className="flex md:flex-col gap-3">
                        <Button
                          onClick={() => handleApprove(request)}
                          disabled={processing === request.id}
                          className="flex-1 md:flex-none bg-green-600 hover:bg-green-700 gap-2"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Approve
                        </Button>
                        <Button
                          onClick={() => handleReject(request)}
                          disabled={processing === request.id}
                          variant="destructive"
                          className="flex-1 md:flex-none gap-2"
                        >
                          <X className="w-4 h-4" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Request History */}
      <Card className="border-0 shadow-xl">
        <CardHeader>
          <CardTitle>Request History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {allRequests.filter(r => r.status !== "pending").map((request) => (
              <div key={request.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-slate-400 to-slate-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold text-sm">
                      {request.user_name?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900">{request.user_name}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(request.created_date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <Badge className={
                  request.status === "approved" ? "bg-green-500" : "bg-red-500"
                }>
                  {request.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
