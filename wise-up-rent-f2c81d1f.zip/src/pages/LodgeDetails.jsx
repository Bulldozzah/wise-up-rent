
import React, { useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, MapPin, Star, Phone, MessageSquare, Mail, 
  Wifi, Car, Utensils, Coffee, Dumbbell, Waves, User,
  Building2, Bed, Users, DollarSign, Droplets, Tv, Wind,
  Shield, Smartphone, Briefcase, Refrigerator, Archive
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import LocationMap from "../components/property/LocationMap";
import ImageGallery from "../components/property/ImageGallery";

export default function LodgeDetails() {
  const navigate = useNavigate();
  const [lodge, setLodge] = useState(null);
  const [owner, setOwner] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const urlParams = new URLSearchParams(window.location.search);
  const lodgeId = urlParams.get("id");

  const { data: rooms = [] } = useQuery({
    queryKey: ['rooms', lodgeId],
    queryFn: () => base44.entities.Room.filter({ lodge_id: lodgeId }),
    enabled: !!lodgeId
  });

  const loadData = useCallback(async () => {
    try {
      if (!lodgeId) {
        navigate(createPageUrl("BrowseLodges"));
        return;
      }

      const lodgeData = await base44.entities.Lodge.get(lodgeId);
      setLodge(lodgeData);

      // Increment views
      await base44.entities.Lodge.update(lodgeId, { views: (lodgeData.views || 0) + 1 });

      if (lodgeData.owner_id) {
        const ownerData = {
          id: lodgeData.owner_id,
          full_name: lodgeData.owner_name,
          email: lodgeData.owner_email || null,
          phone: lodgeData.owner_phone || null,
          whatsapp: lodgeData.owner_whatsapp || null
        };
        setOwner(ownerData);
      }

      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
      } catch (error) {
        setCurrentUser(null);
      }

      setLoading(false);
    } catch (error) {
      console.error("Error loading lodge:", error);
      setLoading(false);
    }
  }, [lodgeId, navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const generateInquiryMessage = (room) => {
    let message = `Hello, I'm interested in a room at ${lodge.name}.`;
    if (room) {
      message += `\n\nRoom: ${room.room_number} - ${room.room_type}\nPrice: ${userCurrency} ${room.price_per_night?.toLocaleString()}/night`;
    }
    message += `\n\nIs it available? Please provide more details. Thank you.`;
    return message;
  };

  const handleCall = () => {
    if (owner?.phone) {
      window.location.href = `tel:${owner.phone}`;
    }
  };

  const handleWhatsApp = (room = null) => {
    if (owner?.whatsapp) {
      const message = encodeURIComponent(generateInquiryMessage(room));
      const cleanNumber = owner.whatsapp.replace(/[^0-9]/g, '');
      window.open(`https://wa.me/${cleanNumber}?text=${message}`, '_blank');
    }
  };
  
  const handleSMS = (room = null) => {
    if (owner?.phone) {
      const message = encodeURIComponent(generateInquiryMessage(room));
      window.location.href = `sms:${owner.phone}?body=${message}`;
    }
  };

  const handleEmail = (room = null) => {
    if (owner?.email) {
      const subject = encodeURIComponent(`Inquiry about: ${lodge.name}` + (room ? ` - Room ${room.room_number}` : ''));
      const body = encodeURIComponent(generateInquiryMessage(room));
      window.location.href = `mailto:${owner.email}?subject=${subject}&body=${body}`;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (!lodge) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="border-0 shadow-xl p-8">
          <p className="text-xl text-slate-600">Lodge not found</p>
        </Card>
      </div>
    );
  }

  const amenityIcons = {
    wifi: Wifi,
    parking: Car,
    restaurant: Utensils,
    bar: Coffee,
    pool: Waves,
    gym: Dumbbell,
    conference_hall: Building2,
    laundry: Droplets,
    room_service: User,
    airport_shuttle: Car
  };

  const roomAmenityIcons = {
    tv: Tv,
    ac: Wind,
    wifi: Wifi,
    mini_fridge: Refrigerator,
    safe: Shield,
    balcony: Building2,
    phone: Smartphone,
    desk: Briefcase,
    wardrobe: Archive
  };

  const userCurrency = currentUser?.currency || "TZS";

  const sortedRooms = [...rooms].sort((a, b) => {
    // Sort available rooms first
    if (a.status === 'available' && b.status !== 'available') return -1;
    if (a.status !== 'available' && b.status === 'available') return 1;
    // Then sort by room number
    return a.room_number.localeCompare(b.room_number);
  });

  return (
    <div className="pb-12">
      {/* Image Gallery */}
      {lodge.images && lodge.images.length > 0 && (
        <div className="relative h-96 bg-slate-900">
          <img
            src={lodge.images[0]}
            alt={lodge.name}
            className="w-full h-full object-cover opacity-90"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          
          <div className="absolute top-6 left-6">
            <Button
              variant="secondary"
              onClick={() => navigate(-1)}
              className="bg-white/90 hover:bg-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </div>

          {lodge.images.length > 1 && (
            <div className="absolute bottom-6 left-6">
              <ImageGallery images={lodge.images} propertyTitle={lodge.name} />
            </div>
          )}
        </div>
      )}

      <div className="max-w-7xl mx-auto px-6 md:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Lodge Info */}
            <Card className="border-0 shadow-2xl">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-4 gap-4">
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-slate-900 mb-2">{lodge.name}</h1>
                    <div className="flex items-center gap-4 flex-wrap">
                      <Badge className="capitalize">{lodge.type}</Badge>
                      {lodge.star_rating && (
                        <div className="flex items-center gap-1">
                          {[...Array(lodge.star_rating)].map((_, i) => (
                            <Star key={i} className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  {lodge.logo_url && (
                    <img 
                      src={lodge.logo_url} 
                      alt={`${lodge.name} Logo`}
                      className="w-20 h-20 md:w-24 md:h-24 object-contain rounded-lg border bg-white p-1 shadow-sm"
                    />
                  )}
                </div>

                {lodge.city && (
                  <div className="flex items-center gap-2 text-slate-600 mb-4">
                    <MapPin className="w-5 h-5" />
                    <span>
                      {lodge.address && `${lodge.address}, `}
                      {lodge.neighborhood && `${lodge.neighborhood}, `}
                      {lodge.city}
                      {lodge.state && `, ${lodge.state}`}
                    </span>
                  </div>
                )}

                {lodge.description && (
                  <p className="text-slate-600 leading-relaxed mb-6">{lodge.description}</p>
                )}

                {/* Amenities */}
                {lodge.amenities && lodge.amenities.length > 0 && (
                  <div className="mb-6">
                    <h3 className="font-semibold text-lg mb-3">Lodge Amenities</h3>
                    <div className="flex flex-wrap gap-3">
                      {lodge.amenities.map((amenity) => {
                        const Icon = amenityIcons[amenity] || Building2;
                        return (
                          <Badge key={amenity} variant="secondary" className="flex items-center gap-2 px-3 py-1">
                            <Icon className="w-4 h-4" />
                            {amenity.replace('_', ' ')}
                          </Badge>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Check-in/out times */}
                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  {lodge.check_in_time && (
                    <div>
                      <h4 className="font-semibold text-sm text-slate-600 mb-1">Check-in</h4>
                      <p className="text-slate-900">{lodge.check_in_time}</p>
                    </div>
                  )}
                  {lodge.check_out_time && (
                    <div>
                      <h4 className="font-semibold text-sm text-slate-600 mb-1">Check-out</h4>
                      <p className="text-slate-900">{lodge.check_out_time}</p>
                    </div>
                  )}
                </div>

                {/* Payment methods */}
                {lodge.payment_methods && lodge.payment_methods.length > 0 && (
                  <div className="mb-6">
                    <h4 className="font-semibold text-sm text-slate-600 mb-2">Payment Methods</h4>
                    <div className="flex flex-wrap gap-2">
                      {lodge.payment_methods.map((method) => (
                        <Badge key={method} variant="outline" className="capitalize">
                          {method.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Cancellation policy */}
                {lodge.cancellation_policy && (
                  <div>
                    <h4 className="font-semibold text-sm text-slate-600 mb-2">Cancellation Policy</h4>
                    <p className="text-slate-600 text-sm">{lodge.cancellation_policy}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Rooms */}
            <Card className="border-0 shadow-2xl">
              <CardHeader>
                <CardTitle>Available Rooms</CardTitle>
              </CardHeader>
              <CardContent>
                {rooms.length === 0 ? (
                  <p className="text-center text-slate-500 py-8">No rooms available at the moment</p>
                ) : (
                  <div className="space-y-4">
                    {sortedRooms.map((room) => (
                      <Card key={room.id} className={`border ${room.status !== 'available' ? 'bg-slate-50 opacity-70' : ''}`}>
                        <CardContent className="p-4">
                          <div className="grid md:grid-cols-[128px_1fr] gap-4">
                            {room.images && room.images.length > 0 && (
                              <img 
                                src={room.images[0]} 
                                alt={room.room_number}
                                className="w-32 h-32 object-cover rounded-lg"
                              />
                            )}
                            <div className="flex-1">
                              <div className="flex items-start justify-between mb-2">
                                <div>
                                  <h4 className="font-bold text-lg">{room.room_number} - {room.room_type}</h4>
                                  {room.description && (
                                    <p className="text-sm text-slate-600 mt-1">{room.description}</p>
                                  )}
                                </div>
                                <div className="text-right flex-shrink-0 pl-4">
                                  <p className={`text-2xl font-bold ${room.status === 'available' ? 'text-indigo-600' : 'text-slate-500'}`}>
                                    {userCurrency} {room.price_per_night?.toLocaleString()}
                                  </p>
                                  <p className="text-xs text-slate-500">per night</p>
                                </div>
                              </div>
                              
                              <Badge className={`capitalize mb-3 ${
                                room.status === 'available' ? 'bg-green-100 text-green-800' :
                                room.status === 'occupied' ? 'bg-red-100 text-red-800' :
                                'bg-yellow-100 text-yellow-800'
                              }`}>
                                {room.status.replace('_', ' ')}
                              </Badge>

                              <div className="flex flex-wrap gap-3 mt-3 text-sm text-slate-600">
                                <div className="flex items-center gap-1">
                                  <Bed className="w-4 h-4" />
                                  {room.bed_type} (x{room.number_of_beds})
                                </div>
                                <div className="flex items-center gap-1">
                                  <Users className="w-4 h-4" />
                                  Max {room.max_occupancy} guests
                                </div>
                                {room.bathroom_type && (
                                  <Badge variant="secondary" className="capitalize">
                                    {room.bathroom_type} bathroom
                                  </Badge>
                                )}
                              </div>

                              {room.amenities && room.amenities.length > 0 && (
                                <div className="flex flex-wrap gap-2 mt-3">
                                  {room.amenities.map((amenity) => {
                                    const Icon = roomAmenityIcons[amenity] || Building2;
                                    return (
                                      <div key={amenity} className="flex items-center gap-1 text-xs text-slate-600">
                                        <Icon className="w-3 h-3" />
                                        <span className="capitalize">{amenity.replace('_', ' ')}</span>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}

                              <div className="flex gap-2 mt-3 text-xs text-slate-600">
                                {room.has_shower && <Badge variant="outline" className="text-xs">Shower</Badge>}
                                {room.has_bathtub && <Badge variant="outline" className="text-xs">Bathtub</Badge>}
                                {room.has_hot_water && <Badge variant="outline" className="text-xs">Hot Water</Badge>}
                              </div>
                              
                              <div className="flex justify-end mt-4">
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button 
                                      size="sm" 
                                      className="bg-indigo-600 hover:bg-indigo-700"
                                      disabled={room.status !== 'available'} // Disable if not available
                                    >
                                      Inquire about this room
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    {owner?.whatsapp && (
                                      <DropdownMenuItem onClick={() => handleWhatsApp(room)}>
                                        <MessageSquare className="w-4 h-4 mr-2" /> WhatsApp
                                      </DropdownMenuItem>
                                    )}
                                    {owner?.phone && (
                                      <DropdownMenuItem onClick={() => handleSMS(room)}>
                                        <MessageSquare className="w-4 h-4 mr-2" /> Send SMS
                                      </DropdownMenuItem>
                                    )}
                                    {owner?.email && (
                                      <DropdownMenuItem onClick={() => handleEmail(room)}>
                                        <Mail className="w-4 h-4 mr-2" /> Send Email
                                      </DropdownMenuItem>
                                    )}
                                    {owner?.phone && (
                                      <DropdownMenuItem onClick={handleCall}>
                                        <Phone className="w-4 h-4 mr-2" /> Call Owner
                                      </DropdownMenuItem>
                                    )}
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Location Map */}
            {lodge.latitude && lodge.longitude && (
              <LocationMap
                latitude={lodge.latitude}
                longitude={lodge.longitude}
                country={lodge.country}
                city={lodge.city}
                address={lodge.address}
                editable={false}
              />
            )}
          </div>

          {/* Sidebar - Owner Contact */}
          <div className="space-y-6">
            {owner && (
              <Card className="border-0 shadow-2xl sticky top-6">
                <CardHeader className="bg-gradient-to-br from-indigo-50 to-blue-50">
                  <CardTitle>Contact Owner</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-lg">
                        {owner.full_name?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="font-bold text-lg">{owner.full_name}</p>
                      <p className="text-sm text-slate-600">Lodge Owner</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {owner.phone && (
                      <>
                        <Button
                          className="w-full bg-indigo-600 hover:bg-indigo-700 gap-2"
                          onClick={handleCall}
                        >
                          <Phone className="w-5 h-5" />
                          Call Owner
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full gap-2"
                          onClick={() => handleSMS()}
                        >
                          <MessageSquare className="w-5 h-5" />
                          Send SMS (General)
                        </Button>
                      </>
                    )}
                    {owner.whatsapp && (
                      <Button
                        className="w-full bg-green-600 hover:bg-green-700 gap-2"
                        onClick={() => handleWhatsApp()}
                      >
                        <MessageSquare className="w-5 h-5" />
                        WhatsApp (General)
                      </Button>
                    )}
                    {owner.email && (
                      <Button
                        variant="outline"
                        className="w-full gap-2"
                        onClick={() => handleEmail()}
                      >
                        <Mail className="w-5 h-5" />
                        Send Email (General)
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
