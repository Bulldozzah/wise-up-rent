import React, { useState, useEffect } from "react";
import { Property } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Search, 
  Building2, 
  MapPin, 
  Bed, 
  DollarSign, 
  Filter,
  SlidersHorizontal,
  Home,
  Droplets,
  Zap,
  Trash2,
  Shield,
  X
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function PropertySearch() {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  
  const [filters, setFilters] = useState({
    searchQuery: "",
    city: "",
    district: "",
    neighborhood: "",
    minBedrooms: "",
    maxRent: "",
    minRent: "",
    paymentFrequency: "",
    waterIncluded: false,
    electricityIncluded: false,
    garbageIncluded: false,
    isFenced: false,
    hasKitchen: false,
    hasDining: false,
    hasGarage: false,
    hasGarden: false,
  });

  useEffect(() => {
    loadProperties();
  }, []);

  const loadProperties = async () => {
    const allProperties = await Property.filter({ status: "available" }, "-created_date");
    setProperties(allProperties);
    setLoading(false);
  };

  const clearFilters = () => {
    setFilters({
      searchQuery: "",
      city: "",
      district: "",
      neighborhood: "",
      minBedrooms: "",
      maxRent: "",
      minRent: "",
      paymentFrequency: "",
      waterIncluded: false,
      electricityIncluded: false,
      garbageIncluded: false,
      isFenced: false,
      hasKitchen: false,
      hasDining: false,
      hasGarage: false,
      hasGarden: false,
    });
  };

  const filteredProperties = properties.filter(property => {
    // Search query filter
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      const matchesSearch = 
        property.title?.toLowerCase().includes(query) ||
        property.description?.toLowerCase().includes(query) ||
        property.city?.toLowerCase().includes(query) ||
        property.neighborhood?.toLowerCase().includes(query);
      if (!matchesSearch) return false;
    }

    // Location filters
    if (filters.city && !property.city?.toLowerCase().includes(filters.city.toLowerCase())) {
      return false;
    }
    if (filters.district && !property.district?.toLowerCase().includes(filters.district.toLowerCase())) {
      return false;
    }
    if (filters.neighborhood && !property.neighborhood?.toLowerCase().includes(filters.neighborhood.toLowerCase())) {
      return false;
    }

    // Bedroom filter
    if (filters.minBedrooms && property.bedrooms < parseInt(filters.minBedrooms)) {
      return false;
    }

    // Price filters
    if (filters.minRent && property.rent_amount < parseFloat(filters.minRent)) {
      return false;
    }
    if (filters.maxRent && property.rent_amount > parseFloat(filters.maxRent)) {
      return false;
    }

    // Payment frequency
    if (filters.paymentFrequency && property.payment_frequency !== filters.paymentFrequency) {
      return false;
    }

    // Utilities filters
    if (filters.waterIncluded && !property.water_included) return false;
    if (filters.electricityIncluded && !property.electricity_included) return false;
    if (filters.garbageIncluded && !property.garbage_included) return false;

    // Amenities filters
    if (filters.isFenced && !property.is_fenced) return false;
    if (filters.hasKitchen && !property.has_kitchen) return false;
    if (filters.hasDining && !property.has_dining) return false;
    if (filters.hasGarage && !property.has_garage) return false;
    if (filters.hasGarden && !property.has_garden) return false;

    return true;
  });

  const activeFiltersCount = Object.entries(filters).filter(([key, value]) => {
    if (key === 'searchQuery') return false;
    return value && value !== "";
  }).length;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const FilterSection = () => (
    <div className="space-y-6">
      {/* Location Filters */}
      <div>
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-indigo-600" />
          Location
        </h3>
        <div className="space-y-3">
          <div>
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              placeholder="Enter city..."
              value={filters.city}
              onChange={(e) => setFilters({...filters, city: e.target.value})}
            />
          </div>
          <div>
            <Label htmlFor="district">District</Label>
            <Input
              id="district"
              placeholder="Enter district..."
              value={filters.district}
              onChange={(e) => setFilters({...filters, district: e.target.value})}
            />
          </div>
          <div>
            <Label htmlFor="neighborhood">Neighborhood</Label>
            <Input
              id="neighborhood"
              placeholder="Enter neighborhood..."
              value={filters.neighborhood}
              onChange={(e) => setFilters({...filters, neighborhood: e.target.value})}
            />
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-indigo-600" />
          Price Range
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="minRent">Min Price</Label>
            <Input
              id="minRent"
              type="number"
              placeholder="Min"
              value={filters.minRent}
              onChange={(e) => setFilters({...filters, minRent: e.target.value})}
            />
          </div>
          <div>
            <Label htmlFor="maxRent">Max Price</Label>
            <Input
              id="maxRent"
              type="number"
              placeholder="Max"
              value={filters.maxRent}
              onChange={(e) => setFilters({...filters, maxRent: e.target.value})}
            />
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <Bed className="w-5 h-5 text-indigo-600" />
          Property Details
        </h3>
        <div className="space-y-3">
          <div>
            <Label htmlFor="minBedrooms">Minimum Bedrooms</Label>
            <Select
              value={filters.minBedrooms}
              onValueChange={(value) => setFilters({...filters, minBedrooms: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Any" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>Any</SelectItem>
                <SelectItem value="1">1+</SelectItem>
                <SelectItem value="2">2+</SelectItem>
                <SelectItem value="3">3+</SelectItem>
                <SelectItem value="4">4+</SelectItem>
                <SelectItem value="5">5+</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="paymentFrequency">Payment Frequency</Label>
            <Select
              value={filters.paymentFrequency}
              onValueChange={(value) => setFilters({...filters, paymentFrequency: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Any" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>Any</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
                <SelectItem value="quarterly">Quarterly</SelectItem>
                <SelectItem value="semi-annual">Semi-Annual</SelectItem>
                <SelectItem value="annual">Annual</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <Droplets className="w-5 h-5 text-indigo-600" />
          Utilities Included
        </h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="waterIncluded"
              checked={filters.waterIncluded}
              onCheckedChange={(checked) => setFilters({...filters, waterIncluded: checked})}
            />
            <Label htmlFor="waterIncluded" className="cursor-pointer flex items-center gap-2">
              <Droplets className="w-4 h-4 text-blue-500" />
              Water Bill
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="electricityIncluded"
              checked={filters.electricityIncluded}
              onCheckedChange={(checked) => setFilters({...filters, electricityIncluded: checked})}
            />
            <Label htmlFor="electricityIncluded" className="cursor-pointer flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-500" />
              Electricity Bill
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="garbageIncluded"
              checked={filters.garbageIncluded}
              onCheckedChange={(checked) => setFilters({...filters, garbageIncluded: checked})}
            />
            <Label htmlFor="garbageIncluded" className="cursor-pointer flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-green-500" />
              Garbage Collection
            </Label>
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <Home className="w-5 h-5 text-indigo-600" />
          Amenities
        </h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="isFenced"
              checked={filters.isFenced}
              onCheckedChange={(checked) => setFilters({...filters, isFenced: checked})}
            />
            <Label htmlFor="isFenced" className="cursor-pointer flex items-center gap-2">
              <Shield className="w-4 h-4 text-indigo-500" />
              Fenced Property
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="hasKitchen"
              checked={filters.hasKitchen}
              onCheckedChange={(checked) => setFilters({...filters, hasKitchen: checked})}
            />
            <Label htmlFor="hasKitchen" className="cursor-pointer">
              Kitchen
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="hasDining"
              checked={filters.hasDining}
              onCheckedChange={(checked) => setFilters({...filters, hasDining: checked})}
            />
            <Label htmlFor="hasDining" className="cursor-pointer">
              Dining Room
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="hasGarage"
              checked={filters.hasGarage}
              onCheckedChange={(checked) => setFilters({...filters, hasGarage: checked})}
            />
            <Label htmlFor="hasGarage" className="cursor-pointer">
              Garage
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="hasGarden"
              checked={filters.hasGarden}
              onCheckedChange={(checked) => setFilters({...filters, hasGarden: checked})}
            />
            <Label htmlFor="hasGarden" className="cursor-pointer">
              Garden
            </Label>
          </div>
        </div>
      </div>

      <Button
        variant="outline"
        className="w-full"
        onClick={clearFilters}
      >
        <X className="w-4 h-4 mr-2" />
        Clear All Filters
      </Button>
    </div>
  );

  return (
    <div className="min-h-screen">
      {/* Hero Search Section */}
      <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-indigo-700 text-white py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">
              Find Your Dream Home
            </h1>
            <p className="text-xl text-blue-100">
              Search through {properties.length} available properties
            </p>
          </div>

          {/* Main Search Bar */}
          <Card className="border-0 shadow-2xl max-w-4xl mx-auto">
            <CardContent className="p-6">
              <div className="flex gap-3">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Search by title, city, or neighborhood..."
                    value={filters.searchQuery}
                    onChange={(e) => setFilters({...filters, searchQuery: e.target.value})}
                    className="pl-10 h-12 text-lg"
                  />
                </div>
                
                {/* Mobile Filter Button */}
                <Sheet>
                  <SheetTrigger asChild>
                    <Button className="md:hidden bg-indigo-600 hover:bg-indigo-700 h-12 relative">
                      <SlidersHorizontal className="w-5 h-5" />
                      {activeFiltersCount > 0 && (
                        <Badge className="absolute -top-2 -right-2 bg-orange-500 h-5 w-5 p-0 flex items-center justify-center">
                          {activeFiltersCount}
                        </Badge>
                      )}
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-80 overflow-y-auto">
                    <SheetHeader className="mb-6">
                      <SheetTitle>Filter Properties</SheetTitle>
                      <SheetDescription>
                        Refine your search with filters
                      </SheetDescription>
                    </SheetHeader>
                    <FilterSection />
                  </SheetContent>
                </Sheet>
              </div>

              {/* Quick Filters */}
              <div className="flex flex-wrap gap-2 mt-4">
                <Button
                  size="sm"
                  variant={filters.waterIncluded ? "default" : "outline"}
                  onClick={() => setFilters({...filters, waterIncluded: !filters.waterIncluded})}
                  className="gap-2"
                >
                  <Droplets className="w-4 h-4" />
                  Water Included
                </Button>
                <Button
                  size="sm"
                  variant={filters.electricityIncluded ? "default" : "outline"}
                  onClick={() => setFilters({...filters, electricityIncluded: !filters.electricityIncluded})}
                  className="gap-2"
                >
                  <Zap className="w-4 h-4" />
                  Electricity Included
                </Button>
                <Button
                  size="sm"
                  variant={filters.isFenced ? "default" : "outline"}
                  onClick={() => setFilters({...filters, isFenced: !filters.isFenced})}
                  className="gap-2"
                >
                  <Shield className="w-4 h-4" />
                  Fenced
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Desktop Sidebar Filters */}
          <div className="hidden lg:block">
            <Card className="border-0 shadow-xl sticky top-6">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <Filter className="w-5 h-5 text-indigo-600" />
                    Filters
                  </h2>
                  {activeFiltersCount > 0 && (
                    <Badge className="bg-indigo-600">{activeFiltersCount}</Badge>
                  )}
                </div>
                <FilterSection />
              </CardContent>
            </Card>
          </div>

          {/* Properties Grid */}
          <div className="lg:col-span-3">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">
                  {filteredProperties.length} {filteredProperties.length === 1 ? 'Property' : 'Properties'} Found
                </h2>
                {activeFiltersCount > 0 && (
                  <p className="text-slate-600 text-sm mt-1">
                    {activeFiltersCount} filter{activeFiltersCount > 1 ? 's' : ''} active
                  </p>
                )}
              </div>
            </div>

            {filteredProperties.length === 0 ? (
              <Card className="border-0 shadow-xl">
                <CardContent className="text-center py-16">
                  <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">No Properties Found</h3>
                  <p className="text-slate-600 mb-6">Try adjusting your filters or search criteria</p>
                  <Button onClick={clearFilters} variant="outline">
                    Clear All Filters
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {filteredProperties.map((property) => (
                  <Link key={property.id} to={createPageUrl(`PropertyDetails?id=${property.id}`)}>
                    <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden cursor-pointer transform hover:-translate-y-2 h-full">
                      <div className="relative h-56 bg-slate-200">
                        {property.images && property.images.length > 0 ? (
                          <img
                            src={property.images[0]}
                            alt={property.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Building2 className="w-16 h-16 text-slate-400" />
                          </div>
                        )}
                        <Badge className="absolute top-3 right-3 bg-green-500">Available</Badge>
                        <div className="absolute bottom-3 left-3 flex gap-2">
                          {property.water_included && (
                            <Badge className="bg-blue-500 text-xs">
                              <Droplets className="w-3 h-3 mr-1" />
                              Water
                            </Badge>
                          )}
                          {property.electricity_included && (
                            <Badge className="bg-yellow-500 text-xs">
                              <Zap className="w-3 h-3 mr-1" />
                              Electric
                            </Badge>
                          )}
                        </div>
                      </div>
                      <CardContent className="p-6">
                        <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-1">{property.title}</h3>
                        
                        <div className="flex items-center gap-2 text-slate-600 mb-3">
                          <MapPin className="w-4 h-4 flex-shrink-0" />
                          <span className="text-sm line-clamp-1">
                            {property.city}{property.neighborhood && `, ${property.neighborhood}`}
                          </span>
                        </div>

                        <div className="flex items-center gap-4 mb-4 text-sm text-slate-600">
                          <div className="flex items-center gap-1">
                            <Bed className="w-4 h-4" />
                            <span>{property.bedrooms} bed</span>
                          </div>
                          {property.is_fenced && (
                            <div className="flex items-center gap-1">
                              <Shield className="w-4 h-4" />
                              <span>Fenced</span>
                            </div>
                          )}
                          {property.has_garage && (
                            <Badge variant="secondary" className="text-xs">Garage</Badge>
                          )}
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t">
                          <div className="flex items-center gap-1">
                            <DollarSign className="w-5 h-5 text-indigo-600" />
                            <span className="font-bold text-xl text-indigo-600">{property.rent_amount}</span>
                            <span className="text-sm text-slate-500">/{property.payment_frequency === 'monthly' ? 'mo' : property.payment_frequency}</span>
                          </div>
                          <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}