
import React, { useState, useEffect } from "react";
import { Listing } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Search, 
  Building2, 
  MapPin, 
  Filter,
  X,
  Car,
  Music,
  Laptop,
  Shirt,
  Wrench,
  Camera,
  Eye, // Added from outline
  Package // Added from outline
} from "lucide-react"; // DollarSign removed as per outline
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

const categoryIcons = {
  transport_vehicles: Car,
  events_entertainment: Music,
  home_office_equipment: Laptop,
  personal_lifestyle: Shirt,
  construction_tools: Wrench,
  media_technology: Camera
};

const categoryLabels = {
  transport_vehicles: "Transport & Vehicles",
  events_entertainment: "Events & Entertainment",
  home_office_equipment: "Home & Office Equipment",
  personal_lifestyle: "Personal & Lifestyle",
  construction_tools: "Construction & Tools",
  media_technology: "Media & Technology"
};

export default function BrowseItems() {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState("all");
  
  const [filters, setFilters] = useState({
    searchQuery: "",
    city: "",
    minPrice: "",
    maxPrice: "",
    condition: "",
    listingType: "all"
  });

  useEffect(() => {
    loadListings();
  }, []);

  const loadListings = async () => {
    const allListings = await Listing.filter({ status: "available" }, "-created_date");
    setListings(allListings);
    
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      setCurrentUser(null);
    }
    
    setLoading(false);
  };

  const clearFilters = () => {
    setFilters({
      searchQuery: "",
      city: "",
      minPrice: "",
      maxPrice: "",
      condition: "",
      listingType: "all"
    });
  };

  const filteredListings = listings.filter(listing => {
    if (selectedCategory !== "all" && listing.category !== selectedCategory) {
      return false;
    }

    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      const matchesSearch = 
        listing.title?.toLowerCase().includes(query) ||
        listing.description?.toLowerCase().includes(query) ||
        listing.city?.toLowerCase().includes(query) ||
        listing.subcategory?.toLowerCase().includes(query) ||
        listing.brand?.toLowerCase().includes(query);
      if (!matchesSearch) return false;
    }

    if (filters.city && !listing.city?.toLowerCase().includes(filters.city.toLowerCase())) {
      return false;
    }

    if (filters.listingType !== "all" && listing.listing_type !== filters.listingType) {
      return false;
    }

    const price = listing.listing_type === 'rent' ? listing.rent_amount : listing.sale_price;
    if (filters.minPrice && price < parseFloat(filters.minPrice)) {
      return false;
    }
    if (filters.maxPrice && price > parseFloat(filters.maxPrice)) {
      return false;
    }

    if (filters.condition && listing.condition !== filters.condition) {
      return false;
    }

    return true;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const userCurrency = currentUser?.currency || "TZS";

  return (
    <div className="min-h-screen">
      {/* Hero Search Section */}
      <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-indigo-700 text-white py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">
              Rent Anything You Need
            </h1>
            <p className="text-xl text-blue-100">
              From vehicles to equipment, tools to event gear
            </p>
          </div>

          <Card className="border-0 shadow-2xl max-w-4xl mx-auto">
            <CardContent className="p-6">
              <div className="flex gap-3 mb-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Search for anything..."
                    value={filters.searchQuery}
                    onChange={(e) => setFilters({...filters, searchQuery: e.target.value})}
                    className="pl-10 h-12 text-lg"
                  />
                </div>
                <Select
                  value={filters.listingType}
                  onValueChange={(value) => setFilters({...filters, listingType: value})}
                >
                  <SelectTrigger className="w-32 h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="rent">For Rent</SelectItem>
                    <SelectItem value="sale">For Sale</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Moved filters below the main search and listing type select */}
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3">
                <Input
                  placeholder="City"
                  value={filters.city}
                  onChange={(e) => setFilters({...filters, city: e.target.value})}
                />
                <Input
                  type="number"
                  placeholder="Min Price"
                  value={filters.minPrice}
                  onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
                />
                <Input
                  type="number"
                  placeholder="Max Price"
                  value={filters.maxPrice}
                  onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
                />
                <Select
                  value={filters.condition}
                  onValueChange={(value) => setFilters({...filters, condition: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Condition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>All Conditions</SelectItem> {/* Changed null to "" for consistency with other inputs */}
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="like_new">Like New</SelectItem>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
          <TabsList className="grid grid-cols-3 lg:grid-cols-7 gap-2 h-auto mb-8 bg-transparent">
            <TabsTrigger 
              value="all" 
              className="flex flex-col items-center gap-2 p-4 data-[state=active]:bg-indigo-600 data-[state=active]:text-white"
            >
              <Filter className="w-5 h-5" />
              <span className="text-xs">All</span>
            </TabsTrigger>
            {Object.entries(categoryLabels).map(([key, label]) => {
              const Icon = categoryIcons[key];
              return (
                <TabsTrigger 
                  key={key}
                  value={key}
                  className="flex flex-col items-center gap-2 p-4 data-[state=active]:bg-indigo-600 data-[state=active]:text-white"
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs text-center">{label.split(' ')[0]}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {/* This div previously held city, minPrice, maxPrice, condition filters. It is now removed. */}
          {/* <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Input
              placeholder="City"
              value={filters.city}
              onChange={(e) => setFilters({...filters, city: e.target.value})}
            />
            <Input
              type="number"
              placeholder="Min Price"
              value={filters.minPrice}
              onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
            />
            <Input
              type="number"
              placeholder="Max Price"
              value={filters.maxPrice}
              onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
            />
            <Select
              value={filters.condition}
              onValueChange={(value) => setFilters({...filters, condition: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>All Conditions</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="like_new">Like New</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
              </SelectContent>
            </Select>
          </div> */}

          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">
              {filteredListings.length} {filteredListings.length === 1 ? 'Item' : 'Items'} Found
            </h2>
            {(filters.searchQuery || filters.city || filters.minPrice || filters.maxPrice || filters.condition || filters.listingType !== "all") && (
              <Button onClick={clearFilters} variant="outline" size="sm">
                <X className="w-4 h-4 mr-2" />
                Clear Filters
              </Button>
            )}
          </div>

          {filteredListings.length === 0 ? (
            <Card className="border-0 shadow-xl">
              <CardContent className="text-center py-16">
                <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No Items Found</h3>
                <p className="text-slate-600 mb-6">Try adjusting your filters or search criteria</p>
                <Button onClick={clearFilters} variant="outline">
                  Clear All Filters
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredListings.map((listing) => {
                const CategoryIcon = categoryIcons[listing.category] || Building2;
                return (
                  <Link key={listing.id} to={createPageUrl(`Listing?id=${listing.id}`)}>
                    <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden cursor-pointer transform hover:-translate-y-2 h-full">
                      <div className="relative h-56 bg-slate-200">
                        {listing.images && listing.images.length > 0 ? (
                          <img
                            src={listing.images[0]}
                            alt={listing.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <CategoryIcon className="w-16 h-16 text-slate-400" />
                          </div>
                        )}
                        <div className="absolute top-3 left-3 flex gap-2">
                          <Badge className={listing.listing_type === "rent" ? "bg-indigo-600" : "bg-purple-600"}>
                            {listing.listing_type === "rent" ? "For Rent" : "For Sale"}
                          </Badge>
                          {listing.condition && (
                            <Badge variant="secondary" className="capitalize">
                              {listing.condition.replace('_', ' ')}
                            </Badge>
                          )}
                        </div>
                        <Badge className="absolute top-3 right-3 bg-green-500">Available</Badge>
                      </div>
                      <CardContent className="p-6">
                        <div className="flex items-center gap-2 mb-2">
                          <CategoryIcon className="w-4 h-4 text-indigo-600" />
                          <span className="text-xs text-slate-600">
                            {categoryLabels[listing.category]}
                          </span>
                        </div>
                        
                        <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-2">{listing.title}</h3>
                        
                        {listing.city && (
                          <div className="flex items-center gap-2 text-slate-600 mb-3">
                            <MapPin className="w-4 h-4 flex-shrink-0" />
                            <span className="text-sm line-clamp-1">{listing.city}</span>
                          </div>
                        )}

                        {(listing.brand || listing.model) && (
                          <p className="text-sm text-slate-600 mb-3">
                            {[listing.brand, listing.model].filter(Boolean).join(' ')}
                          </p>
                        )}

                        <div className="flex items-center justify-between pt-4 border-t">
                          <div> {/* Removed DollarSign icon */}
                            <span className="font-bold text-xl text-indigo-600">
                              {userCurrency} {listing.listing_type === "rent" 
                                ? listing.rent_amount?.toLocaleString() 
                                : listing.sale_price?.toLocaleString()
                              }
                            </span>
                            {listing.listing_type === "rent" && listing.payment_frequency && (
                              <span className="text-sm text-slate-500 ml-1">
                                /{listing.payment_frequency}
                              </span>
                            )}
                          </div>
                          <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                            View
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </Tabs>
      </div>
    </div>
  );
}
