
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Building2, MapPin, Star } from "lucide-react";

export default function BrowseLodges() {
  const [searchQuery, setSearchQuery] = useState("");
  const [lodgeType, setLodgeType] = useState("all");
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [neighborhood, setNeighborhood] = useState("");

  const { data: lodges = [], isLoading } = useQuery({
    queryKey: ['lodges'],
    queryFn: () => base44.entities.Lodge.filter({ status: "active" }, "-created_date")
  });

  const filteredLodges = lodges.filter(lodge => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const matchesSearch =
        lodge.name?.toLowerCase().includes(query) ||
        lodge.description?.toLowerCase().includes(query) ||
        lodge.city?.toLowerCase().includes(query) ||
        lodge.neighborhood?.toLowerCase().includes(query) ||
        lodge.country?.toLowerCase().includes(query) ||
        lodge.state?.toLowerCase().includes(query);
      if (!matchesSearch) return false;
    }

    if (lodgeType !== "all" && lodge.type !== lodgeType) {
      return false;
    }
    
    if (country && !lodge.country?.toLowerCase().includes(country.toLowerCase())) {
      return false;
    }

    if (city && !lodge.city?.toLowerCase().includes(city.toLowerCase())) {
      return false;
    }
    
    if (neighborhood && !lodge.neighborhood?.toLowerCase().includes(neighborhood.toLowerCase())) {
      return false;
    }

    return true;
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Hero Search Section */}
      <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-indigo-700 text-white py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">
              Find Your Perfect Lodge
            </h1>
            <p className="text-xl text-blue-100">
              Hotels, Motels, Lodges & Guesthouses
            </p>
          </div>

          <Card className="border-0 shadow-2xl max-w-4xl mx-auto">
            <CardContent className="p-6 space-y-4">
              <div className="flex gap-3">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Search by name, city, country, neighborhood..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12 text-lg"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3">
                <Select value={lodgeType} onValueChange={setLodgeType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Lodge Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="hotel">Hotels</SelectItem>
                    <SelectItem value="motel">Motels</SelectItem>
                    <SelectItem value="lodge">Lodges</SelectItem>
                    <SelectItem value="guesthouse">Guesthouses</SelectItem>
                    <SelectItem value="inn">Inns</SelectItem>
                    <SelectItem value="resort">Resorts</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  placeholder="Country"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                />
                
                <Input
                  placeholder="City"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
                
                <Input
                  placeholder="Neighborhood"
                  value={neighborhood}
                  onChange={(e) => setNeighborhood(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-slate-900">
            {filteredLodges.length} {filteredLodges.length === 1 ? 'Lodge' : 'Lodges'} Found
          </h2>
        </div>

        {filteredLodges.length === 0 ? (
          <Card className="border-0 shadow-xl">
            <CardContent className="text-center py-16">
              <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">No Lodges Found</h3>
              <p className="text-slate-600">Try adjusting your filters or search criteria</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredLodges.map((lodge) => (
              <Link key={lodge.id} to={createPageUrl(`LodgeDetails?id=${lodge.id}`)}>
                <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden cursor-pointer transform hover:-translate-y-2 h-full">
                  <div className="relative h-56 bg-slate-200">
                    {lodge.images && lodge.images.length > 0 ? (
                      <img
                        src={lodge.images[0]}
                        alt={lodge.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Building2 className="w-16 h-16 text-slate-400" />
                      </div>
                    )}
                    <Badge className="absolute top-3 left-3 bg-indigo-600 capitalize">
                      {lodge.type}
                    </Badge>
                    {lodge.star_rating && (
                      <Badge className="absolute top-3 right-3 bg-yellow-500 flex items-center gap-1">
                        <Star className="w-3 h-3 fill-white" />
                        {lodge.star_rating}
                      </Badge>
                    )}
                  </div>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-2 min-h-[3.5rem]">{lodge.name}</h3>

                    {lodge.city && (
                      <div className="flex items-center gap-2 text-slate-600 mb-3">
                        <MapPin className="w-4 h-4 flex-shrink-0" />
                        <span className="text-sm line-clamp-1">
                          {lodge.neighborhood && `${lodge.neighborhood}, `}
                          {lodge.city}
                        </span>
                      </div>
                    )}

                    {lodge.description && (
                      <p className="text-sm text-slate-600 line-clamp-2 mb-4">
                        {lodge.description}
                      </p>
                    )}

                    <div className="flex flex-wrap gap-2 mb-4">
                      {lodge.amenities?.slice(0, 3).map((amenity) => (
                        <Badge key={amenity} variant="secondary" className="text-xs capitalize">
                          {amenity.replace('_', ' ')}
                        </Badge>
                      ))}
                      {lodge.amenities?.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{lodge.amenities.length - 3} more
                        </Badge>
                      )}
                    </div>

                    <Button size="sm" className="w-full bg-indigo-600 hover:bg-indigo-700">
                      View Rooms & Details
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
