
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Property } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, Upload, X, ImageIcon, MapPin } from "lucide-react"; // Added MapPin
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import LocationMap from "../components/property/LocationMap";

export default function EditProperty() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [geocodingLoading, setGeocodingLoading] = useState(false); // New state for geocoding
  const [success, setSuccess] = useState(false);
  const [citySuggestions, setCitySuggestions] = useState([]);
  const [neighborhoodSuggestions, setNeighborhoodSuggestions] = useState([]);
  const [showCitySuggestions, setShowCitySuggestions] = useState(false);
  const [showNeighborhoodSuggestions, setShowNeighborhoodSuggestions] = useState(false);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    listing_type: "rent",
    city: "",
    neighborhood: "",
    address: "",
    latitude: null,
    longitude: null,
    images: [],
    rent_amount: "",
    sale_price: "",
    security_deposit: "",
    payment_frequency: "monthly",
    bedrooms: "1",
    has_kitchen: true,
    has_dining: false,
    has_study: false,
    has_garage: false,
    has_garden: false,
    water_included: false,
    electricity_included: false,
    garbage_included: false,
    is_fenced: false,
    fence_type: ""
  });

  const loadData = useCallback(async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const propertyId = urlParams.get("id");

    if (!propertyId) {
      navigate(createPageUrl("MyProperties"));
      return;
    }

    const currentUser = await User.me();
    setUser(currentUser);

    const propertyData = await Property.get(propertyId);
    setProperty(propertyData);

    if (propertyData.landlord_id !== currentUser.id && currentUser.account_type !== "admin") {
      navigate(createPageUrl("MyProperties"));
      return;
    }

    setFormData({
      title: propertyData.title || "",
      description: propertyData.description || "",
      listing_type: propertyData.listing_type || "rent",
      city: propertyData.city || "",
      neighborhood: propertyData.neighborhood || "",
      address: propertyData.address || "",
      latitude: propertyData.latitude || null,
      longitude: propertyData.longitude || null,
      images: propertyData.images || [],
      rent_amount: propertyData.rent_amount || "",
      sale_price: propertyData.sale_price || "",
      security_deposit: propertyData.security_deposit || "",
      payment_frequency: propertyData.payment_frequency || "monthly",
      bedrooms: propertyData.bedrooms?.toString() || "1",
      has_kitchen: propertyData.has_kitchen ?? true,
      has_dining: propertyData.has_dining ?? false,
      has_study: propertyData.has_study ?? false,
      has_garage: propertyData.has_garage ?? false,
      has_garden: propertyData.has_garden ?? false,
      water_included: propertyData.water_included ?? false,
      electricity_included: propertyData.electricity_included ?? false,
      garbage_included: propertyData.garbage_included ?? false,
      is_fenced: propertyData.is_fenced ?? false,
      fence_type: propertyData.fence_type || ""
    });

    setLoading(false);
  }, [navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const compressImage = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const maxDimension = 1200;
          if (width > height && width > maxDimension) {
            height = (height / width) * maxDimension;
            width = maxDimension;
          } else if (height > maxDimension) {
            width = (width / height) * maxDimension;
            height = maxDimension;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          
          canvas.toBlob((blob) => {
            if (blob) {
              const compressedFile = new File([blob], file.name, {
                type: 'image/jpeg',
                lastModified: Date.now()
              });
              resolve(compressedFile);
            } else {
              reject(new Error("Failed to compress image: Blob is null."));
            }
          }, 'image/jpeg', 0.7); // Quality 0.7
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
    });
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    if (formData.images.length + files.length > 4) {
      alert("You can only upload a maximum of 4 images per property");
      return;
    }

    setUploadingImages(true);

    try {
      const uploadPromises = files.map(async (file) => {
        let fileToUpload = file;
        if (file.size > 200 * 1024) { // 200 KB
          fileToUpload = await compressImage(file);
        }
        const { file_url } = await UploadFile({ file: fileToUpload });
        return file_url;
      });
      
      const imageUrls = await Promise.all(uploadPromises);

      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...imageUrls]
      }));
    } catch (error) {
      console.error("Error uploading images:", error);
      alert("Error uploading images. Please try again.");
    }

    setUploadingImages(false);
  };

  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const handleLocationChange = (lat, lng) => {
    setFormData(prev => ({
      ...prev,
      latitude: lat,
      longitude: lng
    }));
  };

  const geocodeLocationFromDetails = async () => {
    let searchQuery = "";
    
    // Construct search query from available fields, prioritizing specific address
    if (formData.address && formData.address.trim()) {
      searchQuery = [formData.address, formData.neighborhood, formData.city]
        .filter(Boolean)
        .map(s => s.trim())
        .join(', ');
    } else if (formData.neighborhood && formData.neighborhood.trim()) {
      searchQuery = [formData.neighborhood, formData.city]
        .filter(Boolean)
        .map(s => s.trim())
        .join(', ');
    } else if (formData.city && formData.city.trim()) {
      searchQuery = [formData.city]
        .filter(Boolean)
        .map(s => s.trim())
        .join(', ');
    }

    if (!searchQuery) {
      alert("Please enter location details (at least a city) first to find location.");
      return;
    }

    setGeocodingLoading(true); // Use dedicated geocoding loading state
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`
      );
      const data = await response.json();
      
      if (data && data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lon = parseFloat(data[0].lon);
        setFormData(prev => ({
          ...prev,
          latitude: lat,
          longitude: lon
        }));
        alert("Location found! Check the map below. You can refine by dragging the marker.");
      } else {
        alert("Location not found. Please try a different search or click on the map directly.");
      }
    } catch (error) {
      console.error("Geocoding error:", error);
      alert("Error finding location. Please try again.");
    } finally {
      setGeocodingLoading(false);
    }
  };

  const handleCityChange = async (value) => {
    setFormData(prev => ({...prev, city: value}));
    
    if (value.length > 2) {
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(value)}&limit=5&featuretype=city&addressdetails=1`
        );
        const data = await response.json();
        const cities = data.map(item => item.address?.city || item.address?.town || item.address?.village || item.display_name.split(',')[0])
                          .filter(Boolean)
                          .filter((v, i, a) => a.indexOf(v) === i);
        setCitySuggestions(cities);
        setShowCitySuggestions(true);
      } catch (error) {
        console.error("Error fetching city suggestions:", error);
        setShowCitySuggestions(false);
      }
    } else {
      setCitySuggestions([]);
      setShowCitySuggestions(false);
    }
  };

  const handleNeighborhoodChange = async (value) => {
    setFormData(prev => ({...prev, neighborhood: value}));
    
    if (value.length > 2 && formData.city) {
      try {
        const query = `${value}, ${formData.city}`;
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&addressdetails=1`
        );
        const data = await response.json();
        const neighborhoods = data.map(item => item.address?.suburb || item.address?.neighbourhood || item.address?.hamlet || item.display_name.split(',')[0])
                                  .filter(Boolean)
                                  .filter((v, i, a) => a.indexOf(v) === i);
        setNeighborhoodSuggestions(neighborhoods);
        setShowNeighborhoodSuggestions(true);
      } catch (error) {
        console.error("Error fetching neighborhood suggestions:", error);
        setShowNeighborhoodSuggestions(false);
      }
    } else {
      setNeighborhoodSuggestions([]);
      setShowNeighborhoodSuggestions(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const propertyData = {
        ...formData,
        bedrooms: parseInt(formData.bedrooms)
      };

      // Include coordinates if set
      if (formData.latitude && formData.longitude) {
        propertyData.latitude = formData.latitude;
        propertyData.longitude = formData.longitude;
      }

      if (formData.listing_type === "rent") {
        propertyData.rent_amount = parseFloat(formData.rent_amount);
        propertyData.security_deposit = parseFloat(formData.security_deposit);
        delete propertyData.sale_price;
      } else {
        propertyData.sale_price = parseFloat(formData.sale_price);
        delete propertyData.rent_amount;
        delete propertyData.security_deposit;
        delete propertyData.payment_frequency;
        delete propertyData.water_included;
        delete propertyData.electricity_included;
        delete propertyData.garbage_included;
      }

      await Property.update(property.id, propertyData);

      setSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl("MyProperties"));
      }, 2000);
    } catch (error) {
      console.error("Error updating property:", error);
    }

    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const userCurrency = user?.currency || "TZS";

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full border-0 shadow-2xl">
          <CardContent className="pt-6 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Property Updated!</h2>
            <p className="text-slate-600">Your property has been successfully updated.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Edit Property</h1>
        <p className="text-slate-600">Update your property listing details</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="listing_type">Listing Type *</Label>
              <Select
                value={formData.listing_type}
                onValueChange={(value) => setFormData({...formData, listing_type: value})}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rent">For Rent</SelectItem>
                  <SelectItem value="sale">For Sale</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="title">Property Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                placeholder="e.g., Modern 3-Bedroom House in Mikocheni"
                required
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Describe your property in detail"
                className="min-h-32 mt-2"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Location */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <div className="flex items-center justify-between"> {/* Flex container for title and button */}
              <CardTitle>Location Details</CardTitle>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={geocodeLocationFromDetails}
                disabled={geocodingLoading} // Use the new geocoding loading state
                className="gap-2"
              >
                {geocodingLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-600" />
                    Finding...
                  </>
                ) : (
                  <>
                    <MapPin className="w-4 h-4" />
                    Find Location
                  </>
                )}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Label htmlFor="city">City *</Label>
              <Input
                id="city"
                value={formData.city}
                onChange={(e) => handleCityChange(e.target.value)}
                onFocus={() => formData.city.length > 2 && citySuggestions.length > 0 && setShowCitySuggestions(true)}
                onBlur={() => setTimeout(() => setShowCitySuggestions(false), 200)}
                placeholder="Start typing city name..."
                required
                className="mt-2"
                autoComplete="off"
              />
              {showCitySuggestions && citySuggestions.length > 0 && (
                <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {citySuggestions.map((city, index) => (
                    <div
                      key={index}
                      className="px-4 py-2 hover:bg-indigo-50 cursor-pointer transition-colors"
                      onMouseDown={(e) => { // Use onMouseDown to prevent onBlur from firing too soon
                        e.preventDefault(); // Prevent default focus loss behavior
                        setFormData(prev => ({...prev, city: city}));
                        setShowCitySuggestions(false);
                      }}
                    >
                      {city}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="relative">
              <Label htmlFor="neighborhood">Neighborhood / Area</Label>
              <Input
                id="neighborhood"
                value={formData.neighborhood}
                onChange={(e) => handleNeighborhoodChange(e.target.value)}
                onFocus={() => formData.neighborhood.length > 2 && neighborhoodSuggestions.length > 0 && setShowNeighborhoodSuggestions(true)}
                onBlur={() => setTimeout(() => setShowNeighborhoodSuggestions(false), 200)}
                placeholder="e.g., Mikocheni (optional)"
                className="mt-2"
                autoComplete="off"
              />
              {showNeighborhoodSuggestions && neighborhoodSuggestions.length > 0 && (
                <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {neighborhoodSuggestions.map((neighborhood, index) => (
                    <div
                      key={index}
                      className="px-4 py-2 hover:bg-indigo-50 cursor-pointer transition-colors"
                      onMouseDown={(e) => {
                        e.preventDefault();
                        setFormData(prev => ({...prev, neighborhood: neighborhood}));
                        setShowNeighborhoodSuggestions(false);
                      }}
                    >
                      {neighborhood}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="address">Full Address / Location</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="e.g., Plot 123, Mikocheni Street, near Shoppers Plaza\nOr just describe landmarks and nearby places"
                className="mt-2 h-20"
              />
            </div>
          </CardContent>
        </Card>

        {/* Location Map */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Map Location</CardTitle>
            <p className="text-sm text-slate-500">
              Pin your property's precise location on the map. You can drag the marker to adjust.
            </p>
          </CardHeader>
          <CardContent>
            <LocationMap
              latitude={formData.latitude}
              longitude={formData.longitude}
              city={formData.city}
              neighborhood={formData.neighborhood}
              address={formData.address}
              onLocationChange={handleLocationChange}
              editable={true}
            />
          </CardContent>
        </Card>

        {/* Property Images */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Property Images (Maximum 4)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {formData.images.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {formData.images.map((image, index) => (
                    <div key={index} className="relative group">
                      <img 
                        src={image} 
                        alt={`Property ${index + 1}`} 
                        className="w-full h-32 object-cover rounded-lg border-2 border-slate-200" 
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                        onClick={() => removeImage(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <div>
                <Label htmlFor="images" className="cursor-pointer">
                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-12 text-center hover:border-indigo-400 hover:bg-indigo-50/50 transition-all">
                    {uploadingImages ? (
                      <>
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4" />
                        <p className="text-sm text-slate-600">Uploading and compressing images...</p>
                      </>
                    ) : (
                      <>
                        <ImageIcon className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                        <p className="text-slate-600 font-medium mb-1">Click to upload more images</p>
                        <p className="text-xs text-slate-500">
                          PNG, JPG. Maximum 4 images. Files over 200KB will be auto-compressed.
                        </p>
                        <p className="text-xs text-indigo-600 font-semibold mt-2">
                          {formData.images.length} of 4 images uploaded
                        </p>
                      </>
                    )}
                  </div>
                </Label>
                <Input
                  id="images"
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={uploadingImages || formData.images.length >= 4}
                />
                {formData.images.length >= 4 && (
                  <p className="text-sm text-orange-600 mt-2 font-semibold">Maximum of 4 images reached</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Property Details */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Property Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="bedrooms">Number of Bedrooms *</Label>
              <Select
                value={formData.bedrooms}
                onValueChange={(value) => setFormData({...formData, bedrooms: value})}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Studio</SelectItem>
                  <SelectItem value="1">1 Bedroom</SelectItem>
                  <SelectItem value="2">2 Bedrooms</SelectItem>
                  <SelectItem value="3">3 Bedrooms</SelectItem>
                  <SelectItem value="4">4 Bedrooms</SelectItem>
                  <SelectItem value="5">5+ Bedrooms</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-base font-semibold mb-3 block">Additional Rooms</Label>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="kitchen"
                    checked={formData.has_kitchen}
                    onCheckedChange={(checked) => setFormData({...formData, has_kitchen: checked})}
                  />
                  <Label htmlFor="kitchen" className="cursor-pointer font-normal">Kitchen</Label>
                </div>
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="dining"
                    checked={formData.has_dining}
                    onCheckedChange={(checked) => setFormData({...formData, has_dining: checked})}
                  />
                  <Label htmlFor="dining" className="cursor-pointer font-normal">Dining Room</Label>
                </div>
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="study"
                    checked={formData.has_study}
                    onCheckedChange={(checked) => setFormData({...formData, has_study: checked})}
                  />
                  <Label htmlFor="study" className="cursor-pointer font-normal">Study Room</Label>
                </div>
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="garage"
                    checked={formData.has_garage}
                    onCheckedChange={(checked) => setFormData({...formData, has_garage: checked})}
                  />
                  <Label htmlFor="garage" className="cursor-pointer font-normal">Garage/Parking</Label>
                </div>
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="garden"
                    checked={formData.has_garden}
                    onCheckedChange={(checked) => setFormData({...formData, has_garden: checked})}
                  />
                  <Label htmlFor="garden" className="cursor-pointer font-normal">Garden/Yard</Label>
                </div>
              </div>
            </div>

            {formData.listing_type === "rent" && (
              <div>
                <Label className="text-base font-semibold mb-3 block">Utilities Included in Rent</Label>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="water"
                      checked={formData.water_included}
                      onCheckedChange={(checked) => setFormData({...formData, water_included: checked})}
                    />
                    <Label htmlFor="water" className="cursor-pointer font-normal">Water Bill</Label>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="electricity"
                      checked={formData.electricity_included}
                      onCheckedChange={(checked) => setFormData({...formData, electricity_included: checked})}
                    />
                    <Label htmlFor="electricity" className="cursor-pointer font-normal">Electricity Bill</Label>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="garbage"
                      checked={formData.garbage_included}
                      onCheckedChange={(checked) => setFormData({...formData, garbage_included: checked})}
                    />
                    <Label htmlFor="garbage" className="cursor-pointer font-normal">Garbage Collection</Label>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="fenced"
                  checked={formData.is_fenced}
                  onCheckedChange={(checked) => setFormData({...formData, is_fenced: checked})}
                />
                <Label htmlFor="fenced" className="cursor-pointer font-normal">Property is Fenced</Label>
              </div>

              {formData.is_fenced && (
                <div className="ml-6">
                  <Label htmlFor="fence_type">Fence Type</Label>
                  <Select
                    value={formData.fence_type}
                    onValueChange={(value) => setFormData({...formData, fence_type: value})}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select fence type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="wall">Wall Fence</SelectItem>
                      <SelectItem value="wood">Wood Fence</SelectItem>
                      <SelectItem value="wire">Wire Fence</SelectItem>
                      <SelectItem value="mixed">Mixed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Payment/Price Terms */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>
              {formData.listing_type === "rent" ? "Payment Terms" : "Sale Price"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {formData.listing_type === "rent" ? (
              <>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="rent">Monthly Rent Amount ({userCurrency}) *</Label>
                    <Input
                      id="rent"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.rent_amount}
                      onChange={(e) => setFormData({...formData, rent_amount: e.target.value})}
                      placeholder="e.g., 500000"
                      required
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="deposit">Security Deposit ({userCurrency}) *</Label>
                    <Input
                      id="deposit"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.security_deposit}
                      onChange={(e) => setFormData({...formData, security_deposit: e.target.value})}
                      placeholder="e.g., 1000000"
                      required
                      className="mt-2"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="frequency">Payment Frequency</Label>
                  <Select
                    value={formData.payment_frequency}
                    onValueChange={(value) => setFormData({...formData, payment_frequency: value})}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="bi-monthly">Bi-Monthly (2 months)</SelectItem>
                      <SelectItem value="quarterly">Quarterly (3 months)</SelectItem>
                      <SelectItem value="semi-annual">Semi-Annual (6 months)</SelectItem>
                      <SelectItem value="annual">Annual (12 months)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            ) : (
              <div>
                <Label htmlFor="sale_price">Sale Price ({userCurrency}) *</Label>
                <Input
                  id="sale_price"
                  type="number"
                  min="0"
                  step="any"
                  value={formData.sale_price}
                  onChange={(e) => setFormData({...formData, sale_price: e.target.value})}
                  placeholder="e.g., 150000000"
                  required
                  className="mt-2"
                />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Submit Buttons */}
        <div className="flex justify-end gap-4 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate(createPageUrl("MyProperties"))}
            disabled={submitting || geocodingLoading}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={submitting || uploadingImages || geocodingLoading}
            className="bg-indigo-600 hover:bg-indigo-700 px-8"
          >
            {submitting ? "Updating..." : "Update Property"}
          </Button>
        </div>
      </form>
    </div>
  );
}
