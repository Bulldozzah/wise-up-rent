
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Feedback } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { MessageSquare, Eye, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ViewFeedback() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [feedbacks, setFeedbacks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const [adminNotes, setAdminNotes] = useState("");
  const [updatingStatus, setUpdatingStatus] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      if (currentUser.account_type !== "admin") {
        navigate(createPageUrl("Home"));
        return;
      }

      const allFeedbacks = await Feedback.list("-created_date");
      setFeedbacks(allFeedbacks);
      setLoading(false);
    } catch (error) {
      console.error("Error loading data:", error);
      navigate(createPageUrl("Home"));
    }
  }, [navigate]); // navigate is a dependency of useCallback

  useEffect(() => {
    loadData();
  }, [loadData]); // loadData is a dependency of useEffect

  const handleStatusChange = async (feedbackId, newStatus) => {
    setUpdatingStatus(true);
    try {
      await Feedback.update(feedbackId, { status: newStatus });
      await loadData();
      if (selectedFeedback?.id === feedbackId) {
        setSelectedFeedback({ ...selectedFeedback, status: newStatus });
      }
    } catch (error) {
      console.error("Error updating status:", error);
      alert("Error updating status. Please try again.");
    }
    setUpdatingStatus(false);
  };

  const handleSaveNotes = async () => {
    if (!selectedFeedback) return;

    setUpdatingStatus(true);
    try {
      await Feedback.update(selectedFeedback.id, { admin_notes: adminNotes });
      await loadData();
      alert("Notes saved successfully!");
    } catch (error) {
      console.error("Error saving notes:", error);
      alert("Error saving notes. Please try again.");
    }
    setUpdatingStatus(false);
  };

  const openFeedbackDialog = (feedback) => {
    setSelectedFeedback(feedback);
    setAdminNotes(feedback.admin_notes || "");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const pendingCount = feedbacks.filter(f => f.status === "pending").length;
  const inProgressCount = feedbacks.filter(f => f.status === "in_progress").length;
  const resolvedCount = feedbacks.filter(f => f.status === "resolved").length;

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Feedback & Enquiries</h1>
        <p className="text-slate-600">Manage customer feedback and support requests</p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Pending</p>
                <p className="text-3xl font-bold text-orange-600">{pendingCount}</p>
              </div>
              <Clock className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">In Progress</p>
                <p className="text-3xl font-bold text-blue-600">{inProgressCount}</p>
              </div>
              <AlertCircle className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Resolved</p>
                <p className="text-3xl font-bold text-green-600">{resolvedCount}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Feedbacks Table */}
      <Card className="border-0 shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            All Feedback ({feedbacks.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {feedbacks.length === 0 ? (
            <div className="text-center py-12">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <p className="text-slate-600">No feedback submitted yet</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {feedbacks.map((feedback) => (
                  <TableRow key={feedback.id}>
                    <TableCell>
                      {format(new Date(feedback.created_date), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell className="font-medium">{feedback.user_name}</TableCell>
                    <TableCell>{feedback.user_email}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {feedback.feedback_type.replace('_', ' ')}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-xs truncate">{feedback.subject}</TableCell>
                    <TableCell>
                      <Select
                        value={feedback.status}
                        onValueChange={(value) => handleStatusChange(feedback.id, value)}
                        disabled={updatingStatus}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-orange-500" />
                              Pending
                            </div>
                          </SelectItem>
                          <SelectItem value="in_progress">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-blue-500" />
                              In Progress
                            </div>
                          </SelectItem>
                          <SelectItem value="resolved">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-green-500" />
                              Resolved
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openFeedbackDialog(feedback)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>Feedback Details</DialogTitle>
                          </DialogHeader>
                          
                          {selectedFeedback && (
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label className="text-slate-500 text-sm">Name</Label>
                                  <p className="font-medium">{selectedFeedback.user_name}</p>
                                </div>
                                <div>
                                  <Label className="text-slate-500 text-sm">Email</Label>
                                  <p className="font-medium">{selectedFeedback.user_email}</p>
                                </div>
                                {selectedFeedback.phone && (
                                  <div>
                                    <Label className="text-slate-500 text-sm">Phone</Label>
                                    <p className="font-medium">{selectedFeedback.phone}</p>
                                  </div>
                                )}
                                <div>
                                  <Label className="text-slate-500 text-sm">Type</Label>
                                  <p className="font-medium capitalize">
                                    {selectedFeedback.feedback_type.replace('_', ' ')}
                                  </p>
                                </div>
                                <div>
                                  <Label className="text-slate-500 text-sm">Status</Label>
                                  <Badge className={`mt-1 ${
                                    selectedFeedback.status === "pending" ? "bg-orange-500" :
                                    selectedFeedback.status === "in_progress" ? "bg-blue-500" :
                                    "bg-green-500"
                                  }`}>
                                    {selectedFeedback.status.replace('_', ' ')}
                                  </Badge>
                                </div>
                                <div>
                                  <Label className="text-slate-500 text-sm">Submitted</Label>
                                  <p className="font-medium">
                                    {format(new Date(selectedFeedback.created_date), "PPpp")}
                                  </p>
                                </div>
                              </div>

                              <div>
                                <Label className="text-slate-500 text-sm">Subject</Label>
                                <p className="font-medium mt-1">{selectedFeedback.subject}</p>
                              </div>

                              <div>
                                <Label className="text-slate-500 text-sm">Message</Label>
                                <div className="mt-1 p-4 bg-slate-50 rounded-lg">
                                  <p className="whitespace-pre-wrap">{selectedFeedback.message}</p>
                                </div>
                              </div>

                              <div>
                                <Label htmlFor="admin_notes">Admin Notes</Label>
                                <Textarea
                                  id="admin_notes"
                                  value={adminNotes}
                                  onChange={(e) => setAdminNotes(e.target.value)}
                                  placeholder="Add notes for internal reference..."
                                  className="mt-2 min-h-24"
                                />
                                <Button
                                  onClick={handleSaveNotes}
                                  disabled={updatingStatus}
                                  className="mt-2 bg-indigo-600 hover:bg-indigo-700"
                                >
                                  {updatingStatus ? "Saving..." : "Save Notes"}
                                </Button>
                              </div>
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
