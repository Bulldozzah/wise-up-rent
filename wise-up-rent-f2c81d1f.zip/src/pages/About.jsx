
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Target, CheckCircle, MapPin, Phone, Mail } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-indigo-700 text-white py-20">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68dbd0d5777db8b9f2c81d1f/d583bab4e_logoWUR.png" 
            alt="WiseUpRent Logo" 
            className="w-24 h-24 mx-auto mb-6 object-contain"
          />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About WiseUp-Rent</h1>
          <p className="text-2xl text-blue-100 font-medium">Simply Find It.</p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12 space-y-8">
        {/* Introduction */}
        <Card className="border-0 shadow-xl">
          <CardContent className="p-8">
            <p className="text-lg text-slate-700 leading-relaxed">
              We are a Lusaka-based digital marketplace designed to make it easier for people in Zambia to rent, buy, or hire. From houses and apartments to plots, vehicles, furniture, and everyday items, WiseUp-Rent helps you connect with trusted landlords, agents, and vendors in just a few clicks.
            </p>
          </CardContent>
        </Card>

        {/* Our Mission */}
        <Card className="border-0 shadow-xl">
          <CardContent className="p-8">
            <div className="flex items-center gap-3 mb-4">
              <Target className="w-8 h-8 text-indigo-600" />
              <h2 className="text-3xl font-bold text-slate-900">Our Mission</h2>
            </div>
            <p className="text-lg text-slate-700 leading-relaxed">
              To simplify the way Zambians search, connect, and transact by providing a secure and transparent platform where you can <span className="font-semibold text-indigo-600">Simply Find It</span>.
            </p>
          </CardContent>
        </Card>

        {/* What We Offer */}
        <Card className="border-0 shadow-xl">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-6">What We Offer</h2>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-1">Property Listings</h3>
                  <p className="text-slate-600">Rent or buy houses, apartments, commercial spaces, and plots.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-1">Items for Hire</h3>
                  <p className="text-slate-600">Vehicles, tools, furniture, event equipment, and more.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-1">Smart Search & Filters</h3>
                  <p className="text-slate-600">Quickly discover what matches your needs.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-1">Vendor Tools</h3>
                  <p className="text-slate-600">Easy listing management for landlords and vendors.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-1">Safe & Reliable Connections</h3>
                  <p className="text-slate-600">Verified vendors, clear communication, and payment options.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Why Choose Us */}
        <Card className="border-0 shadow-xl bg-gradient-to-br from-indigo-50 to-blue-50">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Why Choose Us?</h2>
            <p className="text-lg text-slate-700 leading-relaxed">
              WiseUp-Rent is built with the Zambian market in mind. Whether you're in Lusaka or anywhere across the country, our platform makes it easier to browse, connect, and close deals. With our motto, <span className="font-semibold text-indigo-600">Simply Find It</span>, we promise a stress-free experience every time.
            </p>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card className="border-0 shadow-xl">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Get In Touch</h2>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <p className="font-semibold text-slate-900">Location</p>
                  <p className="text-slate-600">Lusaka, Zambia</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Phone className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-slate-900">Phone</p>
                  <a href="tel:+260973433321" className="text-slate-600 hover:text-indigo-600">
                    +260 973 433 321
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Mail className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="font-semibold text-slate-900">Email</p>
                  <a href="mailto:wiseuprent@gmail.com" className="text-slate-600 hover:text-indigo-600">
                    wiseuprent@gmail.com
                  </a>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
