
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Listing } from "@/api/entities";
import { Property } from "@/api/entities";
import { VendorRequest } from "@/api/entities";
import { Ad } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Building2, Search, Star, Home as HomeIcon, UserPlus, Clock, Eye, MapPin, Bed, ArrowRight, AlertCircle, Users, Shield, PlusCircle, Package, ExternalLink } from "lucide-react";

export default function HomePage() {
  const [user, setUser] = useState(null);
  const [listings, setListings] = useState([]);
  const [properties, setProperties] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [needsProfile, setNeedsProfile] = useState(false);
  const [daysRemaining, setDaysRemaining] = useState(null);
  const [activeAd, setActiveAd] = useState(null);

  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const handleRenewSubscription = () => {
    navigate(createPageUrl("BecomeVendor?action=renew"));
  };

  const loadData = async () => {
    const currentUser = await User.me();
    
    if (!currentUser.account_type) {
      await User.updateMyUserData({ account_type: "tenant" });
      currentUser.account_type = "tenant";
    }
    
    setUser(currentUser);

    if (!currentUser.phone || !currentUser.whatsapp) {
      setNeedsProfile(true);
    }

    // Load active ad
    const ads = await Ad.filter({ is_active: true }, "-created_date", 1);
    if (ads.length > 0) {
      setActiveAd(ads[0]);
    }

    if (currentUser.account_type === "vendor" && currentUser.subscription_end_date) {
      const now = new Date();
      const endDate = new Date(currentUser.subscription_end_date);
      const diffTime = endDate - now;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setDaysRemaining(diffDays);
    }

    if (currentUser.account_type === "vendor") {
      const [myListings, myProperties] = await Promise.all([
        Listing.filter({ owner_id: currentUser.id }, "-created_date"),
        Property.filter({ vendor_id: currentUser.id }, "-created_date")
      ]);
      
      setListings(myListings);
      setProperties(myProperties);
      
      const allListings = [...myListings, ...myProperties];
      setStats({
        total: allListings.length,
        available: allListings.filter(p => p.status === "available").length,
        views: allListings.reduce((sum, p) => sum + (p.views || 0), 0)
      });
    } else if (currentUser.account_type === "admin") {
      const [allListings, allProperties, requests, allUsers] = await Promise.all([
        Listing.list("-created_date"),
        Property.list("-created_date"),
        VendorRequest.filter({ status: "pending" }),
        User.list()
      ]);
      
      const combinedListings = [...allListings, ...allProperties];
      setListings(allListings.slice(0, 3));
      setProperties(allProperties.slice(0, 3));
      
      setStats({
        listings: combinedListings.length,
        pending: requests.length,
        users: allUsers.length,
        vendors: allUsers.filter(u => u.account_type === "vendor").length
      });
    } else {
      const [availableListings, availableProperties] = await Promise.all([
        Listing.filter({ status: "available" }, "-created_date", 3),
        Property.filter({ status: "available" }, "-created_date", 3)
      ]);
      
      setListings(availableListings);
      setProperties(availableProperties);
      setStats({
        available: availableListings.length + availableProperties.length
      });
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
          Welcome, {user.full_name} 👋
        </h1>
        <p className="text-slate-600 text-lg">
          {user.account_type === "tenant" && "Find anything you need to rent"}
          {user.account_type === "vendor" && "Manage your listings"}
          {user.account_type === "admin" && "Platform overview"}
        </p>
        
        {/* Simple subscription text for vendors - not prominent */}
        {user.account_type === "vendor" && daysRemaining !== null && daysRemaining <= 5 && daysRemaining > 0 && (
          <p className="text-sm text-slate-500 mt-2">
            Your subscription expires in {daysRemaining} {daysRemaining === 1 ? 'day' : 'days'}.
          </p>
        )}
      </div>

      {needsProfile && (
        <Alert className="mb-6 border-orange-200 bg-orange-50">
          <AlertCircle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-900 flex items-center justify-between">
            <span>Complete your profile to connect with others</span>
            <Link to={createPageUrl("Profile")}>
              <Button size="sm" className="bg-orange-600 hover:bg-orange-700 ml-4">
                Complete Profile
              </Button>
            </Link>
          </AlertDescription>
        </Alert>
      )}

      {/* Ad Banner */}
      {activeAd && (
        <Card className="mb-6 border-0 shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer bg-gradient-to-r from-slate-50 to-slate-100">
          <a href={activeAd.link_url} target="_blank" rel="noopener noreferrer" className="block">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                {activeAd.image_url && (
                  <img 
                    src={activeAd.image_url} 
                    alt={activeAd.title} 
                    className="w-16 h-16 object-contain rounded-lg"
                  />
                )}
                <div className="flex-1">
                  <p className="text-lg font-semibold text-slate-900">{activeAd.title}</p>
                </div>
                <ExternalLink className="w-5 h-5 text-slate-600" />
              </div>
            </CardContent>
          </a>
        </Card>
      )}

      {/* Tenant View */}
      {user.account_type === "tenant" && (
        <>
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Link to={createPageUrl("Browse")}>
              <Card className="border shadow-md hover:shadow-lg transition-all group cursor-pointer h-full bg-white">
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-14 h-14 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                      <Building2 className="w-7 h-7 text-slate-700" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-900">Browse Properties</h3>
                      <p className="text-sm text-slate-600">Houses, apartments & spaces</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700 font-medium">
                    <span>Start Searching</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link to={createPageUrl("BrowseItems")}>
              <Card className="border shadow-md hover:shadow-lg transition-all group cursor-pointer h-full bg-white">
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-14 h-14 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                      <Package className="w-7 h-7 text-slate-700" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-900">Browse Items</h3>
                      <p className="text-sm text-slate-600">Vehicles, equipment & more</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700 font-medium">
                    <span>Explore Items</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>

          <Card className="border shadow-md mb-6 bg-white">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-2xl">Featured Listings</CardTitle>
                <div className="flex gap-2">
                  <Link to={createPageUrl("Browse")}>
                    <Button variant="outline" size="sm" className="border-slate-300">Properties</Button>
                  </Link>
                  <Link to={createPageUrl("BrowseItems")}>
                    <Button variant="outline" size="sm" className="border-slate-300">Items</Button>
                  </Link>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {[...properties, ...listings].length === 0 ? (
                <div className="text-center py-16">
                  <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">No Listings Yet</h3>
                  <p className="text-slate-600">Check back soon for new listings!</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-3 gap-6">
                  {[...properties, ...listings].slice(0, 6).map((listing) => {
                    const isProperty = listing.bedrooms !== undefined;
                    const linkUrl = isProperty 
                      ? createPageUrl(`Property?id=${listing.id}`)
                      : createPageUrl(`Listing?id=${listing.id}`);
                    
                    return (
                      <Link key={listing.id} to={linkUrl}>
                        <Card className="border shadow-md hover:shadow-lg transition-all cursor-pointer transform hover:-translate-y-1 overflow-hidden h-full">
                          <div className="relative h-48 bg-slate-200">
                            {listing.images?.[0] ? (
                              <img src={listing.images[0]} alt={listing.title} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <Building2 className="w-12 h-12 text-slate-400" />
                              </div>
                            )}
                            <Badge className="absolute top-3 right-3 bg-green-600 shadow-lg">Available</Badge>
                          </div>
                          <CardContent className="p-4">
                            <h3 className="font-bold text-lg mb-2 line-clamp-1">{listing.title}</h3>
                            <div className="flex items-center gap-2 text-slate-600 mb-3 text-sm">
                              <MapPin className="w-4 h-4" />
                              <span className="line-clamp-1">{listing.city}</span>
                            </div>
                            <div className="flex items-center justify-between pt-3 border-t">
                              <div>
                                <span className="font-bold text-xl text-slate-900">
                                  {user?.currency || "TZS"} {listing.listing_type === "rent"
                                    ? listing.rent_amount?.toLocaleString()
                                    : listing.sale_price?.toLocaleString()
                                  }
                                </span>
                                <div className="text-xs text-slate-500">
                                  {listing.listing_type === "rent" && "/mo"}
                                </div>
                              </div>
                              {isProperty && listing.bedrooms && (
                                <div className="flex items-center gap-1 text-slate-600">
                                  <Bed className="w-4 h-4" />
                                  <span className="text-sm">{listing.bedrooms}</span>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Link to={createPageUrl("BecomeVendor")}>
            <Card className="border shadow-md hover:shadow-lg transition-all cursor-pointer bg-white">
              <CardContent className="p-8 text-center">
                <img src="/WiseUpRent-logo.png" alt="WiseUpRent Logo" className="w-12 h-12 object-contain mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Become a Vendor</h3>
                <p className="text-slate-600 mb-4">List your items and properties to earn income</p>
                <div className="flex items-center justify-center gap-2 text-slate-700 font-semibold">
                  <span>Apply Now</span>
                  <ArrowRight className="w-5 h-5" />
                </div>
              </CardContent>
            </Card>
          </Link>
        </>
      )}

      {/* Vendor View */}
      {user.account_type === "vendor" && (
        <>
          {/* Check if subscription is expired */}
          {daysRemaining !== null && daysRemaining <= 0 && (
            <Card className="border-2 border-red-200 bg-red-50 shadow-xl mb-6">
              <CardContent className="p-6 text-center">
                <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-red-900 mb-2">Subscription Expired</h3>
                <p className="text-red-800 mb-4">
                  Your subscription expired {Math.abs(daysRemaining)} days ago. 
                  Renew now to continue listing properties and items.
                </p>
                <Button 
                  className="bg-red-600 hover:bg-red-700"
                  onClick={handleRenewSubscription}
                >
                  Renew Subscription
                </Button>
              </CardContent>
            </Card>
          )}

          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <Link 
              to={createPageUrl("AddProperty")} 
              className={daysRemaining !== null && daysRemaining <= 0 ? "pointer-events-none" : ""}
            >
              <Card className={`border shadow-md hover:shadow-lg transition-all group cursor-pointer h-full bg-white ${
                daysRemaining !== null && daysRemaining <= 0 ? "opacity-50" : ""
              }`}>
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-14 h-14 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                      <Building2 className="w-7 h-7 text-slate-700" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-900">Add Property</h3>
                      <p className="text-sm text-slate-600">List a house or apartment</p>
                    </div>
                  </div>
                  {daysRemaining !== null && daysRemaining <= 0 && (
                    <p className="text-xs text-red-600">Renew subscription to add properties</p>
                  )}
                </CardContent>
              </Card>
            </Link>

            <Link 
              to={createPageUrl("AddItem")} 
              className={daysRemaining !== null && daysRemaining <= 0 ? "pointer-events-none" : ""}
            >
              <Card className={`border shadow-md hover:shadow-lg transition-all group cursor-pointer h-full bg-white ${
                daysRemaining !== null && daysRemaining <= 0 ? "opacity-50" : ""
              }`}>
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-14 h-14 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                      <Package className="w-7 h-7 text-slate-700" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-900">Add Item</h3>
                      <p className="text-sm text-slate-600">List vehicles, equipment, etc.</p>
                    </div>
                  </div>
                  {daysRemaining !== null && daysRemaining <= 0 && (
                    <p className="text-xs text-red-600">Renew subscription to add items</p>
                  )}
                </CardContent>
              </Card>
            </Link>
          </div>

          <Link to={createPageUrl("MyListings")}>
            <Card className="border shadow-md hover:shadow-lg transition-all cursor-pointer bg-white group">
              <CardContent className="p-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                    <Building2 className="w-7 h-7 text-slate-700" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-slate-900">View My Listings</h3>
                    <p className="text-slate-600 text-sm">Manage all your properties and items</p>
                  </div>
                </div>
                <ArrowRight className="w-6 h-6 text-slate-400 group-hover:text-slate-700 group-hover:translate-x-1 transition-all" />
              </CardContent>
            </Card>
          </Link>
        </>
      )}

      {/* Admin View */}
      {user.account_type === "admin" && (
        <>
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="border shadow-md bg-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm text-slate-600 font-medium">Total Listings</span>
                  <Building2 className="w-5 h-5 text-slate-600" />
                </div>
                <div className="text-4xl font-bold text-slate-900">{stats.listings}</div>
              </CardContent>
            </Card>

            <Card className="border shadow-md bg-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm text-slate-600 font-medium">Pending</span>
                  <Clock className="w-5 h-5 text-slate-600" />
                </div>
                <div className="text-4xl font-bold text-slate-900">{stats.pending}</div>
              </CardContent>
            </Card>

            <Card className="border shadow-md bg-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm text-slate-600 font-medium">Users</span>
                  <Users className="w-5 h-5 text-slate-600" />
                </div>
                <div className="text-4xl font-bold text-slate-900">{stats.users}</div>
              </CardContent>
            </Card>

            <Card className="border shadow-md bg-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm text-slate-600 font-medium">Vendors</span>
                  <HomeIcon className="w-5 h-5 text-slate-600" />
                </div>
                <div className="text-4xl font-bold text-slate-900">{stats.vendors}</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Link to={createPageUrl("AdminPanel")}>
              <Card className="border shadow-md hover:shadow-lg transition-all cursor-pointer bg-white group">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-3">
                    <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                      <Shield className="w-6 h-6 text-slate-700" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Admin Panel</h3>
                  <p className="text-slate-600 text-sm">Manage requests and listings</p>
                </CardContent>
              </Card>
            </Link>

            <Link to={createPageUrl("Users")}>
              <Card className="border shadow-md hover:shadow-lg transition-all cursor-pointer bg-white group">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-3">
                    <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                      <Users className="w-6 h-6 text-slate-700" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">User Management</h3>
                  <p className="text-slate-600 text-sm">Manage user roles</p>
                </CardContent>
              </Card>
            </Link>

            <Link to={createPageUrl("ManageAds")}>
              <Card className="border shadow-md hover:shadow-lg transition-all cursor-pointer bg-white group">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-3">
                    <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                      <ExternalLink className="w-6 h-6 text-slate-700" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Manage Ads</h3>
                  <p className="text-slate-600 text-sm">Add and manage ad banners</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
