
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Property } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, X, ImageIcon, MapPin, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import LocationMap from "../components/property/LocationMap";
import { Separator } from "@/components/ui/separator";

export default function AddProperty() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [isFindingLocation, setIsFindingLocation] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [propertyId, setPropertyId] = useState(null);

  const [countrySuggestions, setCountrySuggestions] = useState([]);
  const [stateSuggestions, setStateSuggestions] = useState([]);
  const [citySuggestions, setCitySuggestions] = useState([]);
  const [neighborhoodSuggestions, setNeighborhoodSuggestions] = useState([]);
  const [showCountrySuggestions, setShowCountrySuggestions] = useState(false);
  const [showStateSuggestions, setShowStateSuggestions] = useState(false);
  const [showCitySuggestions, setShowCitySuggestions] = useState(false);
  const [showNeighborhoodSuggestions, setShowNeighborhoodSuggestions] = useState(false);

  const [locationInputMethod, setLocationInputMethod] = useState("location_details");
  const [fullAddressInput, setFullAddressInput] = useState("");
  const [parsingAddress, setParsingAddress] = useState(false);
  const [parsingStreetAddress, setParsingStreetAddress] = useState(false); // New state for street address parsing
  const [autoGeocodingDone, setAutoGeocodingDone] = useState(false);


  const [formData, setFormData] = useState({
    title: "",
    description: "",
    listing_type: "rent",
    property_type: "residential", // New field
    property_subtype: "", // New field
    country: "",
    state: "",
    city: "",
    neighborhood: "",
    address: "",
    latitude: null,
    longitude: null,
    images: [],
    rent_amount: "",
    sale_price: "",
    security_deposit: "",
    payment_frequency: "monthly",
    
    // Residential fields
    bedrooms: "1",
    bathrooms: "1",
    kitchen_type: "modern",
    has_living_room: true,
    has_dining_room: false,
    has_yard_garden: false,
    yard_fenced: false,
    parking_type: "none",
    parking_spaces: "0",
    has_balcony: false,
    property_size: "",
    size_unit: "sqm",
    water_supply: "municipal",
    electricity_supply: "grid",
    furnishing_status: "unfurnished",
    security_features: [],
    pet_friendly: false,
    
    // Commercial fields
    floor_size: "",
    number_of_units: "",
    location_features: [],
    parking_capacity: "",
    has_internet: false,
    property_condition: "good",
    usage_type: "office",
    
    // Land fields
    land_type: "residential",
    topography: "flat",
    road_access: "paved",
    has_title_deed: false,
    
    // Hospitality fields
    number_of_rooms: "",
    room_types: [],
    facilities: [],
    occupancy_rate: "",
    has_licenses: false,
    license_details: "",
    
    // Parking/Misc fields
    is_covered: false,
    accessibility_features: []
  });

  const propertySubtypes = {
    residential: [
      { value: "house", label: "House (standalone, bungalow, villa)" },
      { value: "townhouse", label: "Townhouse" },
      { value: "apartment", label: "Flat / Apartment" },
      { value: "serviced_apartment", label: "Serviced Apartment" },
      { value: "room", label: "Room (single, shared)" },
      { value: "student_housing", label: "Student Housing / Hostel" },
      { value: "holiday_home", label: "Holiday Home / Lodge / Guesthouse" }
    ],
    commercial: [
      { value: "office", label: "Office" },
      { value: "office_suite", label: "Office Suite" },
      { value: "coworking_space", label: "Coworking Space" },
      { value: "shop", label: "Shop / Retail Outlet" },
      { value: "warehouse", label: "Warehouse / Storage Unit" },
      { value: "industrial", label: "Industrial Building / Factory" },
      { value: "restaurant", label: "Restaurant / Café / Bar" }
    ],
    land: [
      { value: "residential_plot", label: "Residential Plot" },
      { value: "commercial_plot", label: "Commercial Plot" },
      { value: "agricultural_land", label: "Agricultural Land / Farm" },
      { value: "vacant_land", label: "Vacant Land / Bare Land" },
      { value: "open_space", label: "Open Space / Yard" }
    ],
    hospitality: [
      { value: "hotel", label: "Hotel / Motel / Lodge" },
      { value: "conference_hall", label: "Conference Hall / Event Venue" },
      { value: "short_stay", label: "Furnished Short-Stay Rental" }
    ],
    parking_misc: [
      { value: "garage", label: "Garage / Carport" },
      { value: "parking_space", label: "Parking Space" },
      { value: "shade", label: "Shade / Stall / Kiosk" }
    ]
  };

  const loadUser = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Debug: Log user info
      console.log("Current user in AddProperty:", {
        id: currentUser.id,
        email: currentUser.email,
        account_type: currentUser.account_type
      });
      
      if (currentUser.account_type !== "vendor" && currentUser.account_type !== "admin") {
        navigate(createPageUrl("Dashboard"));
        return;
      }

      // Check if vendor subscription is expired (skip for admin)
      if (currentUser.account_type === "vendor") {
        const isExpired = currentUser.subscription_end_date && 
          new Date(currentUser.subscription_end_date) < new Date();
        
        if (isExpired) {
          navigate(createPageUrl("Dashboard")); // Navigate to dashboard if subscription is expired
          return;
        }
      }
      
      // Check if editing existing property
      const urlParams = new URLSearchParams(window.location.search);
      const id = urlParams.get("id");
      
      if (id) {
        setIsEditMode(true);
        setPropertyId(id);
        
        // Load existing property
        const property = await Property.get(id);
        
        // Check if user owns this property or is admin
        if (property.vendor_id !== currentUser.id && currentUser.account_type !== "admin") {
          alert("You don't have permission to edit this property");
          navigate(createPageUrl("MyListings"));
          return;
        }
        
        // Populate form with existing data
        setFormData({
          title: property.title || "",
          description: property.description || "",
          listing_type: property.listing_type || "rent",
          property_type: property.property_type || "residential", // Set existing property type
          property_subtype: property.property_subtype || "",     // Set existing property subtype
          country: property.country || "",
          state: property.state || "",
          city: property.city || "",
          neighborhood: property.neighborhood || "",
          address: property.address || "",
          latitude: property.latitude || null,
          longitude: property.longitude || null,
          images: property.images || [],
          rent_amount: property.rent_amount?.toString() || "",
          sale_price: property.sale_price?.toString() || "",
          security_deposit: property.security_deposit?.toString() || "",
          payment_frequency: property.payment_frequency || "monthly",
          
          // Residential fields
          bedrooms: property.bedrooms?.toString() || "1",
          bathrooms: property.bathrooms?.toString() || "1",
          kitchen_type: property.kitchen_type || "modern",
          has_living_room: property.has_living_room ?? true,
          has_dining_room: property.has_dining_room ?? false,
          has_yard_garden: property.has_yard_garden ?? false,
          yard_fenced: property.yard_fenced ?? false,
          parking_type: property.parking_type || "none",
          parking_spaces: property.parking_spaces?.toString() || "0",
          has_balcony: property.has_balcony ?? false,
          property_size: property.property_size?.toString() || "",
          size_unit: property.size_unit || "sqm",
          water_supply: property.water_supply || "municipal",
          electricity_supply: property.electricity_supply || "grid",
          furnishing_status: property.furnishing_status || "unfurnished",
          security_features: property.security_features || [],
          pet_friendly: property.pet_friendly ?? false,
          
          // Commercial fields
          floor_size: property.floor_size?.toString() || "",
          number_of_units: property.number_of_units?.toString() || "",
          location_features: property.location_features || [],
          parking_capacity: property.parking_capacity?.toString() || "",
          has_internet: property.has_internet ?? false,
          property_condition: property.property_condition || "good",
          usage_type: property.usage_type || "office",
          
          // Land fields
          land_type: property.land_type || "residential",
          topography: property.topography || "flat",
          road_access: property.road_access || "paved",
          has_title_deed: property.has_title_deed ?? false,
          
          // Hospitality fields
          number_of_rooms: property.number_of_rooms?.toString() || "",
          room_types: property.room_types || [],
          facilities: property.facilities || [],
          occupancy_rate: property.occupancy_rate?.toString() || "",
          has_licenses: property.has_licenses ?? false,
          license_details: property.license_details || "",
          
          // Parking/Misc fields
          is_covered: property.is_covered ?? false,
          accessibility_features: property.accessibility_features || []
        });

        // Set fullAddressInput if it was initially set by the user or can be constructed
        if (property.address) {
          setFullAddressInput(property.address);
          setLocationInputMethod("full_address"); // Assume full address was used if address field has data
        } else if (property.country || property.city) {
          setLocationInputMethod("location_details");
        }
      }
      
      setLoading(false);
    } catch (error) {
      console.error("Error loading user:", error);
      navigate(createPageUrl("Home"));
    }
  }, [navigate]);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  const compressImage = (file, maxSizeKB = 600) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          // Calculate new dimensions while maintaining aspect ratio
          const maxDimension = 1920; // Updated from 1200
          if (width > height && width > maxDimension) {
            height = (height / width) * maxDimension;
            width = maxDimension;
          } else if (height > maxDimension) {
            width = (width / height) * maxDimension;
            height = maxDimension;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          
          // Try different quality levels to get under maxSizeKB
          const tryCompress = (quality) => {
            canvas.toBlob((blob) => {
              const sizeKB = blob.size / 1024;
              
              if (sizeKB <= maxSizeKB || quality <= 0.3) { // Stop if size is good or quality is too low
                // Accept this compression level
                const compressedFile = new File([blob], file.name, {
                  type: 'image/jpeg',
                  lastModified: Date.now()
                });
                
                if (sizeKB > maxSizeKB) {
                  // Couldn't compress enough, but we tried
                  resolve({ file: compressedFile, overSize: true, finalSize: sizeKB });
                } else {
                  resolve({ file: compressedFile, overSize: false, finalSize: sizeKB });
                }
              } else {
                // Try with lower quality
                tryCompress(quality - 0.1);
              }
            }, 'image/jpeg', quality); // Pass current quality
          };
          
          // Start with quality 0.8
          tryCompress(0.8);
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
    });
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    const maxImages = 4;
    const currentImageCount = formData.images.length;
    const filesToUploadCount = files.length;

    if (currentImageCount + filesToUploadCount > maxImages) {
      alert(`You can only upload a maximum of ${maxImages} images per property. You currently have ${currentImageCount} image(s).`);
      return;
    }

    setUploadingImages(true);

    try {
      const uploadPromises = files.map(async (file) => {
        // Compress the image
        const { file: compressedFile, overSize, finalSize } = await compressImage(file); // Updated to receive the object
        
        if (overSize) { // Added user feedback for oversized images
          alert(`Warning: "${file.name}" is ${finalSize.toFixed(0)}KB after compression. For best performance, please try reducing the image size or using a different image.`);
        }
        
        const { file_url } = await UploadFile({ file: compressedFile });
        return file_url;
      });
      
      const imageUrls = await Promise.all(uploadPromises);

      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...imageUrls]
      }));
    } catch (error) {
      console.error("Error uploading images:", error);
      alert("Error uploading images. Please try again.");
    }

    setUploadingImages(false);
  };

  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const handleLocationChange = (lat, lng) => {
    setFormData(prev => ({
      ...prev,
      latitude: lat,
      longitude: lng
    }));
  };

  const parseFullAddress = async () => {
    if (!fullAddressInput.trim()) {
      alert("Please enter a full address");
      return;
    }

    setParsingAddress(true);
    try {
      // Add delay to respect rate limits
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(fullAddressInput)}&limit=1&addressdetails=1`,
        {
          headers: {
            'Accept': 'application/json',
          }
        }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data && data.length > 0) {
        const result = data[0];
        const address = result.address || {};
        
        const country = address.country || "";
        const state = address.state || address.region || address.county || "";
        const city = address.city || address.town || address.village || address.municipality || "";
        const neighborhood = address.neighbourhood || address.suburb || address.district || "";
        
        setFormData(prev => ({
          ...prev,
          country: country,
          state: state,
          city: city,
          neighborhood: neighborhood,
          address: fullAddressInput,
          latitude: parseFloat(result.lat),
          longitude: parseFloat(result.lon)
        }));
        
        alert("Address parsed successfully! Please review the auto-filled fields.");
      } else {
        alert("Could not parse address. Please try entering location details manually.");
      }
    } catch (error) {
      console.error("Error parsing address:", error);
      alert("Error parsing address. Please check your internet connection and try again.");
    }
    setParsingAddress(false);
  };

  const parseStreetAddress = async () => {
    if (!formData.address.trim()) {
      alert("Please enter a street address");
      return;
    }

    setParsingStreetAddress(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(formData.address)}&limit=1&addressdetails=1`,
        {
          headers: {
            'Accept': 'application/json',
          }
        }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data && data.length > 0) {
        const result = data[0];
        const address = result.address || {};
        
        // Preserve existing values if new parsing is less specific or empty
        const country = address.country || formData.country;
        const state = address.state || address.region || address.county || formData.state;
        const city = address.city || address.town || address.village || address.municipality || formData.city;
        const neighborhood = address.neighbourhood || address.suburb || address.district || formData.neighborhood;
        
        setFormData(prev => ({
          ...prev,
          country: country,
          state: state,
          city: city,
          neighborhood: neighborhood,
          latitude: parseFloat(result.lat),
          longitude: parseFloat(result.lon)
        }));
        
        alert("Address parsed successfully! Location fields have been auto-filled. Please review and adjust if necessary.");
      } else {
        alert("Could not parse address. Please try a more specific address or fill fields manually.");
      }
    } catch (error) {
      console.error("Error parsing street address:", error);
      alert("Error parsing address. Please check your internet connection and try again.");
    }
    setParsingStreetAddress(false);
  };


  const geocodeLocationFromDetails = async () => {
    let searchQuery = "";
    
    // Prioritize address, then neighborhood, then city, then country
    if (formData.address && formData.address.trim()) {
      searchQuery = [formData.address, formData.neighborhood, formData.city, formData.state, formData.country]
        .filter(Boolean)
        .map(s => s.trim())
        .join(', ');
    } else if (formData.neighborhood && formData.neighborhood.trim()) {
      searchQuery = [formData.neighborhood, formData.city, formData.state, formData.country]
        .filter(Boolean)
        .map(s => s.trim())
        .join(', ');
    } else if (formData.city && formData.city.trim()) {
      searchQuery = [formData.city, formData.state, formData.country]
        .filter(Boolean)
        .map(s => s.trim())
        .join(', ');
    } else if (formData.country && formData.country.trim()) {
      searchQuery = formData.country;
    }

    if (!searchQuery) {
      alert("Please enter country, city, or address details first.");
      return;
    }

    setIsFindingLocation(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=1`,
        {
          headers: {
            'Accept': 'application/json',
          }
        }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data && data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lon = parseFloat(data[0].lon);
        setFormData(prev => ({
          ...prev,
          latitude: lat,
          longitude: lon
        }));
        alert("Location found! The map has been updated.");
      } else {
        alert("Location not found. Please refine your details or click on the map to set a precise location.");
      }
    } catch (error) {
      console.error("Geocoding error:", error);
      alert("Error finding location. Please check your internet connection and try again.");
    }
    setIsFindingLocation(false);
  };

  // Country autocomplete
  const handleCountryChange = async (value) => {
    setFormData({...formData, country: value, state: "", city: "", neighborhood: "", latitude: null, longitude: null});
    
    if (value.length > 2) {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(value)}&limit=5&featuretype=country`,
          {
            headers: {
              'Accept': 'application/json',
            }
          }
        );
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const countries = data
          .filter(item => item.type === 'administrative' || item.addresstype === 'country')
          .map(item => item.display_name.split(',')[0].trim())
          .filter((v, i, a) => a.indexOf(v) === i && v !== '');
        setCountrySuggestions(countries);
        setShowCountrySuggestions(true);
      } catch (error) {
        console.error("Error fetching country suggestions:", error);
        setShowCountrySuggestions(false);
        setCountrySuggestions([]);
      }
    } else {
      setShowCountrySuggestions(false);
      setCountrySuggestions([]);
    }
  };

  // State autocomplete
  const handleStateChange = async (value) => {
    setFormData({...formData, state: value, city: "", neighborhood: "", latitude: null, longitude: null});
    
    if (value.length > 2 && formData.country) {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(value + ', ' + formData.country)}&limit=5`,
          {
            headers: {
              'Accept': 'application/json',
            }
          }
        );
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const states = data.map(item => {
          const parts = item.display_name.split(',');
          const statePart = parts.find(p => p.trim().toLowerCase().includes(value.toLowerCase())) || parts[0];
          return statePart.trim();
        }).filter((v, i, a) => a.indexOf(v) === i && v !== '');
        setStateSuggestions(states);
        setShowStateSuggestions(true);
      } catch (error) {
        console.error("Error fetching state suggestions:", error);
        setShowStateSuggestions(false);
        setStateSuggestions([]);
      }
    } else {
      setShowStateSuggestions(false);
      setStateSuggestions([]);
    }
  };

  // City autocomplete
  const handleCityChange = async (value) => {
    setFormData({...formData, city: value, latitude: null, longitude: null});
    
    if (value.length > 2) {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const searchQuery = formData.state 
          ? `${value}, ${formData.state}, ${formData.country}`
          : `${value}, ${formData.country}`;
        
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=5&featuretype=city`,
          {
            headers: {
              'Accept': 'application/json',
            }
          }
        );
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const cities = data.map(item => {
          const parts = item.display_name.split(',');
          return parts[0].trim();
        }).filter((v, i, a) => a.indexOf(v) === i && v !== '');
        setCitySuggestions(cities);
        setShowCitySuggestions(true);
      } catch (error) {
        console.error("Error fetching city suggestions:", error);
        setShowCitySuggestions(false);
        setCitySuggestions([]);
      }
    } else {
      setShowCitySuggestions(false);
      setCitySuggestions([]);
    }
  };

  // Neighborhood autocomplete
  const handleNeighborhoodChange = async (value) => {
    setFormData({...formData, neighborhood: value, latitude: null, longitude: null});
    
    if (value.length > 2 && formData.city) {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(value + ', ' + formData.city + ', ' + formData.country)}&limit=5`,
          {
            headers: {
              'Accept': 'application/json',
            }
          }
        );
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const neighborhoods = data.map(item => {
          const parts = item.display_name.split(',');
          return parts[0].trim();
        }).filter((v, i, a) => a.indexOf(v) === i && v !== '');
        setNeighborhoodSuggestions(neighborhoods);
        setShowNeighborhoodSuggestions(true);
      } catch (error) {
        console.error("Error fetching neighborhood suggestions:", error);
        setShowNeighborhoodSuggestions(false);
        setNeighborhoodSuggestions([]);
      }
    } else {
      setShowNeighborhoodSuggestions(false);
      setNeighborhoodSuggestions([]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      // Fetch current user again to ensure latest contact details
      const currentUser = await User.me();

      // Basic validation for currentUser and authorization
      if (!currentUser || (currentUser.account_type !== "vendor" && currentUser.account_type !== "admin")) {
        alert("You are not authorized to add/edit properties.");
        navigate(createPageUrl("Dashboard"));
        return;
      }

      // Check for subscription expiry if vendor
      if (currentUser.account_type === "vendor") {
        const isExpired = currentUser.subscription_end_date && 
          new Date(currentUser.subscription_end_date) < new Date();
        if (isExpired) {
          alert("Your subscription has expired. Please renew to add/edit properties.");
          navigate(createPageUrl("Dashboard"));
          return;
        }
      }

      const propertyData = {
        ...formData,
        vendor_id: currentUser.id,
        vendor_name: currentUser.full_name,
        vendor_email: currentUser.email,
        vendor_phone: currentUser.phone,
        vendor_whatsapp: currentUser.whatsapp,
      };

      // Convert numeric fields
      if (formData.bedrooms) propertyData.bedrooms = parseInt(formData.bedrooms);
      if (formData.bathrooms) propertyData.bathrooms = parseInt(formData.bathrooms);
      if (formData.parking_spaces) propertyData.parking_spaces = parseInt(formData.parking_spaces);
      if (formData.property_size) propertyData.property_size = parseFloat(formData.property_size);
      if (formData.floor_size) propertyData.floor_size = parseFloat(formData.floor_size);
      if (formData.number_of_units) propertyData.number_of_units = parseInt(formData.number_of_units);
      if (formData.parking_capacity) propertyData.parking_capacity = parseInt(formData.parking_capacity);
      if (formData.number_of_rooms) propertyData.number_of_rooms = parseInt(formData.number_of_rooms);
      if (formData.occupancy_rate) propertyData.occupancy_rate = parseFloat(formData.occupancy_rate);
      

      // Only update status and views if creating new property
      if (!isEditMode) {
        propertyData.status = "available";
        propertyData.views = 0;
      }

      // Handle numerical conversions for rent/sale prices
      if (formData.listing_type === "rent") {
        propertyData.rent_amount = parseFloat(formData.rent_amount);
        propertyData.security_deposit = parseFloat(formData.security_deposit);
        delete propertyData.sale_price; // Remove sale_price for rent listings
      } else { // For sale listings
        propertyData.sale_price = parseFloat(formData.sale_price);
        delete propertyData.rent_amount;
        delete propertyData.security_deposit;
        delete propertyData.payment_frequency;
        // The old water/electricity/garbage included fields are removed from formData directly,
        // so no need to delete them here explicitly.
      }
      
      // Clean up fields not relevant to the selected property_type
      // This ensures the database only receives data relevant to the current type
      const cleanedPropertyData = { ...propertyData };

      switch (formData.property_type) {
        case "residential":
          // Keep residential fields, remove others
          delete cleanedPropertyData.floor_size;
          delete cleanedPropertyData.number_of_units;
          delete cleanedPropertyData.location_features;
          if (formData.parking_type !== "none") { /* parking_capacity from residential */ } else { delete cleanedPropertyData.parking_capacity; } // Parking capacity is specific to commercial/hospitality, for residential parking_spaces is used.
          delete cleanedPropertyData.has_internet;
          delete cleanedPropertyData.property_condition;
          delete cleanedPropertyData.usage_type;
          delete cleanedPropertyData.land_type;
          delete cleanedPropertyData.topography;
          delete cleanedPropertyData.road_access;
          delete cleanedPropertyData.has_title_deed;
          delete cleanedPropertyData.number_of_rooms;
          delete cleanedPropertyData.room_types;
          delete cleanedPropertyData.facilities;
          delete cleanedPropertyData.occupancy_rate;
          delete cleanedPropertyData.has_licenses;
          delete cleanedPropertyData.license_details;
          delete cleanedPropertyData.is_covered;
          delete cleanedPropertyData.accessibility_features;
          break;
        case "commercial":
          // Keep commercial fields, remove others
          delete cleanedPropertyData.bedrooms;
          delete cleanedPropertyData.bathrooms;
          delete cleanedPropertyData.kitchen_type;
          delete cleanedPropertyData.has_living_room;
          delete cleanedPropertyData.has_dining_room;
          delete cleanedPropertyData.has_yard_garden;
          delete cleanedPropertyData.yard_fenced;
          delete cleanedPropertyData.parking_type;
          delete cleanedPropertyData.parking_spaces;
          delete cleanedPropertyData.has_balcony;
          delete cleanedPropertyData.water_supply;
          delete cleanedPropertyData.electricity_supply;
          delete cleanedPropertyData.furnishing_status;
          delete cleanedPropertyData.pet_friendly;
          delete cleanedPropertyData.land_type;
          delete cleanedPropertyData.topography;
          delete cleanedPropertyData.road_access;
          delete cleanedPropertyData.has_title_deed;
          delete cleanedPropertyData.number_of_rooms;
          delete cleanedPropertyData.room_types;
          delete cleanedPropertyData.facilities;
          delete cleanedPropertyData.occupancy_rate;
          delete cleanedPropertyData.has_licenses;
          delete cleanedPropertyData.license_details;
          delete cleanedPropertyData.is_covered;
          delete cleanedPropertyData.accessibility_features;
          if (formData.property_size) { /* property_size is still applicable as total area */ } else { delete cleanedPropertyData.property_size; }
          break;
        case "land":
          // Keep land fields, remove others
          delete cleanedPropertyData.bedrooms;
          delete cleanedPropertyData.bathrooms;
          delete cleanedPropertyData.kitchen_type;
          delete cleanedPropertyData.has_living_room;
          delete cleanedPropertyData.has_dining_room;
          delete cleanedPropertyData.has_yard_garden;
          delete cleanedPropertyData.yard_fenced; // Re-purposed for land fenced
          delete cleanedPropertyData.parking_type;
          delete cleanedPropertyData.parking_spaces;
          delete cleanedPropertyData.has_balcony;
          delete cleanedPropertyData.furnishing_status;
          delete cleanedPropertyData.pet_friendly;
          delete cleanedPropertyData.floor_size;
          delete cleanedPropertyData.number_of_units;
          delete cleanedPropertyData.location_features;
          delete cleanedPropertyData.parking_capacity;
          delete cleanedPropertyData.has_internet;
          delete cleanedPropertyData.property_condition;
          delete cleanedPropertyData.usage_type;
          delete cleanedPropertyData.number_of_rooms;
          delete cleanedPropertyData.room_types;
          delete cleanedPropertyData.facilities;
          delete cleanedPropertyData.occupancy_rate;
          delete cleanedPropertyData.has_licenses;
          delete cleanedPropertyData.license_details;
          delete cleanedPropertyData.is_covered;
          delete cleanedPropertyData.accessibility_features;
          delete cleanedPropertyData.security_features; // Specific to residential/commercial
          break;
        case "hospitality":
          // Keep hospitality fields, remove others
          delete cleanedPropertyData.bedrooms;
          delete cleanedPropertyData.bathrooms;
          delete cleanedPropertyData.kitchen_type;
          delete cleanedPropertyData.has_living_room;
          delete cleanedPropertyData.has_dining_room;
          delete cleanedPropertyData.has_yard_garden;
          delete cleanedPropertyData.yard_fenced;
          delete cleanedPropertyData.parking_type;
          delete cleanedPropertyData.parking_spaces;
          delete cleanedPropertyData.has_balcony;
          delete cleanedPropertyData.water_supply;
          delete cleanedPropertyData.electricity_supply;
          delete cleanedPropertyData.pet_friendly;
          delete cleanedPropertyData.floor_size;
          delete cleanedPropertyData.number_of_units;
          delete cleanedPropertyData.location_features;
          delete cleanedPropertyData.has_internet;
          delete cleanedPropertyData.property_condition;
          delete cleanedPropertyData.usage_type;
          delete cleanedPropertyData.land_type;
          delete cleanedPropertyData.topography;
          delete cleanedPropertyData.road_access;
          delete cleanedPropertyData.has_title_deed;
          delete cleanedPropertyData.is_covered;
          delete cleanedPropertyData.accessibility_features;
          if (formData.has_licenses === false) delete cleanedPropertyData.license_details;
          break;
        case "parking_misc":
          // Keep parking/misc fields, remove others
          delete cleanedPropertyData.bedrooms;
          delete cleanedPropertyData.bathrooms;
          delete cleanedPropertyData.kitchen_type;
          delete cleanedPropertyData.has_living_room;
          delete cleanedPropertyData.has_dining_room;
          delete cleanedPropertyData.has_yard_garden;
          delete cleanedPropertyData.yard_fenced;
          delete cleanedPropertyData.parking_type;
          delete cleanedPropertyData.parking_spaces;
          delete cleanedPropertyData.has_balcony;
          delete cleanedPropertyData.water_supply;
          delete cleanedPropertyData.electricity_supply;
          delete cleanedPropertyData.furnishing_status;
          delete cleanedPropertyData.pet_friendly;
          delete cleanedPropertyData.floor_size;
          delete cleanedPropertyData.number_of_units;
          delete cleanedPropertyData.location_features;
          delete cleanedPropertyData.has_internet;
          delete cleanedPropertyData.property_condition;
          delete cleanedPropertyData.usage_type;
          delete cleanedPropertyData.land_type;
          delete cleanedPropertyData.topography;
          delete cleanedPropertyData.road_access;
          delete cleanedPropertyData.has_title_deed;
          delete cleanedPropertyData.number_of_rooms;
          delete cleanedPropertyData.room_types;
          delete cleanedPropertyData.facilities;
          delete cleanedPropertyData.occupancy_rate;
          delete cleanedPropertyData.has_licenses;
          delete cleanedPropertyData.license_details;
          break;
        default:
          break;
      }

      console.log("Property data being saved:", cleanedPropertyData);

      if (isEditMode) {
        await Property.update(propertyId, cleanedPropertyData);
        alert("Property updated successfully!");
      } else {
        await Property.create(cleanedPropertyData);
        alert("Property created successfully!");
      }
      
      navigate(createPageUrl("MyListings"));
    } catch (error) {
      console.error("Error saving property:", error);
      alert("Error saving property. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const userCurrency = user?.currency || "TZS";

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">
          {isEditMode ? "Edit Property" : "Add New Property"}
        </h1>
        <p className="text-slate-600">
          {isEditMode ? "Update your property details" : "Create a detailed listing to attract quality tenants or buyers"}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="listing_type">Listing Type *</Label>
              <Select
                value={formData.listing_type}
                onValueChange={(value) => setFormData({...formData, listing_type: value})}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rent">For Rent</SelectItem>
                  <SelectItem value="sale">For Sale</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500 mt-1">
                Choose whether this property is for rent or for sale
              </p>
            </div>

            <div>
              <Label htmlFor="property_type">Property Category *</Label>
              <Select
                value={formData.property_type}
                onValueChange={(value) => setFormData({...formData, property_type: value, property_subtype: ""})} // Clear subtype when category changes
                required
              >
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="residential">🏠 Residential Properties</SelectItem>
                  <SelectItem value="commercial">🏢 Commercial Properties</SelectItem>
                  <SelectItem value="land">🏞️ Land & Open Spaces</SelectItem>
                  <SelectItem value="hospitality">🏨 Hospitality & Special Use</SelectItem>
                  <SelectItem value="parking_misc">🚗 Parking & Miscellaneous</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="property_subtype">Property Type *</Label>
              <Select
                value={formData.property_subtype}
                onValueChange={(value) => setFormData({...formData, property_subtype: value})}
                required
              >
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select property type" />
                </SelectTrigger>
                <SelectContent>
                  {propertySubtypes[formData.property_type]?.map((subtype) => (
                    <SelectItem key={subtype.value} value={subtype.value}>
                      {subtype.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500 mt-1">
                Specify the exact type of property you're listing
              </p>
            </div>

            <div>
              <Label htmlFor="title">Property Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                placeholder="e.g., Modern 3-Bedroom House in Mikocheni"
                required
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Describe your property in detail: features, nearby amenities, condition, etc."
                className="min-h-32 mt-2"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Location */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Location Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Location Input Method Selector */}
            <div>
              <Label className="text-base font-semibold mb-3 block">How would you like to enter the location?</Label>
              <Select value={locationInputMethod} onValueChange={setLocationInputMethod}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="location_details">
                    📍 Location Details (Country, State, City, Neighborhood)
                  </SelectItem>
                  <SelectItem value="full_address">
                    📝 Full Address (Auto-parse location)
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500 mt-2">
                {locationInputMethod === "full_address" 
                  ? "Enter the complete address and we'll automatically parse it into components."
                  : "Fill in location details step by step for precise listing, or use 'Find Location' to auto-populate coordinates."}
              </p>
            </div>

            <Separator />

            {/* Full Address Input Method */}
            {locationInputMethod === "full_address" && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="full_address_input">Full Address *</Label>
                  <Textarea
                    id="full_address_input"
                    value={fullAddressInput}
                    onChange={(e) => setFullAddressInput(e.target.value)}
                    placeholder="Enter complete address, e.g.&#10;Plot 123, Mikocheni Street, Dar es Salaam, Tanzania"
                    className="mt-2 h-24"
                  />
                  <Button
                    type="button"
                    onClick={parseFullAddress}
                    disabled={parsingAddress || !fullAddressInput.trim()}
                    className="mt-3 bg-indigo-600 hover:bg-indigo-700"
                  >
                    {parsingAddress ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        Parsing Address...
                      </>
                    ) : (
                      "Parse Address"
                    )}
                  </Button>
                </div>

                <Alert className="border-blue-200 bg-blue-50">
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-900 text-sm">
                    After parsing, review the auto-filled fields below and make corrections if needed. The map will update automatically.
                  </AlertDescription>
                </Alert>

                {/* Show parsed fields (read-only or editable) */}
                <div className="grid md:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-lg">
                  <div>
                    <Label className="text-sm text-slate-600">Country</Label>
                    <Input
                      value={formData.country}
                      onChange={(e) => setFormData({...formData, country: e.target.value})}
                      placeholder="Auto-filled"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-sm text-slate-600">State / Region</Label>
                    <Input
                      value={formData.state}
                      onChange={(e) => setFormData({...formData, state: e.target.value})}
                      placeholder="Auto-filled"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-sm text-slate-600">City</Label>
                    <Input
                      value={formData.city}
                      onChange={(e) => setFormData({...formData, city: e.target.value})}
                      placeholder="Auto-filled"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-sm text-slate-600">Neighborhood</Label>
                    <Input
                      value={formData.neighborhood}
                      onChange={(e) => setFormData({...formData, neighborhood: e.target.value})}
                      placeholder="Auto-filled"
                      className="mt-1"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label className="text-sm text-slate-600">Full Address / Location Description</Label>
                    <Textarea
                      value={formData.address}
                      onChange={(e) => setFormData({...formData, address: e.target.value})}
                      placeholder="Auto-filled"
                      className="mt-1 h-20"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Location Details Input Method */}
            {locationInputMethod === "location_details" && (
              <div className="space-y-4">
                <div className="relative">
                  <Label htmlFor="country">Country *</Label>
                  <Input
                    id="country"
                    value={formData.country}
                    onChange={(e) => handleCountryChange(e.target.value)}
                    onFocus={() => formData.country.length > 2 && countrySuggestions.length > 0 && setShowCountrySuggestions(true)}
                    onBlur={() => setTimeout(() => setShowCountrySuggestions(false), 200)}
                    placeholder="Start typing country name..."
                    required
                    className="mt-2"
                    autoComplete="off"
                  />
                  {showCountrySuggestions && countrySuggestions.length > 0 && (
                    <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                      {countrySuggestions.map((country, index) => (
                        <div
                          key={index}
                          className="px-4 py-2 hover:bg-indigo-50 cursor-pointer transition-colors"
                          onMouseDown={() => {
                            setFormData(prev => ({...prev, country: country, state: "", city: "", neighborhood: "", latitude: null, longitude: null}));
                            setShowCountrySuggestions(false);
                          }}
                        >
                          {country}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="relative">
                  <Label htmlFor="state">State / Region / District</Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => handleStateChange(e.target.value)}
                    onFocus={() => formData.state.length > 2 && stateSuggestions.length > 0 && setShowStateSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowStateSuggestions(false), 200)}
                    placeholder="e.g., Dar es Salaam Region (optional)"
                    className="mt-2"
                    autoComplete="off"
                  />
                  {showStateSuggestions && stateSuggestions.length > 0 && (
                    <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                      {stateSuggestions.map((state, index) => (
                        <div
                          key={index}
                          className="px-4 py-2 hover:bg-indigo-50 cursor-pointer transition-colors"
                          onMouseDown={() => {
                            setFormData(prev => ({...prev, state: state, city: "", neighborhood: "", latitude: null, longitude: null}));
                            setShowStateSuggestions(false);
                          }}
                        >
                          {state}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="relative">
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => handleCityChange(e.target.value)}
                    onFocus={() => formData.city.length > 2 && citySuggestions.length > 0 && setShowCitySuggestions(true)}
                    onBlur={() => setTimeout(() => setShowCitySuggestions(false), 200)}
                    placeholder="Start typing city name..."
                    required
                    className="mt-2"
                    autoComplete="off"
                  />
                  {showCitySuggestions && citySuggestions.length > 0 && (
                    <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                      {citySuggestions.map((city, index) => (
                        <div
                          key={index}
                          className="px-4 py-2 hover:bg-indigo-50 cursor-pointer transition-colors"
                          onMouseDown={() => {
                            setFormData(prev => ({...prev, city: city, latitude: null, longitude: null}));
                            setShowCitySuggestions(false);
                          }}
                        >
                          {city}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="relative">
                  <Label htmlFor="neighborhood">Neighborhood / Area</Label>
                  <Input
                    id="neighborhood"
                    value={formData.neighborhood}
                    onChange={(e) => handleNeighborhoodChange(e.target.value)}
                    onFocus={() => formData.neighborhood.length > 2 && neighborhoodSuggestions.length > 0 && setShowNeighborhoodSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowNeighborhoodSuggestions(false), 200)}
                    placeholder="e.g., Mikocheni (optional)"
                    className="mt-2"
                    autoComplete="off"
                  />
                  {showNeighborhoodSuggestions && neighborhoodSuggestions.length > 0 && (
                    <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                      {neighborhoodSuggestions.map((neighborhood, index) => (
                        <div
                          key={index}
                          className="px-4 py-2 hover:bg-indigo-50 cursor-pointer transition-colors"
                          onMouseDown={() => {
                            setFormData(prev => ({...prev, neighborhood: neighborhood, latitude: null, longitude: null}));
                            setShowNeighborhoodSuggestions(false);
                          }}
                        >
                          {neighborhood}
                        </div>
                      ))}
                    </div>
                  )}
                  <p className="text-xs text-slate-500 mt-1">
                    Optional - Specify a neighborhood area
                  </p>
                </div>

                <div>
                  <Label htmlFor="address">Street Address / Landmarks (Optional)</Label>
                  <Textarea
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value, latitude: null, longitude: null})}
                    placeholder="e.g., Plot 123, Mikocheni Street, Dar es Salaam, Tanzania&#10;Add specific street address, plot number, and landmarks"
                    className="mt-2 h-24"
                  />
                  <p className="text-xs text-slate-500 mt-1">
                    Enter a specific street address, plot number, or landmark and click "Parse" to attempt to auto-fill Country, State, City, and Neighborhood.
                  </p>
                  <Button
                    type="button"
                    onClick={parseStreetAddress}
                    disabled={parsingStreetAddress || !formData.address.trim()}
                    variant="outline"
                    size="sm"
                    className="mt-2 gap-2"
                  >
                    {parsingStreetAddress ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-600 mr-2" />
                        Parsing...
                      </>
                    ) : (
                      <>
                        <MapPin className="w-4 h-4" />
                        Parse Address & Auto-Fill
                      </>
                    )}
                  </Button>
                </div>
                
                <div className="flex justify-end pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={geocodeLocationFromDetails}
                    disabled={isFindingLocation}
                    className="gap-2"
                  >
                    {isFindingLocation ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-600" />
                        Finding...
                      </>
                    ) : (
                      <>
                        <MapPin className="w-4 h-4" />
                        Find Location on Map
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Location Map */}
        <LocationMap
          latitude={formData.latitude}
          longitude={formData.longitude}
          country={formData.country}
          state={formData.state}
          city={formData.city}
          neighborhood={formData.neighborhood}
          address={formData.address}
          onLocationChange={handleLocationChange}
          editable={true}
        />

        {/* Property Images */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Property Images (Maximum 4)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {formData.images.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {formData.images.map((image, index) => (
                    <div key={index} className="relative group">
                      <img 
                        src={image} 
                        alt={`Property ${index + 1}`} 
                        className="w-full h-32 object-cover rounded-lg border-2 border-slate-200" 
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                        onClick={() => removeImage(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <div>
                <Label htmlFor="images" className="cursor-pointer">
                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-12 text-center hover:border-indigo-400 hover:bg-indigo-50/50 transition-all">
                    {uploadingImages ? (
                      <>
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4" />
                        <p className="text-sm text-slate-600">Compressing and uploading images...</p>
                        <p className="text-xs text-slate-500 mt-1">This may take a moment</p>
                      </>
                    ) : (
                      <>
                        <ImageIcon className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                        <p className="text-slate-600 font-medium mb-1">Click to upload property images</p>
                        <p className="text-xs text-slate-500">
                          PNG, JPG, JPEG. Maximum 4 images.
                        </p>
                        <p className="text-xs text-indigo-600 mt-2">
                          Images will be automatically compressed to optimize loading speed
                        </p>
                        <p className="text-xs font-semibold text-slate-700 mt-2">
                          {formData.images.length} of 4 images uploaded
                        </p>
                      </>
                    )}
                  </div>
                </Label>
                <Input
                  id="images"
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={uploadingImages || formData.images.length >= 4}
                />
                {formData.images.length >= 4 && (
                  <p className="text-sm text-orange-600 mt-2 font-semibold">Maximum of 4 images reached</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Property Details - Dynamic based on property type */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Property Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* Residential Properties */}
            {formData.property_type === "residential" && (
              <>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="bedrooms">Number of Bedrooms *</Label>
                    <Select
                      value={formData.bedrooms}
                      onValueChange={(value) => setFormData({...formData, bedrooms: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">Studio (No separate bedroom)</SelectItem>
                        <SelectItem value="1">1 Bedroom</SelectItem>
                        <SelectItem value="2">2 Bedrooms</SelectItem>
                        <SelectItem value="3">3 Bedrooms</SelectItem>
                        <SelectItem value="4">4 Bedrooms</SelectItem>
                        <SelectItem value="5">5+ Bedrooms</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="bathrooms">Number of Bathrooms/Toilets *</Label>
                    <Select
                      value={formData.bathrooms}
                      onValueChange={(value) => setFormData({...formData, bathrooms: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Bathroom</SelectItem>
                        <SelectItem value="2">2 Bathrooms</SelectItem>
                        <SelectItem value="3">3 Bathrooms</SelectItem>
                        <SelectItem value="4">4+ Bathrooms</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="kitchen_type">Kitchen Type</Label>
                    <Select
                      value={formData.kitchen_type}
                      onValueChange={(value) => setFormData({...formData, kitchen_type: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Kitchen</SelectItem>
                        <SelectItem value="basic">Basic Kitchen</SelectItem>
                        <SelectItem value="modern">Modern Kitchen</SelectItem>
                        <SelectItem value="open_plan">Open Plan Kitchen</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="parking_type">Parking Type</Label>
                    <Select
                      value={formData.parking_type}
                      onValueChange={(value) => setFormData({...formData, parking_type: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Parking</SelectItem>
                        <SelectItem value="garage">Garage</SelectItem>
                        <SelectItem value="carport">Carport</SelectItem>
                        <SelectItem value="driveway">Driveway</SelectItem>
                        <SelectItem value="street">Street Parking</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {formData.parking_type !== "none" && (
                    <div>
                      <Label htmlFor="parking_spaces">Number of Parking Spaces</Label>
                      <Input
                        id="parking_spaces"
                        type="number"
                        min="0"
                        value={formData.parking_spaces}
                        onChange={(e) => setFormData({...formData, parking_spaces: e.target.value})}
                        className="mt-2"
                      />
                    </div>
                  )}

                  <div>
                    <Label htmlFor="property_size">Property Size</Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        id="property_size"
                        type="number"
                        min="0"
                        step="any"
                        value={formData.property_size}
                        onChange={(e) => setFormData({...formData, property_size: e.target.value})}
                        placeholder="Enter size"
                      />
                      <Select
                        value={formData.size_unit}
                        onValueChange={(value) => setFormData({...formData, size_unit: value})}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sqm">sqm</SelectItem>
                          <SelectItem value="acres">acres</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="water_supply">Water Supply</Label>
                    <Select
                      value={formData.water_supply}
                      onValueChange={(value) => setFormData({...formData, water_supply: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Water Supply</SelectItem>
                        <SelectItem value="municipal">Municipal Water</SelectItem>
                        <SelectItem value="borehole">Borehole</SelectItem>
                        <SelectItem value="well">Well</SelectItem>
                        <SelectItem value="both">Municipal + Borehole</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="electricity_supply">Electricity Supply</Label>
                    <Select
                      value={formData.electricity_supply}
                      onValueChange={(value) => setFormData({...formData, electricity_supply: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Electricity</SelectItem>
                        <SelectItem value="grid">Grid Electricity</SelectItem>
                        <SelectItem value="generator">Generator</SelectItem>
                        <SelectItem value="solar">Solar</SelectItem>
                        <SelectItem value="mixed">Mixed Sources</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="furnishing_status">Furnishing Status</Label>
                    <Select
                      value={formData.furnishing_status}
                      onValueChange={(value) => setFormData({...formData, furnishing_status: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="unfurnished">Unfurnished</SelectItem>
                        <SelectItem value="semi_furnished">Semi-Furnished</SelectItem>
                        <SelectItem value="fully_furnished">Fully Furnished</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Additional Features</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="has_living_room"
                        checked={formData.has_living_room}
                        onCheckedChange={(checked) => setFormData({...formData, has_living_room: checked})}
                      />
                      <Label htmlFor="has_living_room" className="cursor-pointer font-normal">Living Room</Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="has_dining_room"
                        checked={formData.has_dining_room}
                        onCheckedChange={(checked) => setFormData({...formData, has_dining_room: checked})}
                      />
                      <Label htmlFor="has_dining_room" className="cursor-pointer font-normal">Dining Room</Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="has_yard_garden"
                        checked={formData.has_yard_garden}
                        onCheckedChange={(checked) => setFormData({...formData, has_yard_garden: checked})}
                      />
                      <Label htmlFor="has_yard_garden" className="cursor-pointer font-normal">Yard/Garden</Label>
                    </div>
                    {formData.has_yard_garden && (
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          id="yard_fenced"
                          checked={formData.yard_fenced}
                          onCheckedChange={(checked) => setFormData({...formData, yard_fenced: checked})}
                        />
                        <Label htmlFor="yard_fenced" className="cursor-pointer font-normal">Fenced Yard</Label>
                      </div>
                    )}
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="has_balcony"
                        checked={formData.has_balcony}
                        onCheckedChange={(checked) => setFormData({...formData, has_balcony: checked})}
                      />
                      <Label htmlFor="has_balcony" className="cursor-pointer font-normal">Balcony/Veranda</Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="pet_friendly"
                        checked={formData.pet_friendly}
                        onCheckedChange={(checked) => setFormData({...formData, pet_friendly: checked})}
                      />
                      <Label htmlFor="pet_friendly" className="cursor-pointer font-normal">Pet Friendly</Label>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Security Features</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {['fence', 'wall', 'alarm', 'guard', 'cctv', 'gate'].map((feature) => (
                      <div key={feature} className="flex items-center space-x-3">
                        <Checkbox
                          id={`security_${feature}`}
                          checked={formData.security_features.includes(feature)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, security_features: [...formData.security_features, feature]});
                            } else {
                              setFormData({...formData, security_features: formData.security_features.filter(f => f !== feature)});
                            }
                          }}
                        />
                        <Label htmlFor={`security_${feature}`} className="cursor-pointer font-normal capitalize">
                          {feature === 'cctv' ? 'CCTV' : feature}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Commercial Properties */}
            {formData.property_type === "commercial" && (
              <>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="floor_size">Floor Size (sqm) *</Label>
                    <Input
                      id="floor_size"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.floor_size}
                      onChange={(e) => setFormData({...formData, floor_size: e.target.value})}
                      placeholder="Enter floor size"
                      className="mt-2"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="number_of_units">Number of Units/Rooms</Label>
                    <Input
                      id="number_of_units"
                      type="number"
                      min="0"
                      value={formData.number_of_units}
                      onChange={(e) => setFormData({...formData, number_of_units: e.target.value})}
                      placeholder="Enter number of units"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="parking_capacity">Parking Capacity (number of cars)</Label>
                    <Input
                      id="parking_capacity"
                      type="number"
                      min="0"
                      value={formData.parking_capacity}
                      onChange={(e) => setFormData({...formData, parking_capacity: e.target.value})}
                      placeholder="Enter parking capacity"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="property_condition">Property Condition</Label>
                    <Select
                      value={formData.property_condition}
                      onValueChange={(value) => setFormData({...formData, property_condition: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">Newly Built</SelectItem>
                        <SelectItem value="renovated">Recently Renovated</SelectItem>
                        <SelectItem value="good">Good Condition</SelectItem>
                        <SelectItem value="needs_work">Needs Renovation</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="usage_type">Usage Type</Label>
                    <Select
                      value={formData.usage_type}
                      onValueChange={(value) => setFormData({...formData, usage_type: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="retail">Retail</SelectItem>
                        <SelectItem value="office">Office</SelectItem>
                        <SelectItem value="storage">Storage/Warehouse</SelectItem>
                        <SelectItem value="manufacturing">Manufacturing</SelectItem>
                        <SelectItem value="hospitality">Hospitality Use</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Location & Accessibility</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {['road_frontage', 'main_road', 'cbd', 'mall'].map((feature) => (
                      <div key={feature} className="flex items-center space-x-3">
                        <Checkbox
                          id={`location_${feature}`}
                          checked={formData.location_features.includes(feature)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, location_features: [...formData.location_features, feature]});
                            } else {
                              setFormData({...formData, location_features: formData.location_features.filter(f => f !== feature)});
                            }
                          }}
                        />
                        <Label htmlFor={`location_${feature}`} className="cursor-pointer font-normal">
                          {feature.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Utilities & Features</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="has_internet"
                        checked={formData.has_internet}
                        onCheckedChange={(checked) => setFormData({...formData, has_internet: checked})}
                      />
                      <Label htmlFor="has_internet" className="cursor-pointer font-normal">Internet Connection</Label>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Security Features</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {['guard', 'cctv', 'fence', 'access_control'].map((feature) => (
                      <div key={feature} className="flex items-center space-x-3">
                        <Checkbox
                          id={`com_security_${feature}`}
                          checked={formData.security_features.includes(feature)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, security_features: [...formData.security_features, feature]});
                            } else {
                              setFormData({...formData, security_features: formData.security_features.filter(f => f !== feature)});
                            }
                          }}
                        />
                        <Label htmlFor={`com_security_${feature}`} className="cursor-pointer font-normal">
                          {feature.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Land Properties */}
            {formData.property_type === "land" && (
              <>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="land_size">Land Size *</Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        id="land_size"
                        type="number"
                        min="0"
                        step="any"
                        value={formData.property_size}
                        onChange={(e) => setFormData({...formData, property_size: e.target.value})}
                        placeholder="Enter size"
                        required
                      />
                      <Select
                        value={formData.size_unit}
                        onValueChange={(value) => setFormData({...formData, size_unit: value})}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sqm">sqm</SelectItem>
                          <SelectItem value="acres">acres</SelectItem>
                          <SelectItem value="hectares">hectares</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="land_type">Land Type</Label>
                    <Select
                      value={formData.land_type}
                      onValueChange={(value) => setFormData({...formData, land_type: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="residential">Residential</SelectItem>
                        <SelectItem value="commercial">Commercial</SelectItem>
                        <SelectItem value="agricultural">Agricultural</SelectItem>
                        <SelectItem value="mixed">Mixed Use</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="topography">Topography</Label>
                    <Select
                      value={formData.topography}
                      onValueChange={(value) => setFormData({...formData, topography: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="flat">Flat</SelectItem>
                        <SelectItem value="hilly">Hilly</SelectItem>
                        <SelectItem value="rocky">Rocky</SelectItem>
                        <SelectItem value="fertile">Fertile</SelectItem>
                        <SelectItem value="mixed">Mixed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="road_access">Road Access</Label>
                    <Select
                      value={formData.road_access}
                      onValueChange={(value) => setFormData({...formData, road_access: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Road Access</SelectItem>
                        <SelectItem value="gravel">Gravel Road</SelectItem>
                        <SelectItem value="paved">Paved Road</SelectItem>
                        <SelectItem value="highway">Highway Access</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Utilities & Documentation</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="land_water"
                        checked={formData.water_supply !== "none" && formData.water_supply !== ""}
                        onCheckedChange={(checked) => setFormData({...formData, water_supply: checked ? "municipal" : "none"})}
                      />
                      <Label htmlFor="land_water" className="cursor-pointer font-normal">Water Available</Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="land_electricity"
                        checked={formData.electricity_supply !== "none" && formData.electricity_supply !== ""}
                        onCheckedChange={(checked) => setFormData({...formData, electricity_supply: checked ? "grid" : "none"})}
                      />
                      <Label htmlFor="land_electricity" className="cursor-pointer font-normal">Electricity Available</Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="land_fenced"
                        checked={formData.yard_fenced}
                        onCheckedChange={(checked) => setFormData({...formData, yard_fenced: checked})}
                      />
                      <Label htmlFor="land_fenced" className="cursor-pointer font-normal">Fenced</Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="has_title_deed"
                        checked={formData.has_title_deed}
                        onCheckedChange={(checked) => setFormData({...formData, has_title_deed: checked})}
                      />
                      <Label htmlFor="has_title_deed" className="cursor-pointer font-normal">Has Title Deed</Label>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Hospitality Properties */}
            {formData.property_type === "hospitality" && (
              <>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="number_of_rooms">Number of Rooms/Units *</Label>
                    <Input
                      id="number_of_rooms"
                      type="number"
                      min="1"
                      value={formData.number_of_rooms}
                      onChange={(e) => setFormData({...formData, number_of_rooms: e.target.value})}
                      placeholder="Enter number of rooms"
                      className="mt-2"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="property_size">Property Size (sqm)</Label>
                    <Input
                      id="property_size"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.property_size}
                      onChange={(e) => setFormData({...formData, property_size: e.target.value})}
                      placeholder="Enter size"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="parking_capacity">Parking Capacity</Label>
                    <Input
                      id="parking_capacity"
                      type="number"
                      min="0"
                      value={formData.parking_capacity}
                      onChange={(e) => setFormData({...formData, parking_capacity: e.target.value})}
                      placeholder="Number of cars"
                      className="mt-2"
                    />
                  </div>

                  {formData.listing_type === "sale" && (
                    <div>
                      <Label htmlFor="occupancy_rate">Occupancy Rate (%)</Label>
                      <Input
                        id="occupancy_rate"
                        type="number"
                        min="0"
                        max="100"
                        value={formData.occupancy_rate}
                        onChange={(e) => setFormData({...formData, occupancy_rate: e.target.value})}
                        placeholder="Average occupancy percentage"
                        className="mt-2"
                      />
                    </div>
                  )}
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Room Types</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {['single', 'double', 'suite', 'dorm'].map((roomType) => (
                      <div key={roomType} className="flex items-center space-x-3">
                        <Checkbox
                          id={`room_${roomType}`}
                          checked={formData.room_types.includes(roomType)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, room_types: [...formData.room_types, roomType]});
                            } else {
                              setFormData({...formData, room_types: formData.room_types.filter(r => r !== roomType)});
                            }
                          }}
                        />
                        <Label htmlFor={`room_${roomType}`} className="cursor-pointer font-normal capitalize">
                          {roomType} Room
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Facilities</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {['conference_hall', 'pool', 'gym', 'restaurant', 'bar'].map((facility) => (
                      <div key={facility} className="flex items-center space-x-3">
                        <Checkbox
                          id={`facility_${facility}`}
                          checked={formData.facilities.includes(facility)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, facilities: [...formData.facilities, facility]});
                            } else {
                              setFormData({...formData, facilities: formData.facilities.filter(f => f !== facility)});
                            }
                          }}
                        />
                        <Label htmlFor={`facility_${facility}`} className="cursor-pointer font-normal">
                          {facility.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Licenses & Equipment</Label>
                  <div className="flex items-center space-x-3 mb-3">
                    <Checkbox
                      id="has_licenses"
                      checked={formData.has_licenses}
                      onCheckedChange={(checked) => setFormData({...formData, has_licenses: checked})}
                    />
                    <Label htmlFor="has_licenses" className="cursor-pointer font-normal">Has Valid Licenses & Permits</Label>
                  </div>
                  {formData.has_licenses && (
                    <Textarea
                      id="license_details"
                      value={formData.license_details}
                      onChange={(e) => setFormData({...formData, license_details: e.target.value})}
                      placeholder="Specify licenses (e.g., hotel license, bar license, food handling permit)"
                      className="h-20"
                    />
                  )}
                  <div className="flex items-center space-x-3 mt-3">
                    <Checkbox
                      id="hosp_furnished"
                      checked={formData.furnishing_status === "fully_furnished"}
                      onCheckedChange={(checked) => setFormData({...formData, furnishing_status: checked ? "fully_furnished" : "unfurnished"})}
                    />
                    <Label htmlFor="hosp_furnished" className="cursor-pointer font-normal">Fully Furnished/Equipped</Label>
                  </div>
                </div>
              </>
            )}

            {/* Parking & Miscellaneous */}
            {formData.property_type === "parking_misc" && (
              <>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="parking_capacity">Capacity (number of cars/slots) *</Label>
                    <Input
                      id="parking_capacity"
                      type="number"
                      min="1"
                      value={formData.parking_capacity}
                      onChange={(e) => setFormData({...formData, parking_capacity: e.target.value})}
                      placeholder="Enter capacity"
                      className="mt-2"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="property_size">Size (sqm)</Label>
                    <Input
                      id="property_size"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.property_size}
                      onChange={(e) => setFormData({...formData, property_size: e.target.value})}
                      placeholder="Enter size"
                      className="mt-2"
                    />
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Parking Features</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="is_covered"
                        checked={formData.is_covered}
                        onCheckedChange={(checked) => setFormData({...formData, is_covered: checked})}
                      />
                      <Label htmlFor="is_covered" className="cursor-pointer font-normal">Covered Parking</Label>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Accessibility</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {['main_road', 'gated_community', 'city_center'].map((feature) => (
                      <div key={feature} className="flex items-center space-x-3">
                        <Checkbox
                          id={`access_${feature}`}
                          checked={formData.accessibility_features.includes(feature)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, accessibility_features: [...formData.accessibility_features, feature]});
                            } else {
                              setFormData({...formData, accessibility_features: formData.accessibility_features.filter(f => f !== feature)});
                            }
                          }}
                        />
                        <Label htmlFor={`access_${feature}`} className="cursor-pointer font-normal">
                          {feature.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-base font-semibold mb-3 block">Security</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {['cctv', 'guard', 'gated_entry'].map((feature) => (
                      <div key={feature} className="flex items-center space-x-3">
                        <Checkbox
                          id={`park_security_${feature}`}
                          checked={formData.security_features.includes(feature)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, security_features: [...formData.security_features, feature]});
                            } else {
                              setFormData({...formData, security_features: formData.security_features.filter(f => f !== feature)});
                            }
                          }}
                        />
                        <Label htmlFor={`park_security_${feature}`} className="cursor-pointer font-normal">
                          {feature.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Payment/Price Terms */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>
              {formData.listing_type === "rent" ? "Payment Terms" : "Sale Price"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {formData.listing_type === "rent" ? (
              <>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="rent">Monthly Rent Amount ({userCurrency}) *</Label>
                    <Input
                      id="rent"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.rent_amount}
                      onChange={(e) => setFormData({...formData, rent_amount: e.target.value})}
                      placeholder="e.g., 500000"
                      required
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="deposit">Security Deposit ({userCurrency}) *</Label>
                    <Input
                      id="deposit"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.security_deposit}
                      onChange={(e) => setFormData({...formData, security_deposit: e.target.value})}
                      placeholder="e.g., 1000000"
                      required
                      className="mt-2"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="frequency">Payment Frequency</Label>
                  <Select
                    value={formData.payment_frequency}
                    onValueChange={(value) => setFormData({...formData, payment_frequency: value})}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="bi-monthly">Bi-Monthly (2 months)</SelectItem>
                      <SelectItem value="quarterly">Quarterly (3 months)</SelectItem>
                      <SelectItem value="semi-annual">Semi-Annual (6 months)</SelectItem>
                      <SelectItem value="annual">Annual (12 months)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            ) : (
              <div>
                <Label htmlFor="sale_price">Sale Price ({userCurrency}) *</Label>
                <Input
                  id="sale_price"
                  type="number"
                  min="0"
                  step="any"
                  value={formData.sale_price}
                  onChange={(e) => setFormData({...formData, sale_price: e.target.value})}
                  placeholder="e.g., 150000000"
                  required
                  className="mt-2"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Enter the total sale price for the property
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Submit Buttons */}
        <div className="flex justify-end gap-4 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate(createPageUrl("MyListings"))}
            disabled={saving}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={saving || uploadingImages || isFindingLocation || parsingAddress || parsingStreetAddress}
            className="bg-indigo-600 hover:bg-indigo-700 px-8"
          >
            {saving ? (isEditMode ? "Updating..." : "Publishing...") : (isEditMode ? "Update Property" : "Publish Property")}
          </Button>
        </div>
      </form>
    </div>
  );
}
