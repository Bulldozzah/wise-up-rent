
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { VendorRequest } from "@/api/entities";
import { Property } from "@/api/entities";
import { Listing } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { CheckCircle, XCircle, Clock, Building2, Users, Bell, AlertCircle, Search, Edit2 } from "lucide-react";
import { format } from "date-fns";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";


export default function AdminPanel() {
  const [currentUser, setCurrentUser] = useState(null);
  const [requests, setRequests] = useState([]);
  const [properties, setProperties] = useState([]);
  const [listings, setListings] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deactivating, setDeactivating] = useState(null); // Used for deactivating vendor button loading
  const [subscriptionFilter, setSubscriptionFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [editingSubscription, setEditingSubscription] = useState(null); // Stores the vendor user object being edited
  const [isUpdatingSubscription, setIsUpdatingSubscription] = useState(false); // Used for dialog update button loading
  const [subscriptionForm, setSubscriptionForm] = useState({
    subscription_status: "active",
    subscription_end_date: "", // YYYY-MM-DD format for input type="date"
    trial_used: false
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true); // Ensure loading is true when data is being reloaded
    const user = await User.me();
    setCurrentUser(user);

    if (user.account_type !== "admin") {
      setLoading(false); // Set loading to false if not admin and cannot proceed
      return;
    }

    const [allRequests, allProperties, allListings, allUsers] = await Promise.all([
      VendorRequest.list("-created_date"),
      Property.list("-created_date"),
      Listing.list("-created_date"),
      User.list()
    ]);

    setRequests(allRequests);
    setProperties(allProperties);
    setListings(allListings);
    setUsers(allUsers);
    setLoading(false);
  };

  const handleApproveRequest = async (request) => {
    // Determine the end date based on the subscription type
    const now = new Date();
    let endDate;
    if (request.subscription_type === "trial") {
        endDate = new Date(now.setDate(now.getDate() + 30)); // 30 days for trial
    } else {
        endDate = new Date(now.setMonth(now.getMonth() + 1)); // 1 month for paid
    }
    
    await VendorRequest.update(request.id, {
      status: "approved",
      reviewed_by: currentUser.email,
      reviewed_at: new Date().toISOString()
    });

    await User.update(request.user_id, {
      account_type: "vendor",
      subscription_status: "active",
      subscription_end_date: endDate.toISOString(),
      // If a trial is approved, it means the trial has now been used.
      // If a paid subscription is approved, they are past the trial phase, so trial is considered used.
      trial_used: true 
    });

    loadData();
  };

  const handleRejectRequest = async (request) => {
    await VendorRequest.update(request.id, {
      status: "rejected",
      reviewed_by: currentUser.email,
      reviewed_at: new Date().toISOString()
    });

    loadData();
  };

  const getDaysRemaining = (endDate) => {
    if (!endDate) return null;
    const now = new Date();
    const end = new Date(endDate);
    const diffTime = end - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const handleDeactivateVendor = async (userId) => {
    if (!confirm("Are you sure you want to deactivate this vendor? They will lose access to listing features.")) {
      return;
    }

    setDeactivating(userId);

    try {
      await User.update(userId, {
        account_type: "tenant",
        subscription_status: "expired"
      });
      await loadData();
    } catch (error) {
      console.error("Error deactivating vendor:", error);
      alert("Error deactivating vendor. Please try again.");
    } finally {
      setDeactivating(null);
    }
  };

  const handleSubscriptionEdit = (vendor) => {
    setEditingSubscription(vendor);
    setSubscriptionForm({
      subscription_status: vendor.subscription_status || "active",
      // Format the date to "YYYY-MM-DD" for HTML date input
      subscription_end_date: vendor.subscription_end_date ? format(new Date(vendor.subscription_end_date), "yyyy-MM-dd") : "",
      trial_used: vendor.trial_used || false
    });
  };

  const handleSubscriptionUpdate = async (e) => {
    e.preventDefault();
    if (!editingSubscription) return;

    setIsUpdatingSubscription(true);

    try {
      const updateData = {
        subscription_status: subscriptionForm.subscription_status,
        trial_used: subscriptionForm.trial_used
      };

      if (subscriptionForm.subscription_end_date) {
        // Convert back to ISO string for storage
        const date = new Date(subscriptionForm.subscription_end_date);
        date.setHours(23, 59, 59, 999); // Set to end of day to ensure full day is counted
        updateData.subscription_end_date = date.toISOString();
      } else {
        updateData.subscription_end_date = null;
      }

      await User.update(editingSubscription.id, updateData);
      
      setEditingSubscription(null); // Close the dialog
      await loadData(); // Reload data to reflect changes
    } catch (error) {
      console.error("Error updating subscription:", error);
      alert("Error updating subscription. Please try again.");
    } finally {
      setIsUpdatingSubscription(false);
    }
  };


  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (!currentUser || currentUser.account_type !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card>
          <CardContent className="pt-6">
            <p className="text-slate-600">Access denied. Admin privileges required.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const pendingRequests = requests.filter(r => r.status === "pending");
  const trialRequests = pendingRequests.filter(r => r.subscription_type === "trial");
  const paidRequests = pendingRequests.filter(r => r.subscription_type === "paid");
  const totalListings = properties.length + listings.length;

  // Get all vendors with subscription info
  const vendors = users.filter(u => u.account_type === "vendor").map(vendor => {
    const daysLeft = getDaysRemaining(vendor.subscription_end_date);
    return {
      ...vendor,
      daysRemaining: daysLeft,
      // Adjusted logic: if trial_used is false, implies current state is trial
      planType: vendor.trial_used === false ? "Trial" : "Paid"
    };
  }).sort((a, b) => {
    // Sort by daysRemaining, expired first, then expiring, then active
    if (a.daysRemaining === null && b.daysRemaining === null) return 0;
    if (a.daysRemaining === null) return 1;
    if (b.daysRemaining === null) return -1;
    return (a.daysRemaining || 0) - (b.daysRemaining || 0);
  });

  // Filter vendors based on subscription status and search
  const filteredVendors = vendors.filter(vendor => {
    // Search filter
    const matchesSearch = searchQuery === "" || 
      vendor.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vendor.email?.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!matchesSearch) return false;

    // Status filter
    if (subscriptionFilter === "all") return true;
    if (subscriptionFilter === "expired") return vendor.daysRemaining !== null && vendor.daysRemaining < 0;
    // An "active" vendor is one with more than 5 days remaining, not expiring soon
    if (subscriptionFilter === "active") return vendor.daysRemaining !== null && vendor.daysRemaining > 5;
    // "Expiring soon" is between 0 and 5 days (inclusive)
    if (subscriptionFilter === "expiring") return vendor.daysRemaining !== null && vendor.daysRemaining >= 0 && vendor.daysRemaining <= 5;
    
    return true;
  });

  const expiringVendors = vendors.filter(v => v.daysRemaining !== null && v.daysRemaining <= 3 && v.daysRemaining >= 0);
  const expiredVendors = vendors.filter(v => v.daysRemaining !== null && v.daysRemaining < 0);

  return (
    <>
      <div className="p-6 md:p-8 max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Admin Panel</h1>
          <p className="text-slate-600">Manage vendor requests and subscriptions</p>
        </div>

        {/* Notification Alerts */}
        <div className="space-y-4 mb-8">
          {pendingRequests.length > 0 && (
            <Alert className="border-orange-200 bg-orange-50">
              <Bell className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-900">
                <strong>{pendingRequests.length}</strong> pending vendor {pendingRequests.length === 1 ? 'request' : 'requests'}
                {trialRequests.length > 0 && ` (${trialRequests.length} trial)`}
                {paidRequests.length > 0 && ` (${paidRequests.length} paid)`}
              </AlertDescription>
            </Alert>
          )}

          {expiringVendors.length > 0 && (
            <Alert className="border-yellow-200 bg-yellow-50">
              <Clock className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-900">
                <strong>{expiringVendors.length}</strong> vendor {expiringVendors.length === 1 ? 'subscription expires' : 'subscriptions expire'} within 3 days
              </AlertDescription>
            </Alert>
          )}

          {expiredVendors.length > 0 && (
            <Alert className="border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-900">
                <strong>{expiredVendors.length}</strong> vendor {expiredVendors.length === 1 ? 'subscription has' : 'subscriptions have'} expired
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Pending Requests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl font-bold text-orange-600">{pendingRequests.length}</div>
                <Clock className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Total Listings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl font-bold text-indigo-600">{totalListings}</div>
                <Building2 className="w-8 h-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl font-bold text-blue-600">{users.length}</div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="requests" className="space-y-6">
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="requests" className="relative">
              Subscription Requests
              {pendingRequests.length > 0 && (
                <Badge className="ml-2 bg-orange-500">{pendingRequests.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="subscriptions" className="relative">
              Active Subscriptions
              {expiredVendors.length > 0 && (
                <Badge className="ml-2 bg-red-500">{expiredVendors.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="properties">All Properties</TabsTrigger>
            <TabsTrigger value="items">All Items</TabsTrigger>
            <TabsTrigger value="users">All Users</TabsTrigger>
          </TabsList>

          <TabsContent value="requests">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Vendor Subscription Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {requests.length === 0 ? (
                  <p className="text-slate-600 text-center py-8">No requests yet</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Applicant</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Payment Proof</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {requests.map((request) => (
                        <TableRow key={request.id}>
                          <TableCell className="font-medium">{request.user_name}</TableCell>
                          <TableCell>{request.user_email}</TableCell>
                          <TableCell>
                            <Badge className={request.subscription_type === "trial" ? "bg-green-600" : "bg-indigo-600"}>
                              {request.subscription_type === "trial" ? "30-Day Trial" : "K20/30 Days"}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-xs">
                            {request.subscription_type === "paid" ? (
                              <details className="cursor-pointer">
                                <summary className="text-sm text-blue-600 hover:underline">
                                  View Details
                                </summary>
                                <div className="mt-2 text-xs bg-slate-50 p-2 rounded whitespace-pre-wrap">
                                  {request.proof_of_payment}
                                </div>
                              </details>
                            ) : (
                              <span className="text-sm text-slate-500">N/A (Trial)</span>
                            )}
                          </TableCell>
                          <TableCell>{format(new Date(request.created_date), "MMM d, yyyy")}</TableCell>
                          <TableCell>
                            <Badge variant={
                              request.status === "pending" ? "secondary" :
                              request.status === "approved" ? "default" : "destructive"
                            }>
                              {request.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {request.status === "pending" && (
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-green-600 border-green-300 hover:bg-green-50"
                                  onClick={() => handleApproveRequest(request)}
                                >
                                  <CheckCircle className="w-4 h-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600 border-red-300 hover:bg-red-50"
                                  onClick={() => handleRejectRequest(request)}
                                >
                                  <XCircle className="w-4 h-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subscriptions">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Vendor Subscriptions</CardTitle>
                
                {/* Search and Filter */}
                <div className="flex flex-col md:flex-row gap-4 mt-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      placeholder="Search by name or email..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={subscriptionFilter} onValueChange={setSubscriptionFilter}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Vendors ({vendors.length})</SelectItem>
                      <SelectItem value="active">Active ({vendors.filter(v => v.daysRemaining !== null && v.daysRemaining > 5).length})</SelectItem>
                      <SelectItem value="expiring">Expiring Soon ({vendors.filter(v => v.daysRemaining !== null && v.daysRemaining >= 0 && v.daysRemaining <= 5).length})</SelectItem>
                      <SelectItem value="expired">Expired ({expiredVendors.length})</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                {filteredVendors.length === 0 ? (
                  <p className="text-slate-600 text-center py-8">
                    {searchQuery || subscriptionFilter !== "all" 
                      ? "No vendors match your filters" 
                      : "No active vendors"}
                  </p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Vendor Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Plan Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Days Remaining</TableHead>
                        <TableHead>End Date</TableHead>
                        <TableHead>Listings</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredVendors.map((vendor) => {
                        const vendorListings = [...properties, ...listings].filter(
                          l => (l.vendor_id === vendor.id || l.owner_id === vendor.id) && l.status !== "sold" && l.status !== "rented"
                        ).length;

                        return (
                          <TableRow key={vendor.id}>
                            <TableCell className="font-medium">{vendor.full_name}</TableCell>
                            <TableCell>{vendor.email}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className={
                                vendor.planType === "Trial" ? "border-green-500 text-green-700" : "border-indigo-500 text-indigo-700"
                              }>
                                {vendor.planType}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={
                                vendor.daysRemaining === null ? "secondary" :
                                vendor.daysRemaining <= 0 ? "destructive" :
                                vendor.daysRemaining <= 5 ? "outline" : "default"
                              } className={
                                vendor.daysRemaining !== null && vendor.daysRemaining <= 5 && vendor.daysRemaining > 0
                                  ? "border-yellow-500 text-yellow-700"
                                  : ""
                              }>
                                {vendor.daysRemaining !== null && vendor.daysRemaining <= 0 ? "Expired" :
                                 vendor.daysRemaining !== null && vendor.daysRemaining <= 5 ? "Expiring Soon" :
                                 "Active"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {vendor.daysRemaining === null ? (
                                <span className="text-slate-400">N/A</span>
                              ) : vendor.daysRemaining <= 0 ? (
                                <span className="text-red-600 font-semibold">
                                  Expired {Math.abs(vendor.daysRemaining)} days ago
                                </span>
                              ) : vendor.daysRemaining <= 5 ? (
                                <span className="text-yellow-600 font-semibold">
                                  {vendor.daysRemaining} {vendor.daysRemaining === 1 ? 'day' : 'days'}
                                </span>
                              ) : (
                                <span className="text-green-600">
                                  {vendor.daysRemaining} days
                                </span>
                              )}
                            </TableCell>
                            <TableCell>
                              {vendor.subscription_end_date ? (
                                format(new Date(vendor.subscription_end_date), "MMM d, yyyy")
                              ) : (
                                <span className="text-slate-400">N/A</span>
                              )}
                            </TableCell>
                            <TableCell>{vendorListings}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-indigo-600 border-indigo-300 hover:bg-indigo-50"
                                  onClick={() => handleSubscriptionEdit(vendor)}
                                >
                                  <Edit2 className="w-3 h-3 mr-1" />
                                  Edit
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600 border-red-300 hover:bg-red-50"
                                  onClick={() => handleDeactivateVendor(vendor.id)}
                                  disabled={deactivating === vendor.id}
                                >
                                  {deactivating === vendor.id ? "..." : "Deactivate"}
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="properties">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>All Properties</CardTitle>
              </CardHeader>
              <CardContent>
                {properties.length === 0 ? (
                  <p className="text-slate-600 text-center py-8">No properties listed yet</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Title</TableHead>
                        <TableHead>Vendor</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Views</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {properties.map((property) => (
                        <TableRow key={property.id}>
                          <TableCell className="font-medium">{property.title}</TableCell>
                          <TableCell>{property.vendor_name}</TableCell>
                          <TableCell>{property.city}</TableCell>
                          <TableCell>
                            {property.listing_type === 'rent' 
                              ? `${property.rent_amount?.toLocaleString()} /mo`
                              : property.sale_price?.toLocaleString()
                            }
                          </TableCell>
                          <TableCell>
                            <Badge variant={property.status === "available" ? "default" : "secondary"}>
                              {property.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{property.views || 0}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="items">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>All Items</CardTitle>
              </CardHeader>
              <CardContent>
                {listings.length === 0 ? (
                  <p className="text-slate-600 text-center py-8">No items listed yet</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Title</TableHead>
                        <TableHead>Vendor</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Views</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {listings.map((listing) => (
                        <TableRow key={listing.id}>
                          <TableCell className="font-medium">{listing.title}</TableCell>
                          <TableCell>{listing.owner_name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{listing.category?.replace('_', ' ')}</Badge>
                          </TableCell>
                          <TableCell>
                            {listing.listing_type === 'rent' 
                              ? `${listing.rent_amount?.toLocaleString()} /${listing.payment_frequency}`
                              : listing.sale_price?.toLocaleString()
                            }
                          </TableCell>
                          <TableCell>
                            <Badge variant={listing.status === "available" ? "default" : "secondary"}>
                              {listing.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{listing.views || 0}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>All Users</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Account Type</TableHead>
                      <TableHead>Joined</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.full_name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Badge>{user.account_type || "tenant"}</Badge>
                        </TableCell>
                        <TableCell>{format(new Date(user.created_date), "MMM d, yyyy")}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit Subscription Dialog */}
      {editingSubscription && (
        <Dialog open={!!editingSubscription} onOpenChange={() => {
          setEditingSubscription(null); // Close dialog
          setIsUpdatingSubscription(false); // Reset loading state
        }}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Subscription</DialogTitle>
              <DialogDescription>
                Update subscription for {editingSubscription.full_name}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubscriptionUpdate} className="space-y-4">
              <div>
                <Label htmlFor="subscription_status">Status</Label>
                <Select
                  value={subscriptionForm.subscription_status}
                  onValueChange={(value) => setSubscriptionForm({...subscriptionForm, subscription_status: value})}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="subscription_end_date">End Date</Label>
                <Input
                  id="subscription_end_date"
                  type="date"
                  value={subscriptionForm.subscription_end_date}
                  onChange={(e) => setSubscriptionForm({...subscriptionForm, subscription_end_date: e.target.value})}
                  className="mt-2"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="trial_used"
                  checked={subscriptionForm.trial_used}
                  onChange={(e) => setSubscriptionForm({...subscriptionForm, trial_used: e.target.checked})}
                  className="h-4 w-4 rounded border-slate-300"
                />
                <Label htmlFor="trial_used" className="cursor-pointer">
                  Trial Used
                </Label>
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setEditingSubscription(null);
                    setIsUpdatingSubscription(false);
                  }}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isUpdatingSubscription}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                >
                  {isUpdatingSubscription ? "Updating..." : "Update"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
