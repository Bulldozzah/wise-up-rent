
import React, { useState, useEffect, useCallback } from "react";
import { Property } from "@/api/entities";
import { User } from "@/api/entities";
import { Rating } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Building2,
  MapPin,
  Bed,
  Star,
  Check,
  X,
  ChevronLeft,
  ChevronRight,
  ArrowLeft,
  DollarSign,
  Trash2,
  Phone,
  MessageSquare,
  Mail,
  AlertCircle // Added for the alert icon
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import ContactButtons from "../components/property/ContactButtons";
import RatingSection from "../components/property/RatingSection";
import ImageGallery from "../components/property/ImageGallery";
import LocationMap from "../components/property/LocationMap";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger, // Added DialogTrigger
} from "@/components/ui/dialog";

// Added for the subscription expired alert
import { Alert, AlertDescription } from "@/components/ui/alert";


export default function PropertyDetailsPage() {
  const navigate = useNavigate();
  const [property, setProperty] = useState(null);
  const [landlord, setLandlord] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [ratings, setRatings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [vendorSubscriptionExpired, setVendorSubscriptionExpired] = useState(false); // New state for subscription status

  const loadData = useCallback(async () => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get("id");

      if (!propertyId) {
        navigate(createPageUrl("Browse"));
        return;
      }

      const propertyData = await Property.get(propertyId);
      setProperty(propertyData);

      let landlordData = null;
      let isExpiredSubscription = false;

      if (propertyData.vendor_id) {
        landlordData = {
          id: propertyData.vendor_id,
          full_name: propertyData.vendor_name,
          email: propertyData.vendor_email || null,
          phone: propertyData.vendor_phone || null,
          whatsapp: propertyData.vendor_whatsapp || null,
          rating_average: 0,
          rating_count: 0
        };
        
        try {
          const userData = await User.get(propertyData.vendor_id);
          if (userData) {
            if (userData.subscription_end_date) {
              const endDate = new Date(userData.subscription_end_date);
              if (!isNaN(endDate.getTime()) && endDate < new Date()) {
                isExpiredSubscription = true;
              }
            }
            
            // Always update with latest user profile data
            if (userData.email) landlordData.email = userData.email;
            if (userData.phone) landlordData.phone = userData.phone;
            if (userData.whatsapp) landlordData.whatsapp = userData.whatsapp;
          }
        } catch (userError) {
          console.log("Could not fetch user profile data for vendor_id:", propertyData.vendor_id, userError);
        }
        
        setVendorSubscriptionExpired(isExpiredSubscription);

        try {
          const landlordRatings = await Rating.filter({ rated_user_id: propertyData.vendor_id }, "-created_date");
          setRatings(landlordRatings);
          
          if (landlordRatings.length > 0) {
            const avgRating = landlordRatings.reduce((sum, r) => sum + r.rating, 0) / landlordRatings.length;
            landlordData.rating_average = avgRating;
            landlordData.rating_count = landlordRatings.length;
          }
        } catch (error) {
          console.error("Error loading ratings for landlord:", propertyData.vendor_id, error);
        }
      }
      setLandlord(landlordData);

      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        setCurrentUser(null);
      }

      setLoading(false);
    } catch (error) {
      console.error("Error loading property:", error);
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const nextImage = () => {
    if (property.images) {
      setCurrentImageIndex((prev) => (prev + 1) % property.images.length);
    }
  };

  const prevImage = () => {
    if (property.images) {
      setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
    }
  };

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this property? This action cannot be undone.")) {
      return;
    }

    setDeleting(true);
    try {
      await Property.delete(property.id);
      navigate(createPageUrl("MyListings"));
    } catch (error) {
      console.error("Error deleting property:", error);
      alert("Error deleting property. Please try again.");
      setDeleting(false);
    }
  };

  const handleStatusChange = async (newStatus) => {
    if (!confirm(`Are you sure you want to mark this property as "${newStatus}"?`)) {
      return;
    }

    setUpdatingStatus(true);
    try {
      await Property.update(property.id, { status: newStatus });
      await loadData(); // Reload data to reflect the new status immediately
    } catch (error) {
      console.error("Error updating status:", error);
      alert("Error updating status. Please try again.");
    } finally {
      setUpdatingStatus(false);
    }
  };

  const getPropertyTypeLabel = (type, subtype) => {
    const types = {
      residential: "🏠 Residential",
      commercial: "🏢 Commercial",
      land: "🏞️ Land",
      hospitality: "🏨 Hospitality",
      parking_misc: "🚗 Parking"
    };
    
    const subtypes = {
      house: "House",
      townhouse: "Townhouse",
      apartment: "Apartment",
      serviced_apartment: "Serviced Apartment",
      room: "Room",
      student_housing: "Student Housing",
      holiday_home: "Holiday Home",
      office: "Office",
      office_suite: "Office Suite",
      coworking_space: "Coworking Space",
      shop: "Shop",
      warehouse: "Warehouse",
      industrial: "Industrial Building",
      restaurant: "Restaurant/Café",
      residential_plot: "Residential Plot",
      commercial_plot: "Commercial Plot",
      agricultural_land: "Agricultural Land",
      vacant_land: "Vacant Land",
      open_space: "Open Space",
      hotel: "Hotel/Lodge",
      conference_hall: "Conference Hall",
      short_stay: "Short-Stay Rental",
      garage: "Garage",
      parking_space: "Parking Space",
      shade: "Shade/Stall"
    };
    
    const typeLabel = types[type] || "";
    const subtypeLabel = subtypes[subtype] ? `- ${subtypes[subtype]}` : "";

    return `${typeLabel} ${subtypeLabel}`.trim();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="border-0 shadow-xl">
          <CardContent className="pt-6 text-center">
            <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-900 mb-2">Property not found</h3>
            <Button onClick={() => navigate(createPageUrl("Browse"))} className="mt-4">
              Browse Properties
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const userCurrency = currentUser?.currency || "ZMW";
  // Determine if the current user is the owner of the property or an admin
  const isOwner = currentUser && (currentUser.id === property.vendor_id || currentUser.account_type === "admin");
  
  // Check if contact info should be hidden (expired vendor AND viewer is not the owner)
  const shouldHideContactInfo = vendorSubscriptionExpired && !isOwner;

  return (
    <div className="pb-12">
      {/* Image Gallery */}
      <div className="relative h-96 bg-slate-900">
        {property.images && property.images.length > 0 ? (
          <>
            <img
              src={property.images[currentImageIndex]}
              alt={property.title}
              className="w-full h-full object-cover opacity-90"
            />
            {property.images.length > 1 && (
              <>
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                  onClick={prevImage}
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                  onClick={nextImage}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {property.images.map((_, index) => (
                    <div
                      key={index}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentImageIndex ? "bg-white w-8" : "bg-white/50"
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
            {/* Gallery Button */}
            <div className="absolute bottom-4 right-4">
              <ImageGallery images={property.images} propertyTitle={property.title} />
            </div>
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Building2 className="w-24 h-24 text-slate-400" />
          </div>
        )}

        {/* Back Button */}
        <Button
          variant="outline"
          className="absolute top-4 left-4 bg-white/90 hover:bg-white"
          onClick={() => navigate(createPageUrl("Browse"))}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Browse
        </Button>
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-0 shadow-2xl">
              <CardHeader>
                <div className="flex justify-between items-start flex-wrap gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={property.listing_type === "rent" ? "bg-indigo-600" : "bg-purple-600"}>
                        For {property.listing_type === "rent" ? "Rent" : "Sale"}
                      </Badge>
                      <Badge className={`${
                        property.status === "available" ? "bg-green-500" :
                        property.status === "rented" ? "bg-blue-500" :
                        property.status === "sold" ? "bg-gray-500" : "bg-orange-500"
                      }`}>
                        {property.status}
                      </Badge>
                      {property.property_type && (
                        <Badge variant="secondary">
                          {getPropertyTypeLabel(property.property_type, property.property_subtype)}
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-3xl mb-2">{property.title}</CardTitle>
                    {property.city && (
                      <div className="flex items-center gap-2 text-slate-600">
                        <MapPin className="w-5 h-5" />
                        <span>
                          {property.neighborhood && `${property.neighborhood}, `}
                          {property.city}
                          {property.state && `, ${property.state}`}
                          {property.country && `, ${property.country}`}
                        </span>
                      </div>
                    )}
                    {property.address && (
                      <p className="text-sm text-slate-500 ml-7 mt-1">{property.address}</p>
                    )}

                    {/* View Map Button */}
                    {property.latitude && property.longitude && (
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="mt-3 ml-7 gap-2">
                            <MapPin className="w-4 h-4" />
                            View on Map
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl w-full h-[80vh] p-0">
                          <DialogHeader className="p-6 pb-0">
                            <DialogTitle>Property Location</DialogTitle>
                          </DialogHeader>
                          <div className="p-6 pt-4 h-full">
                            <LocationMap
                              latitude={property.latitude}
                              longitude={property.longitude}
                              city={property.city}
                              neighborhood={property.neighborhood}
                              address={property.address}
                              editable={false}
                            />
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}
                  </div>

                  {isOwner && (
                    <div className="flex flex-col gap-2">
                      <Select value={property.status} onValueChange={handleStatusChange} disabled={updatingStatus}>
                        <SelectTrigger className="w-48">
                          <SelectValue placeholder="Update Status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="available">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-green-500" />
                              Available
                            </div>
                          </SelectItem>
                          <SelectItem value="rented">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-blue-500" />
                              Rented
                            </div>
                          </SelectItem>
                          <SelectItem value="sold">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-gray-500" />
                              Sold
                            </div>
                          </SelectItem>
                          <SelectItem value="maintenance">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-orange-500" />
                              Maintenance
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>

                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-600 border-red-300 hover:bg-red-50"
                        onClick={handleDelete}
                        disabled={deleting}
                      >
                        {deleting ? (
                          <>
                            <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin mr-2" />
                            Deleting...
                          </>
                        ) : (
                          <>
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Property
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Redesigned price and security deposit display */}
                <div className="flex justify-between items-center bg-slate-50 p-4 rounded-lg shadow-inner">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-6 h-6 text-indigo-600" />
                    <div>
                      <p className="text-3xl font-bold text-slate-900">
                        {userCurrency} {property.listing_type === "rent"
                          ? property.rent_amount?.toLocaleString()
                          : property.sale_price?.toLocaleString()
                        }
                      </p>
                      <p className="text-slate-600">
                        {property.listing_type === "rent" && "per month"}
                        {property.listing_type === "sale" && "total price"}
                      </p>
                    </div>
                  </div>

                  {property.listing_type === "rent" && property.security_deposit && (
                    <div>
                      <p className="text-sm text-slate-600">Security Deposit</p>
                      <p className="text-xl font-semibold">{userCurrency} {property.security_deposit.toLocaleString()}</p>
                    </div>
                  )}
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-3">Description</h3>
                  <p className="text-slate-600 whitespace-pre-wrap">{property.description}</p>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-4">Property Details</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3">
                      <Bed className="w-5 h-5 text-indigo-600" />
                      <span><strong>{property.bedrooms}</strong> Bedrooms</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-4">Additional Rooms</h3>
                  <div className="grid md:grid-cols-2 gap-3">
                    {property.has_kitchen && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Kitchen</span>
                      </div>
                    )}
                    {property.has_dining && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Dining Room</span>
                      </div>
                    )}
                    {property.has_study && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Study Room</span>
                      </div>
                    )}
                    {property.has_garage && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Garage</span>
                      </div>
                    )}
                    {property.has_garden && (
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Garden</span>
                      </div>
                    )}
                  </div>
                </div>

                {property.listing_type === "rent" && (
                  <>
                    <Separator />
                    <div>
                      <h3 className="font-semibold text-lg mb-4">Utilities Included</h3>
                      <div className="grid md:grid-cols-3 gap-3">
                        <div className="flex items-center gap-2">
                          {property.water_included ? (
                            <Check className="w-4 h-4 text-green-600" />
                          ) : (
                            <X className="w-4 h-4 text-red-500" />
                          )}
                          <span>Water Bill</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {property.electricity_included ? (
                            <Check className="w-4 h-4 text-green-600" />
                          ) : (
                            <X className="w-4 h-4 text-red-500" />
                          )}
                          <span>Electricity Bill</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {property.garbage_included ? (
                            <Check className="w-4 h-4 text-green-600" />
                          ) : (
                            <X className="w-4 h-4 text-red-500" />
                          )}
                          <span>Garbage Collection</span>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {property.is_fenced && (
                  <>
                    <Separator />
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Security</h3>
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-600" />
                        <span>Fenced ({property.fence_type} fence)</span>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Location Map */}
            {property.latitude && property.longitude && (
              <Card className="border-0 shadow-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-indigo-600" />
                    Property Location
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-96">
                  <LocationMap
                    latitude={property.latitude}
                    longitude={property.longitude}
                    city={property.city}
                    neighborhood={property.neighborhood}
                    address={property.address}
                    editable={false}
                  />
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar - Owner Info & Contact */}
          <div className="space-y-6">
            {landlord ? (
              <Card className="border-0 shadow-2xl sticky top-6">
                <CardHeader className="bg-gradient-to-br from-indigo-50 to-blue-50">
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-indigo-600" />
                    Property Owner
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 pt-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
                      <span className="text-white font-bold text-2xl">
                        {landlord?.full_name?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-xl text-slate-900">{landlord?.full_name}</p>
                      {landlord?.rating_average > 0 && (
                        <div className="flex items-center gap-1 mt-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                          <span className="font-semibold">{landlord.rating_average.toFixed(1)}</span>
                          <span className="text-sm text-slate-500">({landlord.rating_count} reviews)</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator />

                  {shouldHideContactInfo ? (
                    <Alert className="border-red-200 bg-red-50">
                      <AlertCircle className="h-4 w-4 text-red-600" />
                      <AlertDescription className="text-red-900 text-sm">
                        This vendor's subscription has expired. Contact information is temporarily unavailable until they renew their subscription.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <>
                      {/* Contact Information Display */}
                      <div className="space-y-3 bg-slate-50 p-4 rounded-lg">
                        <h3 className="font-semibold text-slate-900 mb-3">Contact Information</h3>
                        
                        {landlord.phone && (
                          <div className="flex items-center gap-2 text-slate-700">
                            <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center">
                              <Phone className="w-4 h-4 text-indigo-600" />
                            </div>
                            <div>
                              <p className="text-xs text-slate-500">Phone</p>
                              <p className="font-medium">{landlord.phone}</p>
                            </div>
                          </div>
                        )}

                        {landlord.whatsapp && (
                          <div className="flex items-center gap-2 text-slate-700">
                            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                              <MessageSquare className="w-4 h-4 text-green-600" />
                            </div>
                            <div>
                              <p className="text-xs text-slate-500">WhatsApp</p>
                              <p className="font-medium">{landlord.whatsapp}</p>
                            </div>
                          </div>
                        )}

                        {landlord.email && (
                          <div className="flex items-center gap-2 text-slate-700">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <Mail className="w-4 h-4 text-blue-600" />
                            </div>
                            <div>
                              <p className="text-xs text-slate-500">Email</p>
                              <p className="font-medium text-sm break-all">{landlord.email}</p>
                            </div>
                          </div>
                        )}
                        {!(landlord.phone || landlord.whatsapp || landlord.email) && (
                          <p className="text-sm text-slate-500 text-center py-2">Owner has not provided contact information yet.</p>
                        )}
                      </div>

                      <Separator />

                      {/* Contact Buttons */}
                      <div>
                        <h3 className="font-semibold text-slate-900 mb-3">Get In Touch</h3>
                        <ContactButtons landlord={landlord} property={property} />
                      </div>
                    </>
                  )}

                  <Separator />

                  {/* Rating Section */}
                  <RatingSection
                    property={property}
                    landlord={landlord}
                    currentUser={currentUser}
                    ratings={ratings}
                    onRatingSubmitted={loadData}
                  />
                </CardContent>
              </Card>
            ) : (
              <Card className="border-0 shadow-2xl sticky top-6">
                <CardContent className="pt-6 text-center">
                  <p className="text-slate-500">Owner information not available</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
