

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { Building2, Home, Search, PlusCircle, User as UserIcon, Shield, Users, LogOut, Menu, MapPin } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Check if profile is incomplete and redirect to profile setup
      const isProfileIncomplete = !currentUser.country || !currentUser.phone || !currentUser.whatsapp;
      const isOnProfileSetupPage = window.location.pathname.includes('ProfileSetup');
      
      if (isProfileIncomplete && !isOnProfileSetupPage) {
        window.location.href = createPageUrl("ProfileSetup");
        return; // Stop further execution if redirecting
      }
    } catch (error) {
      setUser(null);
    }
    setLoading(false);
  };

  const handleLogout = async () => {
    await User.logout();
    window.location.href = createPageUrl("Home");
  };

  const getNavItems = () => {
    if (!user) return [];

    // Check if vendor subscription is expired
    const isVendorExpired = user.account_type === "vendor" && 
      user.subscription_end_date && 
      new Date(user.subscription_end_date) < new Date();

    const baseItems = [
      { title: "Home", url: createPageUrl("Home"), icon: Home, show: true },
      { title: "About", url: createPageUrl("About"), icon: Building2, show: true }, // Added About page link, preserved from previous version
      { title: "Browse Properties", url: createPageUrl("Browse"), icon: Building2, show: true },
      { title: "Browse Items", url: createPageUrl("BrowseItems"), icon: Search, show: true },
      { title: "Browse Lodges", url: createPageUrl("BrowseLodges"), icon: Building2, show: true }, // New: Browse Lodges page link
      { title: "Contact Us", url: createPageUrl("ContactUs"), icon: Users, show: true } // New: Contact Us page link
    ];

    const tenantItems = [
      { title: "Become Vendor", url: createPageUrl("BecomeVendor"), icon: Building2, show: user.account_type === "tenant" }
    ];

    const vendorItems = [
      { title: "My Listings", url: createPageUrl("MyListings"), icon: Building2, show: user.account_type === "vendor" },
      { title: "My Lodges", url: createPageUrl("MyLodges"), icon: Building2, show: user.account_type === "vendor" }, // New: My Lodges for vendor
      { 
        title: "Add Property", 
        url: isVendorExpired ? createPageUrl("BecomeVendor?action=renew") : createPageUrl("AddProperty"), 
        icon: PlusCircle, 
        show: user.account_type === "vendor" 
      },
      { 
        title: "Add Item", 
        url: isVendorExpired ? createPageUrl("BecomeVendor?action=renew") : createPageUrl("AddItem"), 
        icon: PlusCircle, 
        show: user.account_type === "vendor" 
      },
      { 
        title: "Add Lodge", // New: Add Lodge for vendor
        url: isVendorExpired ? createPageUrl("BecomeVendor?action=renew") : createPageUrl("AddLodge"), 
        icon: PlusCircle, 
        show: user.account_type === "vendor" 
      }
    ];

    const adminItems = [
      { title: "Admin Panel", url: createPageUrl("AdminPanel"), icon: Shield, show: user.account_type === "admin" },
      { title: "All Listings", url: createPageUrl("MyListings"), icon: Building2, show: user.account_type === "admin" },
      { title: "All Lodges", url: createPageUrl("MyLodges"), icon: Building2, show: user.account_type === "admin" }, // New: All Lodges for admin
      { title: "Add Property", url: createPageUrl("AddProperty"), icon: PlusCircle, show: user.account_type === "admin" },
      { title: "Add Item", url: createPageUrl("AddItem"), icon: PlusCircle, show: user.account_type === "admin" },
      { title: "Add Lodge", url: createPageUrl("AddLodge"), icon: PlusCircle, show: user.account_type === "admin" }, // New: Add Lodge for admin
      { title: "User Management", url: createPageUrl("Users"), icon: Users, show: user.account_type === "admin" },
      { title: "View Feedback", url: createPageUrl("ViewFeedback"), icon: Users, show: user.account_type === "admin" }, // New: Feedback management for admin
      { title: "Manage Ads", url: createPageUrl("ManageAds"), icon: Users, show: user.account_type === "admin" }
    ];

    const profileItems = [
      { title: "My Profile", url: createPageUrl("Profile"), icon: UserIcon, show: true }
    ];

    return [...baseItems, ...tenantItems, ...vendorItems, ...adminItems, ...profileItems].filter(item => item.show);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  // Modified condition: The sidebar will now be visible on the Home page if a user is logged in.
  if (!user) {
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <div className="flex-1">{children}</div>
        
        {/* Footer for non-logged in users */}
        <footer className="bg-slate-900 text-white py-8 mt-12">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-8 mb-6">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68dbd0d5777db8b9f2c81d1f/d583bab4e_logoWUR.png" 
                    alt="WiseUpRent Logo" 
                    className="w-12 h-12 object-contain"
                  />
                  <div>
                    <h3 className="font-bold text-lg">WiseUpRent</h3>
                    <p className="text-xs text-slate-400">Simply Find It</p>
                  </div>
                </div>
                <p className="text-sm text-slate-400">
                  Your trusted marketplace for properties and items in Zambia.
                </p>
              </div>

              <div>
                <h4 className="font-semibold mb-3">Quick Links</h4>
                <ul className="space-y-2 text-sm text-slate-400">
                  <li>
                    <Link to={createPageUrl("Home")} className="hover:text-white transition-colors">
                      Home
                    </Link>
                  </li>
                  <li>
                    <Link to={createPageUrl("About")} className="hover:text-white transition-colors">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <Link to={createPageUrl("Browse")} className="hover:text-white transition-colors">
                      Browse Properties
                    </Link>
                  </li>
                  <li>
                    <Link to={createPageUrl("BrowseItems")} className="hover:text-white transition-colors">
                      Browse Items
                    </Link>
                  </li>
                  <li>
                    <Link to={createPageUrl("BrowseLodges")} className="hover:text-white transition-colors">
                      Browse Lodges
                    </Link>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-3">Contact Us</h4>
                <ul className="space-y-2 text-sm text-slate-400">
                  <li className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Lusaka, Zambia
                  </li>
                  <li className="flex items-center gap-2">
                    <span>📞</span>
                    <a href="tel:+260973433321" className="hover:text-white transition-colors">
                      +260 973 433 321
                    </a>
                  </li>
                  <li className="flex items-center gap-2">
                    <span>📧</span>
                    <a href="mailto:wiseuprent@gmail.com" className="hover:text-white transition-colors">
                      wiseuprent@gmail.com
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            <div className="border-t border-slate-800 pt-6 text-center text-sm text-slate-400">
              <p>&copy; {new Date().getFullYear()} WiseUpRent. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <Sidebar className="border-r border-slate-200 bg-white/80 backdrop-blur-xl">
          <SidebarHeader className="border-b border-slate-200 p-6">
            <div className="flex items-center gap-3">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68dbd0d5777db8b9f2c81d1f/d583bab4e_logoWUR.png" 
                alt="WiseUpRent Logo" 
                className="w-10 h-10 object-contain"
              />
              <div>
                <h2 className="font-bold text-slate-900 text-lg">WiseUpRent</h2>
                <p className="text-xs text-slate-500">Rent Anything</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-3">
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  {getNavItems().map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-indigo-50 hover:text-indigo-700 transition-all rounded-xl mb-1 ${
                          location.pathname === item.url ? 'bg-indigo-50 text-indigo-700 shadow-sm' : ''
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-200 p-4">
            <div className="space-y-3">
              <div className="flex items-center gap-3 px-2">
                <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-sm">
                    {user.full_name?.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-slate-900 text-sm truncate">{user.full_name}</p>
                  <Badge variant="secondary" className="text-xs">
                    {user.account_type}
                  </Badge>
                </div>
              </div>
              <Button
                variant="outline"
                className="w-full justify-start gap-2 text-slate-600 hover:text-red-600 hover:border-red-200"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white/80 backdrop-blur-xl border-b border-slate-200 px-6 py-4 md:hidden sticky top-0 z-40">
            <div className="flex items-center justify-between">
              <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg">
                <Menu className="w-5 h-5" />
              </SidebarTrigger>
              <h1 className="text-lg font-bold text-slate-900">WiseUpRent</h1>
              <div className="w-9" />
            </div>
          </header>

          <div className="flex-1 flex flex-col overflow-auto">
            <div className="flex-1">{children}</div>

            {/* Footer for logged in users */}
            <footer className="bg-slate-900 text-white py-8 mt-12">
              <div className="max-w-7xl mx-auto px-6">
                <div className="grid md:grid-cols-3 gap-8 mb-6">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <img 
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68dbd0d5777db8b9f2c81d1f/d583bab4e_logoWUR.png" 
                        alt="WiseUpRent Logo" 
                        className="w-12 h-12 object-contain"
                      />
                      <div>
                        <h3 className="font-bold text-lg">WiseUpRent</h3>
                        <p className="text-xs text-slate-400">Simply Find It</p>
                      </div>
                    </div>
                    <p className="text-sm text-slate-400">
                      Your trusted marketplace for properties and items in Zambia.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3">Quick Links</h4>
                    <ul className="space-y-2 text-sm text-slate-400">
                      <li>
                        <Link to={createPageUrl("Home")} className="hover:text-white transition-colors">
                          Home
                        </Link>
                      </li>
                      <li>
                        <Link to={createPageUrl("About")} className="hover:text-white transition-colors">
                          About Us
                        </Link>
                      </li>
                      <li>
                        <Link to={createPageUrl("Browse")} className="hover:text-white transition-colors">
                          Browse Properties
                        </Link>
                      </li>
                      <li>
                        <Link to={createPageUrl("BrowseItems")} className="hover:text-white transition-colors">
                          Browse Items
                        </Link>
                      </li>
                      <li>
                        <Link to={createPageUrl("BrowseLodges")} className="hover:text-white transition-colors">
                          Browse Lodges
                        </Link>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3">Contact Us</h4>
                    <ul className="space-y-2 text-sm text-slate-400">
                      <li className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        Lusaka, Zambia
                      </li>
                      <li className="flex items-center gap-2">
                        <span>📞</span>
                        <a href="tel:+260973433321" className="hover:text-white transition-colors">
                          +260 973 433 321
                        </a>
                      </li>
                      <li className="flex items-center gap-2">
                        <span>📧</span>
                        <a href="mailto:wiseuprent@gmail.com" className="hover:text-white transition-colors">
                          wiseuprent@gmail.com
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="border-t border-slate-800 pt-6 text-center text-sm text-slate-400">
                  <p>&copy; {new Date().getFullYear()} WiseUpRent. All rights reserved.</p>
                </div>
              </div>
            </footer>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

