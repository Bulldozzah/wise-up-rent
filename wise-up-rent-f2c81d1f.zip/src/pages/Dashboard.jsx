
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Listing } from "@/api/entities";
import { VendorRequest } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Building2, Search, Star, Home, UserPlus, Clock, Eye, MapPin, Bed, ArrowRight, AlertCircle, Users, Shield, PlusCircle } from "lucide-react";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [listings, setListings] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [needsProfile, setNeedsProfile] = useState(false);
  const [daysRemaining, setDaysRemaining] = useState(null);
  const [subscriptionType, setSubscriptionType] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    let currentUser = await User.me(); // Use `let` to allow re-assignment if user data is updated
    
    // Debug log
    console.log("Dashboard - Current user:", {
      id: currentUser.id,
      email: currentUser.email,
      account_type: currentUser.account_type,
      full_name: currentUser.full_name, // Include full_name in debug log for better visibility
      subscription_end_date: currentUser.subscription_end_date
    });
    
    // Set default account type if not set
    if (!currentUser.account_type) {
      const updatedUser = await User.updateMyUserData({ account_type: "tenant" });
      // If the update function returns the full updated user object, use it to ensure
      // the `currentUser` state reflects the latest data, including any other fields
      // that might have been updated.
      if (updatedUser && updatedUser.account_type) { 
        currentUser = updatedUser; // Overwrite `currentUser` with the freshly updated object
      } else {
        // Fallback: if `updateMyUserData` doesn't return the full user,
        // we at least ensure `account_type` is set locally for the current session.
        currentUser.account_type = "tenant"; 
      }
    }
    
    setUser(currentUser); // Set the component's state with the potentially updated currentUser object.

    if (!currentUser.phone || !currentUser.whatsapp) {
      setNeedsProfile(true);
    }

    // Calculate days remaining for vendors and get subscription type
    if (currentUser.account_type === "vendor" && currentUser.subscription_end_date) {
      const now = new Date();
      const endDate = new Date(currentUser.subscription_end_date);
      const diffTime = endDate - now;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setDaysRemaining(diffDays);
      
      // Trial is now 30 days, so check if they're close to that
      if (currentUser.trial_used === false || diffDays >= 25) { // Changed from `diffDays === 15` for 15-day trial to `diffDays >= 25` for 30-day trial heuristic
        setSubscriptionType("30-Day Trial"); // Changed label from "15-Day Trial"
      } else {
        setSubscriptionType("K20/30 Days");
      }
    }

    if (currentUser.account_type === "vendor") {
      console.log("Loading vendor listings with owner_id:", currentUser.id);
      
      try {
        const myListings = await Listing.filter({ owner_id: currentUser.id }, "-created_date");
        console.log("Vendor listings loaded:", myListings.length, myListings);
        setListings(myListings);
        setStats({
          total: myListings.length,
          available: myListings.filter(p => p.status === "available").length,
          rented: myListings.filter(p => p.status === "rented").length,
          views: myListings.reduce((sum, p) => sum + (p.views || 0), 0)
        });
      } catch (error) {
        console.error("Error loading vendor listings:", error);
        setListings([]);
        setStats({ total: 0, available: 0, rented: 0, views: 0 });
      }
    } else if (currentUser.account_type === "admin") {
      const [allListings, requests, allUsers] = await Promise.all([
        Listing.list("-created_date"),
        VendorRequest.filter({ status: "pending" }),
        User.list()
      ]);
      setListings(allListings.slice(0, 5));
      setStats({
        listings: allListings.length,
        pending: requests.length,
        users: allUsers.length,
        owners: allUsers.filter(u => u.account_type === "vendor").length
      });
    } else { // This branch handles "tenant" account type or any other default
      const available = await Listing.filter({ status: "available" }, "-created_date");
      setListings(available.slice(0, 6));
      setStats({
        available: available.length
      });
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
          Welcome, {user.full_name} 👋
        </h1>
        <p className="text-slate-600 text-lg">
          {user.account_type === "tenant" && "Find anything you need to rent"}
          {user.account_type === "vendor" && "Manage your listings"}
          {user.account_type === "admin" && "Platform overview"}
        </p>
      </div>

      {needsProfile && (
        <Alert className="mb-6 border-orange-200 bg-orange-50">
          <AlertCircle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-900 flex items-center justify-between">
            <span>Complete your profile to connect with others</span>
            <Link to={createPageUrl("Profile")}>
              <Button size="sm" className="bg-orange-600 hover:bg-orange-700 ml-4">
                Complete Profile
              </Button>
            </Link>
          </AlertDescription>
        </Alert>
      )}

      {/* Vendor Subscription Alert */}
      {user.account_type === "vendor" && daysRemaining !== null && (
        <Alert className={`mb-6 ${
          daysRemaining <= 0 ? 'border-red-200 bg-red-50' :
          daysRemaining <= 5 ? 'border-yellow-200 bg-yellow-50' :
          'border-blue-200 bg-blue-50'
        }`}>
          <Clock className={`h-4 w-4 ${
            daysRemaining <= 0 ? 'text-red-600' :
            daysRemaining <= 5 ? 'text-yellow-600' :
            'text-blue-600'
          }`} />
          <AlertDescription className={
            daysRemaining <= 0 ? 'text-red-900' :
            daysRemaining <= 5 ? 'text-yellow-900' :
            'text-blue-900'
          }>
            {daysRemaining <= 0 ? (
              <>
                Your subscription has expired. Please renew to continue listing items.
                <Link to={createPageUrl("BecomeVendor")} className="ml-2 underline font-semibold">
                  Renew Now
                </Link>
              </>
            ) : daysRemaining === 1 ? (
              `Your subscription expires tomorrow. Renew soon to avoid interruption.`
            ) : (
              `Your subscription expires in ${daysRemaining} days.`
            )}
          </AlertDescription>
        </Alert>
      )}

      {/* Tenant View */}
      {user.account_type === "tenant" && (
        <>
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card className="border-0 shadow-xl bg-gradient-to-br from-indigo-600 to-blue-500 text-white overflow-hidden relative">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white opacity-10 rounded-full -mr-20 -mt-20" />
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-3">
                  <Building2 className="w-7 h-7" />
                  Browse Properties
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-indigo-100 text-lg">
                  Find houses, apartments, and spaces
                </p>
                <Link to={createPageUrl("Browse")}>
                  <Button className="bg-white text-indigo-600 hover:bg-indigo-50 font-semibold">
                    Start Searching
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-purple-600 to-pink-500 text-white overflow-hidden relative">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white opacity-10 rounded-full -mr-20 -mt-20" />
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-3">
                  <Search className="w-7 h-7" />
                  Browse Items
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-purple-100 text-lg">
                  Vehicles, equipment, and more
                </p>
                <Link to={createPageUrl("BrowseItems")}>
                  <Button className="bg-white text-purple-600 hover:bg-purple-50 font-semibold">
                    Explore Items
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <Card className="border-0 shadow-xl mb-6">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-2xl">Featured Listings</CardTitle>
                <div className="flex gap-2">
                  <Link to={createPageUrl("Browse")}>
                    <Button variant="outline" size="sm">Properties</Button>
                  </Link>
                  <Link to={createPageUrl("BrowseItems")}>
                    <Button variant="outline" size="sm">Items</Button>
                  </Link>
                </div>
              </div> {/* Closing div tag added here */}
            </CardHeader>
            <CardContent>
              {listings.length === 0 ? (
                <div className="text-center py-12">
                  <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">No Listings Yet</h3>
                  <p className="text-slate-600">Check back soon for new listings!</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-3 gap-6">
                  {listings.map((listing) => (
                    <Link key={listing.id} to={createPageUrl(`Listing?id=${listing.id}`)}>
                      <Card className="border shadow-md hover:shadow-xl transition-all cursor-pointer transform hover:-translate-y-1 overflow-hidden">
                        <div className="relative h-48 bg-slate-200">
                          {listing.images?.[0] ? (
                            <img src={listing.images[0]} alt={listing.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Building2 className="w-12 h-12 text-slate-400" />
                            </div>
                          )}
                          <Badge className="absolute top-3 right-3 bg-green-500">Available</Badge>
                        </div>
                        <CardContent className="p-4">
                          <h3 className="font-bold text-lg mb-2 line-clamp-1">{listing.title}</h3>
                          <div className="flex items-center gap-2 text-slate-600 mb-3 text-sm">
                            <MapPin className="w-4 h-4" />
                            <span className="line-clamp-1">{listing.city}</span>
                          </div>
                          <div className="flex items-center justify-between pt-3 border-t">
                            <div>
                              <span className="font-bold text-xl text-indigo-600">
                                {user?.currency || "TZS"} {listing.listing_type === "rent"
                                  ? listing.rent_amount?.toLocaleString()
                                  : listing.sale_price?.toLocaleString()
                                }
                              </span>
                              <div className="text-xs text-slate-500">
                                {listing.listing_type === "rent" && "/mo"}
                              </div>
                            </div>
                            {listing.bedrooms && (
                              <div className="flex items-center gap-1 text-slate-600">
                                <Bed className="w-4 h-4" />
                                <span className="text-sm">{listing.bedrooms}</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl bg-gradient-to-br from-orange-500 to-red-500 text-white">
            <CardContent className="p-8 text-center">
              <UserPlus className="w-12 h-12 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">Become a Vendor</h3>
              <p className="text-orange-100 mb-6">List your items and properties to earn income</p>
              <Link to={createPageUrl("BecomeVendor")}>
                <Button className="bg-white text-orange-600 hover:bg-orange-50 font-semibold">
                  Apply Now
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </>
      )}

      {/* Vendor View */}
      {user.account_type === "vendor" && (
        <>
          {/* Subscription Info Card */}
          {daysRemaining !== null && (
            <Card className={`mb-6 border-0 shadow-xl ${
              daysRemaining <= 0 ? 'bg-gradient-to-br from-red-500 to-red-600' :
              daysRemaining <= 5 ? 'bg-gradient-to-br from-yellow-500 to-orange-500' :
              'bg-gradient-to-br from-blue-500 to-indigo-600'
            } text-white`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90 mb-1">Current Plan</p>
                    <p className="text-2xl font-bold">{subscriptionType}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm opacity-90 mb-1">
                      {daysRemaining <= 0 ? 'Expired' : 'Days Remaining'}
                    </p>
                    <p className="text-3xl font-bold">
                      {daysRemaining <= 0 ? Math.abs(daysRemaining) : daysRemaining}
                    </p>
                    {daysRemaining <= 0 && (
                      <Link to={createPageUrl("BecomeVendor")}>
                        <Button size="sm" className="mt-2 bg-white text-red-600 hover:bg-red-50">
                          Renew Now
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="border-0 shadow-xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-indigo-100 text-sm mb-1">Total Listings</p>
                    <p className="text-4xl font-bold">{stats.total}</p>
                  </div>
                  <Building2 className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-green-100 text-sm mb-1">Available</p>
                    <p className="text-4xl font-bold">{stats.available}</p>
                  </div>
                  <Home className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-blue-100 text-sm mb-1">Total Views</p>
                    <p className="text-4xl font-bold">{stats.views}</p>
                  </div>
                  <Eye className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-yellow-500 to-orange-500 text-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-yellow-100 text-sm mb-1">Rating</p>
                    <p className="text-4xl font-bold">{(user.rating_average || 0).toFixed(1)}★</p>
                  </div>
                  <Star className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <Link to={createPageUrl("AddProperty")}>
              <Card className="border-0 shadow-xl hover:shadow-2xl transition-shadow cursor-pointer bg-gradient-to-br from-indigo-50 to-blue-50">
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-blue-600 rounded-xl flex items-center justify-center">
                    <Building2 className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-slate-900">Add Property</h3>
                    <p className="text-slate-600">List a house or apartment</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link to={createPageUrl("AddItem")}>
              <Card className="border-0 shadow-xl hover:shadow-2xl transition-shadow cursor-pointer bg-gradient-to-br from-purple-50 to-pink-50">
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center">
                    <PlusCircle className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-slate-900">Add Item</h3>
                    <p className="text-slate-600">List vehicles, equipment, etc.</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </>
      )}

      {/* Admin View */}
      {user.account_type === "admin" && (
        <>
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="border-0 shadow-xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-indigo-100 text-sm mb-1">Total Listings</p>
                    <p className="text-4xl font-bold">{stats.listings}</p>
                  </div>
                  <Building2 className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-orange-500 to-orange-600 text-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-orange-100 text-sm mb-1">Pending Requests</p>
                    <p className="text-4xl font-bold">{stats.pending}</p>
                  </div>
                  <Clock className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-blue-100 text-sm mb-1">Total Users</p>
                    <p className="text-4xl font-bold">{stats.users}</p>
                  </div>
                  <Users className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-green-100 text-sm mb-1">Vendors</p>
                    <p className="text-4xl font-bold">{stats.owners}</p>
                  </div>
                  <Home className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Link to={createPageUrl("AdminPanel")}>
              <Card className="border-0 shadow-xl hover:shadow-2xl transition-shadow cursor-pointer bg-gradient-to-br from-indigo-600 to-blue-600 text-white">
                <CardContent className="p-8 flex items-center justify-between">
                  <div>
                    <h3 className="text-2xl font-bold mb-2">Admin Panel</h3>
                    <p className="text-indigo-100">Manage requests and listings</p>
                  </div>
                  <Shield className="w-12 h-12 opacity-80" />
                </CardContent>
              </Card>
            </Link>

            <Link to={createPageUrl("Users")}>
              <Card className="border-0 shadow-xl hover:shadow-2xl transition-shadow cursor-pointer bg-gradient-to-br from-blue-600 to-indigo-600 text-white">
                <CardContent className="p-8 flex items-center justify-between">
                  <div>
                    <h3 className="text-2xl font-bold mb-2">User Management</h3>
                    <p className="text-blue-100">Manage user roles</p>
                  </div>
                  <Users className="w-12 h-12 opacity-80" />
                </CardContent>
              </Card>
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
