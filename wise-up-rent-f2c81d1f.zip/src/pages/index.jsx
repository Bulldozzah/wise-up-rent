import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import BecomeLandlord from "./BecomeLandlord";

import AdminPanel from "./AdminPanel";

import AddProperty from "./AddProperty";

import MyProperties from "./MyProperties";

import PropertySearch from "./PropertySearch";

import PropertyDetails from "./PropertyDetails";

import Profile from "./Profile";

import Home from "./Home";

import UserManagement from "./UserManagement";

import Browse from "./Browse";

import Admin from "./Admin";

import Users from "./Users";

import Property from "./Property";

import EditProperty from "./EditProperty";

import BrowseItems from "./BrowseItems";

import AddItem from "./AddItem";

import BecomeVendor from "./BecomeVendor";

import MyListings from "./MyListings";

import ProfileSetup from "./ProfileSetup";

import Listing from "./Listing";

import ManageAds from "./ManageAds";

import About from "./About";

import ContactUs from "./ContactUs";

import ViewFeedback from "./ViewFeedback";

import AddLodge from "./AddLodge";

import ManageRooms from "./ManageRooms";

import BrowseLodges from "./BrowseLodges";

import LodgeDetails from "./LodgeDetails";

import MyLodges from "./MyLodges";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    BecomeLandlord: BecomeLandlord,
    
    AdminPanel: AdminPanel,
    
    AddProperty: AddProperty,
    
    MyProperties: MyProperties,
    
    PropertySearch: PropertySearch,
    
    PropertyDetails: PropertyDetails,
    
    Profile: Profile,
    
    Home: Home,
    
    UserManagement: UserManagement,
    
    Browse: Browse,
    
    Admin: Admin,
    
    Users: Users,
    
    Property: Property,
    
    EditProperty: EditProperty,
    
    BrowseItems: BrowseItems,
    
    AddItem: AddItem,
    
    BecomeVendor: BecomeVendor,
    
    MyListings: MyListings,
    
    ProfileSetup: ProfileSetup,
    
    Listing: Listing,
    
    ManageAds: ManageAds,
    
    About: About,
    
    ContactUs: ContactUs,
    
    ViewFeedback: ViewFeedback,
    
    AddLodge: AddLodge,
    
    ManageRooms: ManageRooms,
    
    BrowseLodges: BrowseLodges,
    
    LodgeDetails: LodgeDetails,
    
    MyLodges: MyLodges,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/BecomeLandlord" element={<BecomeLandlord />} />
                
                <Route path="/AdminPanel" element={<AdminPanel />} />
                
                <Route path="/AddProperty" element={<AddProperty />} />
                
                <Route path="/MyProperties" element={<MyProperties />} />
                
                <Route path="/PropertySearch" element={<PropertySearch />} />
                
                <Route path="/PropertyDetails" element={<PropertyDetails />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/UserManagement" element={<UserManagement />} />
                
                <Route path="/Browse" element={<Browse />} />
                
                <Route path="/Admin" element={<Admin />} />
                
                <Route path="/Users" element={<Users />} />
                
                <Route path="/Property" element={<Property />} />
                
                <Route path="/EditProperty" element={<EditProperty />} />
                
                <Route path="/BrowseItems" element={<BrowseItems />} />
                
                <Route path="/AddItem" element={<AddItem />} />
                
                <Route path="/BecomeVendor" element={<BecomeVendor />} />
                
                <Route path="/MyListings" element={<MyListings />} />
                
                <Route path="/ProfileSetup" element={<ProfileSetup />} />
                
                <Route path="/Listing" element={<Listing />} />
                
                <Route path="/ManageAds" element={<ManageAds />} />
                
                <Route path="/About" element={<About />} />
                
                <Route path="/ContactUs" element={<ContactUs />} />
                
                <Route path="/ViewFeedback" element={<ViewFeedback />} />
                
                <Route path="/AddLodge" element={<AddLodge />} />
                
                <Route path="/ManageRooms" element={<ManageRooms />} />
                
                <Route path="/BrowseLodges" element={<BrowseLodges />} />
                
                <Route path="/LodgeDetails" element={<LodgeDetails />} />
                
                <Route path="/MyLodges" element={<MyLodges />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}