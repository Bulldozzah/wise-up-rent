import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, Globe, Phone, MessageSquare, DollarSign } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { countriesWithCurrency, getCurrencyForCountry, getCallingCodeForCountry } from "../components/profile/CountryCurrencyData";

export default function ProfileSetup() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  
  const [formData, setFormData] = useState({
    phone: "",
    whatsapp: "",
    country: "",
    currency: ""
  });

  const loadUser = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      // If user already has required fields, redirect to dashboard
      if (currentUser.country && currentUser.phone && currentUser.whatsapp) {
        navigate(createPageUrl("Dashboard"));
        return;
      }
      
      // Pre-fill if data exists
      if (currentUser.country) {
        const localPhone = extractLocalNumber(currentUser.phone, currentUser.country);
        const localWhatsapp = extractLocalNumber(currentUser.whatsapp, currentUser.country);
        
        setFormData({
          phone: localPhone,
          whatsapp: localWhatsapp,
          country: currentUser.country,
          currency: currentUser.currency || ""
        });
      }
      
      setLoading(false);
    } catch (error) {
      console.error("Error loading user:", error);
      setError("Failed to load user data");
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  const extractLocalNumber = (fullNumber, country) => {
    if (!fullNumber || !country) return "";
    const callingCode = getCallingCodeForCountry(country);
    if (fullNumber.startsWith(callingCode) && callingCode !== "") {
      return fullNumber.substring(callingCode.length).replace(/^[-\s]+|[-,.\s]+$/g, '').trim();
    }
    return fullNumber.trim();
  };

  const handleCountryChange = (country) => {
    const currencyData = getCurrencyForCountry(country);
    setFormData(prevFormData => ({
      ...prevFormData,
      country: country,
      currency: currencyData ? currencyData.code : ""
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    
    // Validation
    if (!formData.country) {
      setError("Please select your country");
      return;
    }
    if (!formData.phone || formData.phone.length < 7) {
      setError("Please enter a valid phone number");
      return;
    }
    if (!formData.whatsapp || formData.whatsapp.length < 7) {
      setError("Please enter a valid WhatsApp number");
      return;
    }
    
    setSubmitting(true);

    try {
      const callingCode = getCallingCodeForCountry(formData.country);
      
      const dataToSave = {
        phone: `${callingCode}${formData.phone.replace(/[\s-]/g, '')}`,
        whatsapp: `${callingCode}${formData.whatsapp.replace(/[\s-]/g, '')}`,
        country: formData.country,
        currency: formData.currency,
        account_type: "tenant" // All new users default to tenant
      };

      await User.updateMyUserData(dataToSave);
      
      // Redirect to dashboard after successful profile setup
      navigate(createPageUrl("Dashboard"));
    } catch (error) {
      console.error("Error saving profile:", error);
      setError("Failed to save profile. Please try again.");
    }

    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const currentCallingCode = formData.country ? getCallingCodeForCountry(formData.country) : "";

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <Card className="max-w-2xl w-full border-0 shadow-2xl">
        <CardHeader className="text-center pb-4">
          <div className="w-20 h-20 bg-gradient-to-br from-indigo-600 to-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold">Complete Your Profile</CardTitle>
          <p className="text-slate-600 mt-2">
            Welcome to WiseUpRent! Please complete your profile to get started.
          </p>
        </CardHeader>
        <CardContent className="pt-2">
          {error && (
            <Alert className="mb-6 border-red-200 bg-red-50">
              <AlertDescription className="text-red-900">{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="country" className="flex items-center gap-2 text-base font-semibold">
                <Globe className="w-4 h-4" />
                Country *
              </Label>
              <Select
                value={formData.country}
                onValueChange={handleCountryChange}
                required
              >
                <SelectTrigger className="mt-2 h-12">
                  <SelectValue placeholder="Select your country" />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {countriesWithCurrency.map((item) => (
                    <SelectItem key={item.country} value={item.country}>
                      {item.country}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="currency" className="flex items-center gap-2 text-base font-semibold">
                <DollarSign className="w-4 h-4" />
                Currency
              </Label>
              <Input
                id="currency"
                value={formData.currency ? `${getCurrencyForCountry(formData.country)?.currency || ""} (${formData.currency})` : ""}
                disabled
                className="mt-2 h-12 bg-slate-50"
                placeholder="Select country first"
              />
              <p className="text-xs text-slate-500 mt-1">
                Auto-filled based on your country
              </p>
            </div>

            <div>
              <Label htmlFor="phone" className="flex items-center gap-2 text-base font-semibold">
                <Phone className="w-4 h-4" />
                Phone Number *
              </Label>
              <div className="flex items-center mt-2">
                {formData.country && (
                  <span className="px-4 py-3 border border-r-0 rounded-l-md bg-gray-100 text-gray-700 font-medium">
                    {currentCallingCode}
                  </span>
                )}
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  placeholder="e.g., 712 345 678"
                  required
                  className={`h-12 ${formData.country ? 'rounded-l-none' : ''}`}
                />
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {formData.country 
                  ? `Your local number will be saved as ${currentCallingCode}${formData.phone}` 
                  : "Select your country first to see the calling code"}
              </p>
            </div>

            <div>
              <Label htmlFor="whatsapp" className="flex items-center gap-2 text-base font-semibold">
                <MessageSquare className="w-4 h-4" />
                WhatsApp Number *
              </Label>
              <div className="flex items-center mt-2">
                {formData.country && (
                  <span className="px-4 py-3 border border-r-0 rounded-l-md bg-gray-100 text-gray-700 font-medium">
                    {currentCallingCode}
                  </span>
                )}
                <Input
                  id="whatsapp"
                  type="tel"
                  value={formData.whatsapp}
                  onChange={(e) => setFormData({...formData, whatsapp: e.target.value})}
                  placeholder="e.g., 712 345 678"
                  required
                  className={`h-12 ${formData.country ? 'rounded-l-none' : ''}`}
                />
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Users can contact you via WhatsApp
              </p>
            </div>

            <Alert className="border-indigo-200 bg-indigo-50">
              <AlertDescription className="text-indigo-900 text-sm">
                <strong>Note:</strong> You'll start as a tenant and can browse items to rent. Want to list your own items? You can apply to become a vendor anytime from your dashboard!
              </AlertDescription>
            </Alert>

            <Button
              type="submit"
              disabled={submitting}
              className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-lg py-6 shadow-lg"
            >
              {submitting ? "Saving Profile..." : "Complete Setup & Continue"}
            </Button>

            <p className="text-xs text-center text-slate-500">
              By continuing, you agree to provide accurate contact information
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}