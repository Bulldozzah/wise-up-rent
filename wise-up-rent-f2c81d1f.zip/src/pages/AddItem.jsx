
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Listing } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, X, ImageIcon, Car, Music, Laptop, Shirt, Wrench, Camera, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const categoryOptions = {
  transport_vehicles: {
    label: "Transport & Vehicles",
    icon: Car,
    subcategories: ["Car (Self-drive)", "Car (With driver)", "Bus/Minibus", "Truck/Van", "Motorbike", "Bicycle", "Excavator", "Forklift", "Ambulance", "Hearse", "Other"]
  },
  events_entertainment: {
    label: "Events & Entertainment",
    icon: Music,
    subcategories: ["PA System", "Sound System", "Projector", "LED Screen", "Stage Lighting", "Tent", "Chairs & Tables", "Décor", "Musical Instruments", "Stage Platform", "Other"]
  },
  home_office_equipment: {
    label: "Home & Office Equipment",
    icon: Laptop,
    subcategories: ["Furniture", "Laptop", "Desktop", "Printer", "Copier", "Wi-Fi Router", "Generator", "Air Conditioner", "Fan", "Heater", "Other"]
  },
  personal_lifestyle: {
    label: "Personal & Lifestyle",
    icon: Shirt,
    subcategories: ["Wedding Dress", "Suit/Tuxedo", "Traditional Attire", "Jewelry", "Accessories", "Costume", "Bouncy Castle", "Party Equipment", "Catering Sets", "Other"]
  },
  construction_tools: {
    label: "Construction & Tools",
    icon: Wrench,
    subcategories: ["Scaffolding", "Ladder", "Drill", "Grinder", "Welding Machine", "Tractor", "Bulldozer", "Grader", "Power Tools", "Other"]
  },
  media_technology: {
    label: "Media & Technology",
    icon: Camera,
    subcategories: ["Camera", "Camcorder", "Drone", "VR Set", "Gaming Console", "Printer", "Projector", "Screen", "Other"]
  }
};

export default function AddItem() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [isEditMode, setIsEditMode] = useState(false);
  const [itemId, setItemId] = useState(null);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    listing_type: "rent",
    category: "",
    subcategory: "",
    city: "",
    district: "N/A",
    neighborhood: "N/A",
    address: "N/A",
    images: [],
    rent_amount: "",
    sale_price: "",
    security_deposit: "",
    payment_frequency: "daily",
    brand: "N/A",
    model: "N/A",
    year: "",
    condition: "good",
    quantity_available: "1",
    specifications: {},
    delivery_available: false,
    setup_included: false,
    operator_included: false,
    minimum_rental_period: "N/A"
  });

  const [errors, setErrors] = useState({});
  const [hasAttemptedSubmit, setHasAttemptedSubmit] = useState(false);

  const loadUser = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      // Debug: Log user info
      console.log("Current user in AddItem:", {
        id: currentUser?.id,
        email: currentUser?.email,
        account_type: currentUser?.account_type
      });
      
      // Allow 'vendor' and 'admin' accounts to access this page
      if (!currentUser || (currentUser.account_type !== "vendor" && currentUser.account_type !== "admin")) {
        setError("You are not authorized to access this page.");
        navigate(createPageUrl("Dashboard"));
        return;
      }

      // Check if vendor subscription is expired (skip for admin)
      if (currentUser.account_type === "vendor") {
        const isExpired = currentUser.subscription_end_date && 
          new Date(currentUser.subscription_end_date) < new Date();
        
        if (isExpired) {
          setError("Your subscription has expired. Please renew to add/edit items.");
          navigate(createPageUrl("Dashboard")); // Navigate to Dashboard if subscription is expired
          return;
        }
      }

      // Check if editing existing item
      const urlParams = new URLSearchParams(window.location.search);
      const id = urlParams.get("id");
      
      if (id) {
        setIsEditMode(true);
        setItemId(id);
        
        // Load existing item
        const item = await Listing.get(id);
        
        // Check if user owns this item or is admin
        if (item.owner_id !== currentUser.id && currentUser.account_type !== "admin") {
          setError("You don't have permission to edit this item.");
          navigate(createPageUrl("MyListings"));
          return;
        }
        
        // Populate form with existing data
        setFormData({
          title: item.title || "",
          description: item.description || "",
          listing_type: item.listing_type || "rent",
          category: item.category || "", // Let validation handle if it's empty
          subcategory: item.subcategory || "", // Let validation handle if it's empty
          city: item.city || "",
          district: item.district === "N/A" ? "" : item.district || "",
          neighborhood: item.neighborhood === "N/A" ? "" : item.neighborhood || "",
          address: item.address === "N/A" ? "" : item.address || "",
          images: item.images || [],
          rent_amount: item.rent_amount?.toString() || "",
          sale_price: item.sale_price?.toString() || "",
          security_deposit: item.security_deposit?.toString() || "",
          payment_frequency: item.payment_frequency || "daily",
          brand: item.brand === "N/A" ? "" : item.brand || "",
          model: item.model === "N/A" ? "" : item.model || "",
          year: item.year?.toString() || "",
          condition: item.condition || "good",
          quantity_available: item.quantity_available?.toString() || "1",
          specifications: item.specifications || {},
          delivery_available: item.delivery_available ?? false,
          setup_included: item.setup_included ?? false,
          operator_included: item.operator_included ?? false,
          minimum_rental_period: item.minimum_rental_period === "N/A" ? "" : item.minimum_rental_period || ""
        });
      }
      
      setLoading(false);
    } catch (error) {
      console.error("Error loading user or item:", error);
      setError("Error loading data. Please try again.");
      navigate(createPageUrl("Home"));
    }
  }, [navigate]);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  const compressImage = (file, maxSizeKB = 600) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          // Calculate new dimensions while maintaining aspect ratio
          const maxDimension = 1920;
          if (width > height && width > maxDimension) {
            height = (height / width) * maxDimension;
            width = maxDimension;
          } else if (height > maxDimension) {
            width = (width / height) * maxDimension;
            height = maxDimension;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          
          // Try different quality levels to get under maxSizeKB
          const tryCompress = (quality) => {
            canvas.toBlob((blob) => {
              const sizeKB = blob.size / 1024;
              
              if (sizeKB <= maxSizeKB || quality <= 0.3) {
                // Accept this compression level
                const compressedFile = new File([blob], file.name, {
                  type: 'image/jpeg',
                  lastModified: Date.now()
                });
                
                if (sizeKB > maxSizeKB) {
                  // Couldn't compress enough, but we tried
                  resolve({ file: compressedFile, overSize: true, finalSize: sizeKB });
                } else {
                  resolve({ file: compressedFile, overSize: false, finalSize: sizeKB });
                }
              } else {
                // Try with lower quality
                tryCompress(quality - 0.1);
              }
            }, 'image/jpeg', quality);
          };
          
          // Start with quality 0.8
          tryCompress(0.8);
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
    });
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    const maxImages = 4;
    const currentImageCount = formData.images.length;
    const filesToUploadCount = files.length;

    if (currentImageCount + filesToUploadCount > maxImages) {
      alert(`You can only upload a maximum of ${maxImages} images per item. You currently have ${currentImageCount} image(s).`);
      return;
    }

    setUploadingImages(true);
    setError(""); // Clear any general error before upload

    try {
      const uploadPromises = files.map(async (file) => {
        // Compress the image
        const { file: compressedFile, overSize, finalSize } = await compressImage(file);
        
        if (overSize) {
          alert(`Warning: "${file.name}" is ${finalSize.toFixed(0)}KB after compression. The target was ${maxImages}KB. Please try reducing the image size or using a different image for best performance.`);
        }
        
        const { file_url } = await UploadFile({ file: compressedFile });
        return file_url;
      });
      
      const imageUrls = await Promise.all(uploadPromises);

      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...imageUrls]
      }));
    } catch (error) {
      console.error("Error uploading images:", error);
      alert("Error uploading images. Please try again.");
    }

    setUploadingImages(false);
  };

  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
    setErrors(prev => ({...prev, images: ""}));
    setError(""); // Clear any general error
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = "Item title is required";
    }

    if (!formData.description.trim()) {
      newErrors.description = "Description is required";
    }

    if (!formData.category) {
      newErrors.category = "Category is required";
    }

    if (!formData.subcategory) {
      newErrors.subcategory = "Specific type is required";
    }

    if (!formData.city.trim()) {
      newErrors.city = "City is required";
    }

    if (formData.listing_type === "rent") {
      const rentAmount = parseFloat(formData.rent_amount);
      if (!formData.rent_amount || isNaN(rentAmount) || rentAmount <= 0) {
        newErrors.rent_amount = "Rental price must be a positive number";
      }
    } else {
      const salePrice = parseFloat(formData.sale_price);
      if (!formData.sale_price || isNaN(salePrice) || salePrice <= 0) {
        newErrors.sale_price = "Sale price must be a positive number";
      }
    }

    if (formData.images.length === 0) {
      newErrors.images = "At least one image is required";
    }

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setHasAttemptedSubmit(true);
    
    console.log("Form submitted. Current form data:", formData);
    
    const validationErrors = validateForm();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      setError("Please fill in all required fields marked with * and fix any errors.");
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setSaving(true);
    setError("");

    try {
      const currentUser = await User.me();

      if (!currentUser || (currentUser.account_type !== "vendor" && currentUser.account_type !== "admin")) {
        setError("You are not authorized to add/edit items. Please ensure you are logged in with a vendor or admin account.");
        setSaving(false);
        return;
      }

      if (currentUser.account_type === "vendor") {
        const isExpired = currentUser.subscription_end_date && 
          new Date(currentUser.subscription_end_date) < new Date();
        if (isExpired) {
          setError("Your subscription has expired. Please renew to add/edit items.");
          setSaving(false);
          return;
        }
      }

      const listingData = {
        ...formData,
        district: formData.district.trim() === "" ? "N/A" : formData.district.trim(),
        neighborhood: formData.neighborhood.trim() === "" ? "N/A" : formData.neighborhood.trim(),
        address: formData.address.trim() === "" ? "N/A" : formData.address.trim(),
        brand: formData.brand.trim() === "" ? "N/A" : formData.brand.trim(),
        model: formData.model.trim() === "" ? "N/A" : formData.model.trim(),
        minimum_rental_period: formData.minimum_rental_period.trim() === "" ? "N/A" : formData.minimum_rental_period.trim(),
        
        owner_id: currentUser.id,
        owner_name: currentUser.full_name,
        owner_email: currentUser.email,
        owner_phone: currentUser.phone,
        owner_whatsapp: currentUser.whatsapp,

        images: formData.images, 

        quantity_available: parseInt(formData.quantity_available),
      };

      if (!isEditMode) {
        listingData.status = "available";
        listingData.views = 0;
      }

      if (formData.year && formData.year.trim() !== "") {
        listingData.year = parseInt(formData.year);
      } else {
        delete listingData.year;
      }

      if (listingData.specifications && Object.keys(listingData.specifications).length === 0) {
        delete listingData.specifications;
      }

      if (formData.listing_type === "rent") {
        listingData.rent_amount = parseFloat(formData.rent_amount);
        if (formData.security_deposit && parseFloat(formData.security_deposit) > 0) {
          listingData.security_deposit = parseFloat(formData.security_deposit);
        } else {
          listingData.security_deposit = null;
        }
        delete listingData.sale_price;
      } else {
        listingData.sale_price = parseFloat(formData.sale_price);
        delete listingData.rent_amount;
        delete listingData.security_deposit;
        delete listingData.payment_frequency;
        delete listingData.minimum_rental_period;
      }

      console.log("Item data being saved:", listingData);
      
      if (isEditMode) {
        await Listing.update(itemId, listingData);
        console.log("Listing updated successfully");
      } else {
        await Listing.create(listingData);
        console.log("Listing created successfully");
      }

      setSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl("MyListings"));
      }, 2000);
    } catch (err) {
      console.error("Error saving listing:", err);
      setError("Error saving listing: " + (err.message || "Please try again."));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const userCurrency = user?.currency || "TZS";

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full border-0 shadow-2xl">
          <CardContent className="pt-6 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Item {isEditMode ? "Updated!" : "Listed!"}</h2>
            <p className="text-slate-600">Your item has been successfully {isEditMode ? "updated" : "added"} and is now visible to customers.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const CategoryIcon = formData.category ? categoryOptions[formData.category]?.icon : null;
  const maxImagesLimit = 4; // Fixed max images for all listings now

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">
          {isEditMode ? "Edit Item" : "Add New Item"}
        </h1>
        <p className="text-slate-600">
          {isEditMode ? "Update your item details for rent or sale" : "List an item for rent or sale"}
        </p>
      </div>

      {hasAttemptedSubmit && Object.keys(errors).length > 0 && (
        <Card className="border-red-200 bg-red-50 shadow-xl mb-6">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-red-900 mb-2 flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              Please fix the following errors:
            </h3>
            <ul className="list-disc list-inside space-y-1 text-red-800">
              {Object.values(errors).map((err, index) => (
                <li key={index}>{err}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {error && (
        <Alert variant="destructive" className="border-red-200 bg-red-50 shadow-xl mb-6">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-900">
            {error}
          </AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="listing_type">Listing Type *</Label>
                <Select
                  value={formData.listing_type}
                  onValueChange={(value) => {
                    setFormData({...formData, listing_type: value});
                    if (hasAttemptedSubmit) {
                      setErrors(prev => {
                        const newErrors = {...prev};
                        delete newErrors.rent_amount;
                        delete newErrors.sale_price;
                        return newErrors;
                      });
                    }
                    setError("");
                  }}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rent">For Rent/Hire</SelectItem>
                    <SelectItem value="sale">For Sale</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="category" className={hasAttemptedSubmit && errors.category ? "text-red-600" : ""}>
                  Category *
                </Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => {
                    setFormData({...formData, category: value, subcategory: ""});
                    if (hasAttemptedSubmit) {
                      const newErrors = {...errors};
                      delete newErrors.category;
                      setErrors(newErrors);
                    }
                    setError("");
                  }}
                >
                  <SelectTrigger className={`mt-2 ${hasAttemptedSubmit && errors.category ? "border-red-500" : ""}`}>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(categoryOptions).map(([key, { label, icon: Icon }]) => (
                      <SelectItem key={key} value={key}>
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4" />
                          {label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {hasAttemptedSubmit && errors.category && <p className="text-xs text-red-600 mt-1">{errors.category}</p>}
              </div>
            </div>

            {formData.category && (
              <div>
                <Label htmlFor="subcategory" className={hasAttemptedSubmit && errors.subcategory ? "text-red-600" : ""}>
                  Specific Type *
                </Label>
                <Select
                  value={formData.subcategory}
                  onValueChange={(value) => {
                    setFormData({...formData, subcategory: value});
                    if (hasAttemptedSubmit) {
                      const newErrors = {...errors};
                      delete newErrors.subcategory;
                      setErrors(newErrors);
                    }
                    setError("");
                  }}
                >
                  <SelectTrigger className={`mt-2 ${hasAttemptedSubmit && errors.subcategory ? "border-red-500" : ""}`}>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {categoryOptions[formData.category].subcategories.map((sub) => (
                      <SelectItem key={sub} value={sub}>{sub}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {hasAttemptedSubmit && errors.subcategory && <p className="text-xs text-red-600 mt-1">{errors.subcategory}</p>}
              </div>
            )}

            <div>
              <Label htmlFor="title" className={hasAttemptedSubmit && errors.title ? "text-red-600" : ""}>
                Item Title *
              </Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => {
                  setFormData({...formData, title: e.target.value});
                  if (hasAttemptedSubmit) {
                    const newErrors = {...errors};
                    delete newErrors.title;
                    setErrors(newErrors);
                  }
                  setError("");
                }}
                placeholder="e.g., Toyota Camry 2020 - Self Drive"
                className={`mt-2 ${hasAttemptedSubmit && errors.title ? "border-red-500" : ""}`}
              />
              {hasAttemptedSubmit && errors.title && <p className="text-xs text-red-600 mt-1">{errors.title}</p>}
            </div>

            <div>
              <Label htmlFor="description" className={hasAttemptedSubmit && errors.description ? "text-red-600" : ""}>
                Description *
              </Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => {
                  setFormData({...formData, description: e.target.value});
                  if (hasAttemptedSubmit) {
                    const newErrors = {...errors};
                    delete newErrors.description;
                    setErrors(newErrors);
                  }
                  setError("");
                }}
                placeholder="Describe your item in detail: features, condition, specifications, etc."
                className={`min-h-32 mt-2 ${hasAttemptedSubmit && errors.description ? "border-red-500" : ""}`}
              />
              {hasAttemptedSubmit && errors.description && <p className="text-xs text-red-600 mt-1">{errors.description}</p>}
            </div>
          </CardContent>
        </Card>

        {/* Item Details */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Item Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="brand">Brand</Label>
                <Input
                  id="brand"
                  value={formData.brand === "N/A" ? "" : formData.brand}
                  onChange={(e) => {
                    setFormData({...formData, brand: e.target.value});
                    setError("");
                  }}
                  placeholder="e.g., Toyota, Sony (optional)"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="model">Model</Label>
                <Input
                  id="model"
                  value={formData.model === "N/A" ? "" : formData.model}
                  onChange={(e) => {
                    setFormData({...formData, model: e.target.value});
                    setError("");
                  }}
                  placeholder="e.g., Camry, A7III (optional)"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="year">Year</Label>
                <Input
                  id="year"
                  type="number"
                  value={formData.year}
                  onChange={(e) => {
                    setFormData({...formData, year: e.target.value});
                    setError("");
                  }}
                  placeholder="e.g., 2020 (optional)"
                  className="mt-2"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="condition">Condition *</Label>
                <Select
                  value={formData.condition}
                  onValueChange={(value) => {
                    setFormData({...formData, condition: value});
                    setError("");
                  }}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="like_new">Like New</SelectItem>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                    <SelectItem value="needs_repair">Needs Repair</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="quantity">Quantity Available *</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={formData.quantity_available}
                  onChange={(e) => {
                    setFormData({...formData, quantity_available: e.target.value});
                    setError("");
                  }}
                  required
                  className="mt-2"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Location */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Location</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="city" className={hasAttemptedSubmit && errors.city ? "text-red-600" : ""}>
                  City *
                </Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => {
                    setFormData({...formData, city: e.target.value});
                    if (hasAttemptedSubmit) {
                      const newErrors = {...errors};
                      delete newErrors.city;
                      setErrors(newErrors);
                    }
                    setError("");
                  }}
                  placeholder="e.g., Dar es Salaam"
                  className={`mt-2 ${hasAttemptedSubmit && errors.city ? "border-red-500" : ""}`}
                />
                {hasAttemptedSubmit && errors.city && <p className="text-xs text-red-600 mt-1">{errors.city}</p>}
              </div>
              <div>
                <Label htmlFor="district">District</Label>
                <Input
                  id="district"
                  value={formData.district === "N/A" ? "" : formData.district}
                  onChange={(e) => {
                    setFormData({...formData, district: e.target.value});
                    setError("");
                  }}
                  placeholder="e.g., Kinondoni (optional)"
                  className="mt-2"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="neighborhood">Neighborhood</Label>
              <Input
                id="neighborhood"
                value={formData.neighborhood === "N/A" ? "" : formData.neighborhood}
                onChange={(e) => {
                  setFormData({...formData, neighborhood: e.target.value});
                  setError("");
                }}
                placeholder="e.g., Mikocheni (optional)"
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="address">Pickup Address</Label>
              <Input
                id="address"
                value={formData.address === "N/A" ? "" : formData.address}
                onChange={(e) => {
                  setFormData({...formData, address: e.target.value});
                  setError("");
                }}
                placeholder="Where customers can pick up the item (optional)"
                className="mt-2"
              />
            </div>
          </CardContent>
        </Card>

        {/* Images */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle className={hasAttemptedSubmit && errors.images ? "text-red-600" : ""}>
              Item Images *
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {hasAttemptedSubmit && errors.images && (
                <Alert variant="destructive" className="border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-900">
                    {errors.images}
                  </AlertDescription>
                </Alert>
              )}

              {formData.images.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {formData.images.map((image, index) => (
                    <div key={index} className="relative group">
                      <img 
                        src={image} 
                        alt={`Item ${index + 1}`} 
                        className="w-full h-32 object-cover rounded-lg border-2 border-slate-200" 
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                        onClick={() => removeImage(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <div>
                <Label htmlFor="images" className="cursor-pointer">
                  <div className={`border-2 border-dashed rounded-lg p-12 text-center hover:border-purple-400 hover:bg-purple-50/50 transition-all ${
                    hasAttemptedSubmit && errors.images ? "border-red-500" : "border-slate-300"
                  }`}>
                    {uploadingImages ? (
                      <>
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4" />
                        <p className="text-sm text-slate-600">Compressing and uploading images...</p>
                        <p className="text-xs text-slate-500 mt-1">This may take a moment</p>
                      </>
                    ) : (
                      <>
                        <ImageIcon className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                        <p className="text-slate-600 font-medium mb-1">Click to upload item images</p>
                        <p className="text-xs text-slate-500">
                          PNG, JPG, JPEG. Maximum {maxImagesLimit} images.
                        </p>
                        <p className="text-xs text-purple-600 mt-2">
                          Images will be automatically compressed to optimize loading speed
                        </p>
                        <p className="text-xs font-semibold text-slate-700 mt-2">
                          {formData.images.length} of {maxImagesLimit} images uploaded
                        </p>
                      </>
                    )}
                  </div>
                </Label>
                <Input
                  id="images"
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={uploadingImages || formData.images.length >= maxImagesLimit}
                />
                {formData.images.length >= maxImagesLimit && (
                  <p className="text-sm text-orange-600 mt-2 font-semibold">Maximum of {maxImagesLimit} images reached</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pricing */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>
              {formData.listing_type === "rent" ? "Rental Terms" : "Sale Price"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {formData.listing_type === "rent" ? (
              <>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="rent" className={hasAttemptedSubmit && errors.rent_amount ? "text-red-600" : ""}>
                      Rental Price ({userCurrency}) *
                    </Label>
                    <Input
                      id="rent"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.rent_amount}
                      onChange={(e) => {
                        setFormData({...formData, rent_amount: e.target.value});
                        if (hasAttemptedSubmit) {
                          const newErrors = {...errors};
                          delete newErrors.rent_amount;
                          setErrors(newErrors);
                        }
                        setError("");
                      }}
                      placeholder="e.g., 50000"
                      className={`mt-2 ${hasAttemptedSubmit && errors.rent_amount ? "border-red-500" : ""}`}
                    />
                    {hasAttemptedSubmit && errors.rent_amount && <p className="text-xs text-red-600 mt-1">{errors.rent_amount}</p>}
                  </div>
                  <div>
                    <Label htmlFor="frequency">Payment Frequency *</Label>
                    <Select
                      value={formData.payment_frequency}
                      onValueChange={(value) => {
                        setFormData({...formData, payment_frequency: value});
                        setError("");
                      }}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hourly">Per Hour</SelectItem>
                        <SelectItem value="daily">Per Day</SelectItem>
                        <SelectItem value="weekly">Per Week</SelectItem>
                        <SelectItem value="monthly">Per Month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="deposit">Security Deposit ({userCurrency})</Label>
                    <Input
                      id="deposit"
                      type="number"
                      min="0"
                      step="any"
                      value={formData.security_deposit}
                      onChange={(e) => {
                        setFormData({...formData, security_deposit: e.target.value});
                        setError("");
                      }}
                      placeholder="e.g., 100000 (optional)"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="minimum">Minimum Rental Period</Label>
                    <Input
                      id="minimum"
                      value={formData.minimum_rental_period === "N/A" ? "" : formData.minimum_rental_period}
                      onChange={(e) => {
                        setFormData({...formData, minimum_rental_period: e.target.value});
                        setError("");
                      }}
                      placeholder="e.g., 1 day, 3 hours (optional)"
                      className="mt-2"
                    />
                  </div>
                </div>
              </>
            ) : (
              <div>
                <Label htmlFor="sale_price" className={hasAttemptedSubmit && errors.sale_price ? "text-red-600" : ""}>
                  Sale Price ({userCurrency}) *
                </Label>
                <Input
                  id="sale_price"
                  type="number"
                  min="0"
                  step="any"
                  value={formData.sale_price}
                  onChange={(e) => {
                    setFormData({...formData, sale_price: e.target.value});
                    if (hasAttemptedSubmit) {
                      const newErrors = {...errors};
                      delete newErrors.sale_price;
                      setErrors(newErrors);
                    }
                    setError("");
                  }}
                  placeholder="e.g., 5000000"
                  className={`mt-2 ${hasAttemptedSubmit && errors.sale_price ? "border-red-500" : ""}`}
                />
                {hasAttemptedSubmit && errors.sale_price && <p className="text-xs text-red-600 mt-1">{errors.sale_price}</p>}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Additional Services */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Additional Services</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="delivery"
                  checked={formData.delivery_available}
                  onCheckedChange={(checked) => {
                    setFormData({...formData, delivery_available: checked});
                    setError("");
                  }}
                />
                <Label htmlFor="delivery" className="cursor-pointer font-normal">
                  Delivery/Transport Available
                </Label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="setup"
                  checked={formData.setup_included}
                  onCheckedChange={(checked) => {
                    setFormData({...formData, setup_included: checked});
                    setError("");
                  }}
                />
                <Label htmlFor="setup" className="cursor-pointer font-normal">
                  Setup/Installation Included
                </Label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="operator"
                  checked={formData.operator_included}
                  onCheckedChange={(checked) => {
                    setFormData({...formData, operator_included: checked});
                    setError("");
                  }}
                />
                <Label htmlFor="operator" className="cursor-pointer font-normal">
                  Operator/Driver Included
                  </Label>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Submit Buttons */}
        <div className="flex justify-end gap-4 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate(createPageUrl("MyListings"))}
            disabled={saving}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={saving || uploadingImages}
            className="bg-purple-600 hover:bg-purple-700 px-8"
          >
            {saving ? (isEditMode ? "Updating..." : "Publishing...") : (isEditMode ? "Update Item" : "Publish Item")}
          </Button>
        </div>
      </form>
    </div>
  );
}
