
import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ImageIcon, X } from "lucide-react";
import LocationMap from "../components/property/LocationMap";

export default function AddLodge() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [lodgeId, setLodgeId] = useState(null);

  const [formData, setFormData] = useState({
    name: "",
    logo_url: "",
    description: "",
    type: "hotel",
    country: "",
    state: "",
    city: "",
    neighborhood: "",
    address: "",
    latitude: null,
    longitude: null,
    images: [],
    star_rating: 3,
    amenities: [],
    check_in_time: "14:00",
    check_out_time: "10:00",
    payment_methods: [],
    cancellation_policy: ""
  });

  const loadUser = useCallback(async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      if (currentUser.account_type !== "vendor" && currentUser.account_type !== "admin") {
        navigate(createPageUrl("Dashboard"));
        return;
      }

      if (currentUser.account_type === "vendor") {
        const isExpired = currentUser.subscription_end_date && 
          new Date(currentUser.subscription_end_date) < new Date();
        
        if (isExpired) {
          navigate(createPageUrl("Dashboard"));
          return;
        }
      }
      
      const urlParams = new URLSearchParams(window.location.search);
      const id = urlParams.get("id");
      
      if (id) {
        setIsEditMode(true);
        setLodgeId(id);
        
        const lodge = await base44.entities.Lodge.get(id);
        
        if (lodge.owner_id !== currentUser.id && currentUser.account_type !== "admin") {
          alert("You don't have permission to edit this lodge");
          navigate(createPageUrl("MyLodges"));
          return;
        }
        
        setFormData({
          name: lodge.name || "",
          logo_url: lodge.logo_url || "",
          description: lodge.description || "",
          type: lodge.type || "hotel",
          country: lodge.country || "",
          state: lodge.state || "",
          city: lodge.city || "",
          neighborhood: lodge.neighborhood || "",
          address: lodge.address || "",
          latitude: lodge.latitude || null,
          longitude: lodge.longitude || null,
          images: lodge.images || [],
          star_rating: lodge.star_rating || 3,
          amenities: lodge.amenities || [],
          check_in_time: lodge.check_in_time || "14:00",
          check_out_time: lodge.check_out_time || "10:00",
          payment_methods: lodge.payment_methods || [],
          cancellation_policy: lodge.cancellation_policy || ""
        });
      }
      
      setLoading(false);
    } catch (error) {
      console.error("Error loading user:", error);
      navigate(createPageUrl("Home"));
    }
  }, [navigate]);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  const compressImage = (file, maxSizeKB = 600) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const maxDimension = 1920;
          if (width > height && width > maxDimension) {
            height = (height / width) * maxDimension;
            width = maxDimension;
          } else if (height > maxDimension) {
            width = (width / height) * maxDimension;
            height = maxDimension;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          
          const tryCompress = (quality) => {
            canvas.toBlob((blob) => {
              const sizeKB = blob.size / 1024;
              
              if (sizeKB <= maxSizeKB || quality <= 0.3) {
                const compressedFile = new File([blob], file.name, {
                  type: 'image/jpeg',
                  lastModified: Date.now()
                });
                
                if (sizeKB > maxSizeKB) {
                  resolve({ file: compressedFile, overSize: true, finalSize: sizeKB });
                } else {
                  resolve({ file: compressedFile, overSize: false, finalSize: sizeKB });
                }
              } else {
                tryCompress(quality - 0.1);
              }
            }, 'image/jpeg', quality);
          };
          
          tryCompress(0.8);
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
    });
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingLogo(true);

    try {
      const { file: compressedFile, overSize, finalSize } = await compressImage(file, 200); // Smaller 200KB target for logos
      if (overSize) {
        alert(`Warning: Logo is still ${finalSize.toFixed(0)}KB after compression.`);
      }
      const { file_url } = await base44.integrations.Core.UploadFile({ file: compressedFile });
      setFormData(prev => ({ ...prev, logo_url: file_url }));
    } catch (error) {
      console.error("Error uploading logo:", error);
      alert("Error uploading logo. Please try again.");
    }

    setUploadingLogo(false);
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    const maxImages = 6;
    const currentImageCount = formData.images.length;

    if (currentImageCount + files.length > maxImages) {
      alert(`You can only upload a maximum of ${maxImages} images. You currently have ${currentImageCount} image(s).`);
      return;
    }

    setUploadingImages(true);

    try {
      const uploadPromises = files.map(async (file) => {
        const { file: compressedFile, overSize, finalSize } = await compressImage(file);
        
        if (overSize) {
          alert(`Warning: "${file.name}" is ${finalSize.toFixed(0)}KB after compression.`);
        }
        
        const { file_url } = await base44.integrations.Core.UploadFile({ file: compressedFile });
        return file_url;
      });
      
      const imageUrls = await Promise.all(uploadPromises);
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...imageUrls]
      }));
    } catch (error) {
      console.error("Error uploading images:", error);
      alert("Error uploading images. Please try again.");
    }

    setUploadingImages(false);
  };

  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const handleLocationChange = (lat, lng) => {
    setFormData(prev => ({
      ...prev,
      latitude: lat,
      longitude: lng
    }));
  };

  const handleAddressFound = (address) => {
    setFormData(prev => ({
      ...prev,
      country: address.country || prev.country,
      state: address.state || prev.state,
      city: address.city || prev.city,
      neighborhood: address.neighborhood || prev.neighborhood,
      // The full address field is left for the user to fine-tune or can be updated if a more specific reverse geocoding result is desired.
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      const currentUser = await base44.auth.me();

      if (!currentUser || (currentUser.account_type !== "vendor" && currentUser.account_type !== "admin")) {
        alert("You are not authorized to add/edit lodges.");
        navigate(createPageUrl("Dashboard"));
        return;
      }

      const lodgeData = {
        ...formData,
        owner_id: currentUser.id,
        owner_name: currentUser.full_name,
        owner_email: currentUser.email,
        owner_phone: currentUser.phone,
        owner_whatsapp: currentUser.whatsapp,
      };

      if (!isEditMode) {
        lodgeData.status = "active";
        lodgeData.views = 0;
      }

      if (isEditMode) {
        await base44.entities.Lodge.update(lodgeId, lodgeData);
        alert("Lodge updated successfully!");
        navigate(createPageUrl("MyLodges"));
      } else {
        const created = await base44.entities.Lodge.create(lodgeData);
        alert("Lodge created successfully! Now you can add rooms.");
        navigate(createPageUrl(`ManageRooms?lodgeId=${created.id}`));
      }
      
      queryClient.invalidateQueries({ queryKey: ['lodges'] });
    } catch (error) {
      console.error("Error saving lodge:", error);
      alert("Error saving lodge. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const amenitiesList = [
    { value: "wifi", label: "WiFi" },
    { value: "parking", label: "Parking" },
    { value: "restaurant", label: "Restaurant" },
    { value: "bar", label: "Bar" },
    { value: "pool", label: "Swimming Pool" },
    { value: "gym", label: "Gym/Fitness Center" },
    { value: "conference_hall", label: "Conference Hall" },
    { value: "laundry", label: "Laundry Service" },
    { value: "room_service", label: "Room Service" },
    { value: "airport_shuttle", label: "Airport Shuttle" }
  ];

  const paymentMethodsList = [
    { value: "cash", label: "Cash" },
    { value: "mobile_money", label: "Mobile Money" },
    { value: "card", label: "Credit/Debit Card" },
    { value: "bank_transfer", label: "Bank Transfer" }
  ];

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">
          {isEditMode ? "Edit Lodge" : "Add New Lodge/Hotel/Motel"}
        </h1>
        <p className="text-slate-600">
          {isEditMode ? "Update your establishment details" : "Create your hospitality establishment profile"}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-[1fr_auto] gap-8 items-start">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Establishment Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="e.g., Sunset Lodge"
                    required
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="type">Type *</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value) => setFormData({...formData, type: value})}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hotel">Hotel</SelectItem>
                      <SelectItem value="motel">Motel</SelectItem>
                      <SelectItem value="lodge">Lodge</SelectItem>
                      <SelectItem value="guesthouse">Guesthouse</SelectItem>
                      <SelectItem value="inn">Inn</SelectItem>
                      <SelectItem value="resort">Resort</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="star_rating">Star Rating</Label>
                  <Select
                    value={formData.star_rating.toString()}
                    onValueChange={(value) => setFormData({...formData, star_rating: parseInt(value)})}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 Star</SelectItem>
                      <SelectItem value="2">2 Stars</SelectItem>
                      <SelectItem value="3">3 Stars</SelectItem>
                      <SelectItem value="4">4 Stars</SelectItem>
                      <SelectItem value="5">5 Stars</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Lodge Logo</Label>
                <div className="mt-2">
                  <Label htmlFor="logo-upload" className="cursor-pointer group">
                    <div className="w-32 h-32 bg-slate-100 rounded-lg flex items-center justify-center border-2 border-dashed border-slate-300 hover:border-indigo-400 relative overflow-hidden">
                      {uploadingLogo ? (
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
                      ) : formData.logo_url ? (
                        <>
                          <img src={formData.logo_url} alt="Logo" className="w-full h-full object-cover rounded-lg" />
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white text-xs font-semibold">
                            Change
                          </div>
                        </>
                      ) : (
                        <div className="text-center text-slate-500">
                          <ImageIcon className="w-8 h-8 mx-auto mb-1" />
                          <span className="text-xs">Upload Logo</span>
                        </div>
                      )}
                    </div>
                  </Label>
                  <Input
                    id="logo-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                    disabled={uploadingLogo}
                  />
                </div>
              </div>
            </div>

            <div className="mt-4">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Describe your establishment, its features, and what makes it special..."
                className="min-h-32 mt-2"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Location */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Location Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="country">Country *</Label>
                <Input
                  id="country"
                  value={formData.country}
                  onChange={(e) => setFormData({...formData, country: e.target.value})}
                  placeholder="Country"
                  required
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="state">State/Region</Label>
                <Input
                  id="state"
                  value={formData.state}
                  onChange={(e) => setFormData({...formData, state: e.target.value})}
                  placeholder="State or Region"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({...formData, city: e.target.value})}
                  placeholder="City"
                  required
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="neighborhood">Neighborhood</Label>
                <Input
                  id="neighborhood"
                  value={formData.neighborhood}
                  onChange={(e) => setFormData({...formData, neighborhood: e.target.value})}
                  placeholder="Neighborhood/Area"
                  className="mt-2"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="address">Full Address *</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Enter complete address with landmarks"
                className="mt-2 h-20"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Location Map */}
        <LocationMap
          latitude={formData.latitude}
          longitude={formData.longitude}
          country={formData.country}
          state={formData.state}
          city={formData.city}
          address={formData.address}
          onLocationChange={handleLocationChange}
          onAddressFound={handleAddressFound}
          editable={true}
        />

        {/* Images */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Lodge Images (Maximum 6)</CardTitle>
          </CardHeader>
          <CardContent>
            {formData.images.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                {formData.images.map((image, index) => (
                  <div key={index} className="relative group">
                    <img 
                      src={image} 
                      alt={`Lodge ${index + 1}`} 
                      className="w-full h-32 object-cover rounded-lg border-2 border-slate-200" 
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                      onClick={() => removeImage(index)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <Label htmlFor="images" className="cursor-pointer">
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-12 text-center hover:border-indigo-400 hover:bg-indigo-50/50 transition-all">
                {uploadingImages ? (
                  <>
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4" />
                    <p className="text-sm text-slate-600">Uploading images...</p>
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                    <p className="text-slate-600 font-medium mb-1">Click to upload images</p>
                    <p className="text-xs text-slate-500">
                      {formData.images.length} of 6 images uploaded
                    </p>
                  </>
                )}
              </div>
            </Label>
            <Input
              id="images"
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageUpload}
              className="hidden"
              disabled={uploadingImages || formData.images.length >= 6}
            />
          </CardContent>
        </Card>

        {/* Amenities & Services */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Amenities & Services</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="text-base font-semibold mb-3 block">Available Amenities</Label>
              <div className="grid md:grid-cols-2 gap-3">
                {amenitiesList.map((amenity) => (
                  <div key={amenity.value} className="flex items-center space-x-3">
                    <Checkbox
                      id={amenity.value}
                      checked={formData.amenities.includes(amenity.value)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setFormData({...formData, amenities: [...formData.amenities, amenity.value]});
                        } else {
                          setFormData({...formData, amenities: formData.amenities.filter(a => a !== amenity.value)});
                        }
                      }}
                    />
                    <Label htmlFor={amenity.value} className="cursor-pointer font-normal">{amenity.label}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="check_in_time">Check-in Time</Label>
                <Input
                  id="check_in_time"
                  type="time"
                  value={formData.check_in_time}
                  onChange={(e) => setFormData({...formData, check_in_time: e.target.value})}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="check_out_time">Check-out Time</Label>
                <Input
                  id="check_out_time"
                  type="time"
                  value={formData.check_out_time}
                  onChange={(e) => setFormData({...formData, check_out_time: e.target.value})}
                  className="mt-2"
                />
              </div>
            </div>

            <div>
              <Label className="text-base font-semibold mb-3 block">Payment Methods Accepted</Label>
              <div className="grid md:grid-cols-2 gap-3">
                {paymentMethodsList.map((method) => (
                  <div key={method.value} className="flex items-center space-x-3">
                    <Checkbox
                      id={method.value}
                      checked={formData.payment_methods.includes(method.value)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setFormData({...formData, payment_methods: [...formData.payment_methods, method.value]});
                        } else {
                          setFormData({...formData, payment_methods: formData.payment_methods.filter(p => p !== method.value)});
                        }
                      }}
                    />
                    <Label htmlFor={method.value} className="cursor-pointer font-normal">{method.label}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="cancellation_policy">Cancellation Policy</Label>
              <Textarea
                id="cancellation_policy"
                value={formData.cancellation_policy}
                onChange={(e) => setFormData({...formData, cancellation_policy: e.target.value})}
                placeholder="Describe your cancellation policy..."
                className="h-24 mt-2"
              />
            </div>
          </CardContent>
        </Card>

        {/* Submit */}
        <div className="flex justify-end gap-4 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate(createPageUrl("MyLodges"))}
            disabled={saving}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={saving || uploadingImages || uploadingLogo}
            className="bg-indigo-600 hover:bg-indigo-700 px-8"
          >
            {saving ? (isEditMode ? "Updating..." : "Creating...") : (isEditMode ? "Update Lodge" : "Create Lodge")}
          </Button>
        </div>
      </form>
    </div>
  );
}
