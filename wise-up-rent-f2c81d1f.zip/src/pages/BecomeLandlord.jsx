import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { LandlordRequest } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, AlertCircle, Clock, Building2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function BecomeLandlord() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [existingRequest, setExistingRequest] = useState(null);

  const loadData = useCallback(async () => {
    const currentUser = await User.me();
    setUser(currentUser);

    if (currentUser.account_type === "landlord") {
      navigate(createPageUrl("Dashboard"));
      return;
    }

    const requests = await LandlordRequest.filter({ user_id: currentUser.id });
    if (requests.length > 0) {
      setExistingRequest(requests[0]);
    }

    setLoading(false);
  }, [navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      await LandlordRequest.create({
        user_id: user.id,
        user_name: user.full_name,
        user_email: user.email,
        reason,
        status: "pending"
      });

      const requests = await LandlordRequest.filter({ user_id: user.id });
      setExistingRequest(requests[0]);
    } catch (error) {
      console.error("Error submitting request:", error);
    }

    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (existingRequest) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full border-0 shadow-2xl">
          <CardHeader className="text-center">
            <div className={`w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center ${
              existingRequest.status === "pending" ? "bg-yellow-100" : 
              existingRequest.status === "approved" ? "bg-green-100" : "bg-red-100"
            }`}>
              {existingRequest.status === "pending" && <Clock className="w-10 h-10 text-yellow-600" />}
              {existingRequest.status === "approved" && <CheckCircle className="w-10 h-10 text-green-600" />}
              {existingRequest.status === "rejected" && <AlertCircle className="w-10 h-10 text-red-600" />}
            </div>
            <CardTitle className="text-2xl">
              {existingRequest.status === "pending" && "Request Under Review"}
              {existingRequest.status === "approved" && "Request Approved!"}
              {existingRequest.status === "rejected" && "Request Declined"}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-slate-600">
              {existingRequest.status === "pending" && 
                "Your landlord request is being reviewed by our admin team. You'll be notified once it's processed. This usually takes 1-2 business days."}
              {existingRequest.status === "approved" && 
                "Congratulations! You can now start listing properties and managing your rentals."}
              {existingRequest.status === "rejected" && 
                "Your request was not approved. Please contact support for more information."}
            </p>
            
            {existingRequest.reason && (
              <div className="text-left bg-slate-50 p-4 rounded-lg">
                <p className="text-sm font-semibold text-slate-700 mb-1">Your Application:</p>
                <p className="text-sm text-slate-600">{existingRequest.reason}</p>
              </div>
            )}

            <Button
              onClick={() => navigate(createPageUrl("Dashboard"))}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <Card className="max-w-xl w-full border-0 shadow-2xl">
        <CardHeader className="text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-full mx-auto mb-4 flex items-center justify-center">
            <Building2 className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-3xl">Become a Landlord</CardTitle>
          <p className="text-slate-600 mt-2">
            Apply to list your properties on WiseUpRent
          </p>
        </CardHeader>
        <CardContent>
          <Alert className="mb-6 border-indigo-200 bg-indigo-50">
            <AlertCircle className="h-4 w-4 text-indigo-600" />
            <AlertDescription className="text-indigo-900">
              Your application will be reviewed by our admin team. This usually takes 1-2 business days.
            </AlertDescription>
          </Alert>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="reason" className="text-base font-semibold">
                Why do you want to become a landlord? *
              </Label>
              <Textarea
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Tell us about the properties you want to list, your experience as a landlord, and why you want to join our platform..."
                className="mt-2 min-h-40"
                required
              />
              <p className="text-xs text-slate-500 mt-2">
                Please provide detailed information to help us process your application faster.
              </p>
            </div>

            <Button
              type="submit"
              disabled={submitting || !reason.trim() || reason.trim().length < 20}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-lg py-6 shadow-lg"
            >
              {submitting ? "Submitting Application..." : "Submit Application"}
            </Button>

            <p className="text-xs text-center text-slate-500">
              By submitting, you agree to provide accurate information about your properties.
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}