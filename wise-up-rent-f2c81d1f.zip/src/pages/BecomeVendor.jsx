
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { VendorRequest } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { CheckCircle, AlertCircle, Clock, Building2, CreditCard, Smartphone } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns"; // Added for date formatting

export default function BecomeVendor() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [proofOfPayment, setProofOfPayment] = useState("");
  const [subscriptionType, setSubscriptionType] = useState("paid");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [existingRequest, setExistingRequest] = useState(null);
  const [actionType, setActionType] = useState("new"); // 'new', 'extend', or 'renew'

  const loadData = useCallback(async () => {
    setLoading(true);
    const currentUser = await User.me();
    setUser(currentUser);

    // Check URL parameters for action type
    const urlParams = new URLSearchParams(window.location.search);
    const action = urlParams.get('action');
    if (action === 'extend' || action === 'renew') {
      setActionType(action);
    }

    // FIRST PRIORITY: Check for ANY pending requests - for ALL cases
    const pendingRequests = await VendorRequest.filter({ 
      user_id: currentUser.id, 
      status: "pending" 
    });
    
    if (pendingRequests.length > 0) {
      // Found a pending request - show pending screen
      setExistingRequest(pendingRequests[0]);
      setLoading(false);
      return; // Stop here - don't show the form
    }

    // No pending requests found - clear any existing request state
    setExistingRequest(null);

    // Check if subscription is expired
    const isExpired = currentUser.subscription_end_date && 
      new Date(currentUser.subscription_end_date) < new Date();

    // If already a vendor with active subscription and no action specified, redirect
    if (currentUser.account_type === "vendor" && !action && !isExpired) {
      navigate(createPageUrl("Dashboard"));
      return;
    }

    // Set default subscription type based on trial usage and action
    if (currentUser.trial_used || action === 'extend' || action === 'renew') {
      setSubscriptionType("paid");
    } else {
      setSubscriptionType("trial");
    }

    setLoading(false);
  }, [navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Prevent multiple submissions
    if (submitting) {
      return;
    }
    
    setSubmitting(true);

    try {
      // Triple-check for pending requests right before submitting
      const existingPendingRequests = await VendorRequest.filter({ 
        user_id: user.id, 
        status: "pending" 
      });

      if (existingPendingRequests.length > 0) {
        setExistingRequest(existingPendingRequests[0]);
        setSubmitting(false);
        return;
      }

      const now = new Date();
      let endDate;

      if (actionType === "extend" && user.subscription_end_date) {
        // For extend, add 30 days to existing end date (not current date)
        const currentEndDate = new Date(user.subscription_end_date);
        endDate = new Date(currentEndDate.getTime() + 30 * 24 * 60 * 60 * 1000);
      } else if (actionType === "renew" || (actionType === "new" && subscriptionType === "paid")) {
        // For renew or new paid subscription, start from now + 30 days
        endDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      } else {
        // Default case for new trial - trial is now 30 days
        const subscriptionDays = subscriptionType === "trial" ? 30 : 30; // Changed 15 to 30
        endDate = new Date(now.getTime() + subscriptionDays * 24 * 60 * 60 * 1000);
      }

      // Create the request
      await VendorRequest.create({
        user_id: user.id,
        user_name: user.full_name,
        user_email: user.email,
        subscription_type: subscriptionType,
        proof_of_payment: subscriptionType === "paid" ? proofOfPayment : "TRIAL",
        subscription_start_date: now.toISOString(),
        subscription_end_date: endDate.toISOString(),
        status: "pending"
      });

      // Reload data to show pending screen
      await loadData();
    } catch (error) {
      console.error("Error submitting request:", error);
      alert("Error submitting request. Please try again.");
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  // ALWAYS show pending screen if there's an existing request
  if (existingRequest) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full border-0 shadow-2xl">
          <CardHeader className="text-center">
            <div className={`w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center ${
              existingRequest.status === "pending" ? "bg-yellow-100" : 
              existingRequest.status === "approved" ? "bg-green-100" : "bg-red-100"
            }`}>
              {existingRequest.status === "pending" && <Clock className="w-10 h-10 text-yellow-600" />}
              {existingRequest.status === "approved" && <CheckCircle className="w-10 h-10 text-green-600" />}
              {existingRequest.status === "rejected" && <AlertCircle className="w-10 h-10 text-red-600" />}
            </div>
            <CardTitle className="text-2xl">
              {existingRequest.status === "pending" && "Subscription Request Being Processed"}
              {existingRequest.status === "approved" && "Request Approved!"}
              {existingRequest.status === "rejected" && "Request Declined"}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-slate-600">
              {existingRequest.status === "pending" && 
                `Your subscription request (${existingRequest.subscription_type === "trial" ? "30-day trial" : "K20/30 days"}) is being reviewed by our admin team. You'll be notified once it's processed.`}
              {existingRequest.status === "approved" && 
                "Congratulations! Your subscription has been updated."}
              {existingRequest.status === "rejected" && 
                "Your request was not approved. Please contact support for more information or submit a new request."}
            </p>
            
            <div className="text-left bg-slate-50 p-4 rounded-lg">
              <p className="text-sm font-semibold text-slate-700 mb-1">Request Type:</p>
              <p className="text-sm text-slate-600 capitalize">
                {existingRequest.subscription_type === "trial" ? "30-Day Trial" : "Paid Subscription (K20/30 Days)"}
              </p>
              {existingRequest.subscription_type === "paid" && existingRequest.proof_of_payment && existingRequest.proof_of_payment !== "TRIAL" && (
                <>
                  <p className="text-sm font-semibold text-slate-700 mb-1 mt-2">Payment Proof Submitted:</p>
                  <p className="text-sm text-slate-600 whitespace-pre-wrap line-clamp-3">{existingRequest.proof_of_payment}</p>
                </>
              )}
              <p className="text-sm font-semibold text-slate-700 mb-1 mt-2">Submitted:</p>
              <p className="text-sm text-slate-600">
                {new Date(existingRequest.created_date).toLocaleDateString()} at {new Date(existingRequest.created_date).toLocaleTimeString()}
              </p>
            </div>

            <Alert className="border-orange-200 bg-orange-50">
              <Clock className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-900 text-sm">
                <strong>Please wait:</strong> Your request is being processed. You cannot submit a new request until this one is reviewed by an admin.
              </AlertDescription>
            </Alert>

            <Button
              onClick={() => navigate(createPageUrl("Home"))}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Only show the form if there's NO existing request
  const canUseTrial = !user.trial_used && actionType === "new";

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <Card className="max-w-2xl w-full border-0 shadow-2xl">
        <CardHeader className="text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-full mx-auto mb-4 flex items-center justify-center">
            <Building2 className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-3xl">
            {actionType === "extend" && "Extend Subscription"}
            {actionType === "renew" && "Renew Subscription"}
            {actionType === "new" && "Become a Vendor"}
          </CardTitle>
          <p className="text-slate-600 mt-2">
            {actionType === "extend" && "Add 30 more days to your current subscription"}
            {actionType === "renew" && "Renew your subscription for 30 days"}
            {actionType === "new" && "List properties and items on WiseUpRent"}
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <Card className="border-2 border-indigo-200 bg-indigo-50">
              <CardContent className="pt-6">
                <h3 className="font-bold text-lg text-indigo-900 mb-4">
                  {actionType === "extend" && "Extension Plan"}
                  {actionType === "renew" && "Renewal Plan"}
                  {actionType === "new" && "Subscription Options"}
                </h3>
                
                <RadioGroup value={subscriptionType} onValueChange={setSubscriptionType} className="space-y-4">
                  {canUseTrial && (
                    <div className="flex items-start space-x-3 p-4 border-2 border-green-300 rounded-lg bg-green-50">
                      <RadioGroupItem value="trial" id="trial" className="mt-1" />
                      <Label htmlFor="trial" className="cursor-pointer flex-1">
                        <div className="font-semibold text-green-900">30-Day Free Trial</div>
                        <div className="text-sm text-green-700 mt-1">
                          Try vendor features for 30 days with no payment required
                        </div>
                      </Label>
                    </div>
                  )}
                  
                  <div className="flex items-start space-x-3 p-4 border-2 border-indigo-300 rounded-lg bg-white">
                    <RadioGroupItem value="paid" id="paid" className="mt-1" />
                    <Label htmlFor="paid" className="cursor-pointer flex-1">
                      <div className="font-semibold text-indigo-900">K20 for 30 Days</div>
                      <div className="text-sm text-indigo-700 mt-1">
                        {actionType === "extend" && "Add 30 days to your current subscription end date"}
                        {actionType === "renew" && "Renew for 30 days starting from today"}
                        {actionType === "new" && "Full access to list unlimited properties and items for one month"}
                      </div>
                    </Label>
                  </div>
                </RadioGroup>

                {!canUseTrial && actionType === "new" && (
                  <Alert className="mt-4 border-blue-200 bg-blue-50">
                    <AlertCircle className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-900 text-sm">
                      You've already used your free trial. Please select the paid subscription to continue.
                    </AlertDescription>
                  </Alert>
                )}

                {actionType === "extend" && user.subscription_end_date && (
                  <Alert className="mt-4 border-indigo-200 bg-indigo-50">
                    <AlertCircle className="h-4 w-4 text-indigo-600" />
                    <AlertDescription className="text-indigo-900 text-sm">
                      Current expiry: {format(new Date(user.subscription_end_date), "MMM d, yyyy")}
                      <br />
                      New expiry after extension: {format(new Date(new Date(user.subscription_end_date).getTime() + 30 * 24 * 60 * 60 * 1000), "MMM d, yyyy")}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {subscriptionType === "paid" && (
              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CreditCard className="w-5 h-5" />
                    Payment Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-blue-200 bg-blue-50">
                    <AlertDescription className="text-blue-900">
                      <div className="space-y-3">
                        <div>
                          <div className="flex items-center gap-2 font-semibold mb-2">
                            <Smartphone className="w-4 h-4" />
                            Send Money To
                          </div>
                          <div className="text-lg font-bold">
                            +260 770 721 727
                          </div>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>

                  <div>
                    <Label htmlFor="proof" className="text-base font-semibold">
                      Proof of Payment Details *
                    </Label>
                    <Textarea
                      id="proof"
                      value={proofOfPayment}
                      onChange={(e) => setProofOfPayment(e.target.value)}
                      placeholder="Please paste your Mobile Money payment confirmation details here:&#10;&#10;Example:&#10;- Transaction ID: MM123456789&#10;- Date: 2024-01-15&#10;- Amount: K20&#10;- Name: John Doe&#10;- Sent to: +260770721727"
                      className="mt-2 min-h-48"
                      required
                    />
                    <p className="text-xs text-slate-500 mt-2">
                      Include transaction ID, date, amount, and your name for faster verification
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            <Alert className="border-orange-200 bg-orange-50">
              <AlertCircle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-900 text-sm">
                {actionType === "extend" && 
                  "Your subscription will be extended by 30 days once admin verifies your payment. The days will be added to your current end date."
                }
                {actionType === "renew" && 
                  "Your subscription will be renewed for 30 days starting from today once admin verifies your payment."
                }
                {subscriptionType === "trial" && actionType === "new" &&
                  "Your 30-day trial will start once approved by admin. After the trial, you'll need to subscribe for K20/30 days to continue as a vendor."
                }
                {subscriptionType === "paid" && actionType === "new" &&
                  "Your paid subscription will be activated once admin verifies your payment. This usually takes a few hours."
                }
              </AlertDescription>
            </Alert>

            <Button
              type="submit"
              disabled={submitting || (subscriptionType === "paid" && (!proofOfPayment || proofOfPayment.trim().length < 6))}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-lg py-6 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
                  Processing Request...
                </div>
              ) : (
                actionType === "extend" ? "Submit Extension Request" :
                actionType === "renew" ? "Submit Renewal Request" :
                "Submit Vendor Application"
              )}
            </Button>

            <p className="text-xs text-center text-slate-500">
              By submitting, you agree to provide accurate payment information
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
