
import React, { useState, useEffect } from "react";
import { Property } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  Building2,
  MapPin,
  // DollarSign, // Removed DollarSign import
  Filter,
  X,
  Bed,
  Shield,
  Droplets,
  Zap,
  Trash2,
  Car as CarIcon
} from "lucide-react";

export default function Browse() {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  const [filters, setFilters] = useState({
    searchQuery: "",
    city: "",
    neighborhood: "",
    minPrice: "",
    maxPrice: "",
    listingType: "all",
    propertyType: "all", // Added propertyType filter state
    bedrooms: "all",
    has_garage: false,
    has_garden: false,
    is_fenced: false,
    water_included: false,
    electricity_included: false,
    garbage_included: false
  });

  useEffect(() => {
    loadProperties();
  }, []);

  const loadProperties = async () => {
    const allProperties = await Property.filter({ status: "available" }, "-created_date");
    setProperties(allProperties);

    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      setCurrentUser(null);
    }

    setLoading(false);
  };

  const clearFilters = () => {
    setFilters({
      searchQuery: "",
      city: "",
      neighborhood: "",
      minPrice: "",
    maxPrice: "",
      listingType: "all",
      propertyType: "all", // Added propertyType to clear filters
      bedrooms: "all",
      has_garage: false,
      has_garden: false,
      is_fenced: false,
      water_included: false,
      electricity_included: false,
      garbage_included: false
    });
  };

  const filteredProperties = properties.filter(property => {
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      const matchesSearch =
        property.title?.toLowerCase().includes(query) ||
        property.description?.toLowerCase().includes(query) ||
        property.city?.toLowerCase().includes(query) ||
        property.neighborhood?.toLowerCase().includes(query);
      if (!matchesSearch) return false;
    }

    if (filters.city && !property.city?.toLowerCase().includes(filters.city.toLowerCase())) {
      return false;
    }

    // New: Neighborhood filter
    if (filters.neighborhood && !property.neighborhood?.toLowerCase().includes(filters.neighborhood.toLowerCase())) {
      return false;
    }

    if (filters.listingType !== "all" && property.listing_type !== filters.listingType) {
      return false;
    }

    // New: Property Type filter
    if (filters.propertyType !== "all" && property.property_type !== filters.propertyType) {
      return false;
    }

    if (filters.bedrooms !== "all" && property.bedrooms !== parseInt(filters.bedrooms)) {
      return false;
    }

    const price = property.listing_type === 'rent' ? property.rent_amount : property.sale_price;
    if (filters.minPrice && price < parseFloat(filters.minPrice)) {
      return false;
    }
    if (filters.maxPrice && price > parseFloat(filters.maxPrice)) {
      return false;
    }

    // Amenity filters
    if (filters.has_garage && !property.has_garage) return false;
    if (filters.has_garden && !property.has_garden) return false;
    if (filters.is_fenced && !property.is_fenced) return false;
    if (filters.water_included && !property.water_included) return false;
    if (filters.electricity_included && !property.electricity_included) return false;
    if (filters.garbage_included && !property.garbage_included) return false;

    return true;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const userCurrency = currentUser?.currency || "TZS";

  return (
    <div className="min-h-screen">
      {/* Hero Search Section */}
      <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-indigo-700 text-white py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">
              Find Your Perfect Property
            </h1>
            <p className="text-xl text-blue-100">
              Browse houses, apartments, and commercial spaces
            </p>
          </div>

          <Card className="border-0 shadow-2xl max-w-4xl mx-auto">
            <CardContent className="p-6 space-y-6">
              {/* Original Search and Listing Type */}
              <div className="flex gap-3 mb-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Search properties..."
                    value={filters.searchQuery}
                    onChange={(e) => setFilters({...filters, searchQuery: e.target.value})}
                    className="pl-10 h-12 text-lg"
                  />
                </div>
                <Select
                  value={filters.listingType}
                  onValueChange={(value) => setFilters({...filters, listingType: value})}
                >
                  <SelectTrigger className="w-32 h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="rent">For Rent</SelectItem>
                    <SelectItem value="sale">For Sale</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Filters from the sidebar, now moved below search */}
              <div className="border-t pt-6 mt-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-lg flex items-center gap-2 text-slate-800">
                    <Filter className="w-5 h-5" />
                    Filters
                  </h3>
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="text-slate-600 hover:text-slate-900">
                    Clear All <X className="w-4 h-4 ml-1" />
                  </Button>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {/* City Filter */}
                  <div>
                    <Label className="text-slate-700">City</Label>
                    <Input
                      placeholder="Enter city"
                      value={filters.city}
                      onChange={(e) => setFilters({...filters, city: e.target.value})}
                      className="mt-2"
                    />
                  </div>

                  {/* Neighborhood Filter */}
                  <div>
                    <Label className="text-slate-700">Neighborhood / Area</Label>
                    <Input
                      placeholder="Enter neighborhood"
                      value={filters.neighborhood}
                      onChange={(e) => setFilters({...filters, neighborhood: e.target.value})}
                      className="mt-2"
                    />
                  </div>

                  {/* Price Range Filter */}
                  <div>
                    <Label className="text-slate-700">Price Range ({userCurrency})</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <Input
                        type="number"
                        placeholder="Min"
                        value={filters.minPrice}
                        onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
                      />
                      <Input
                        type="number"
                        placeholder="Max"
                        value={filters.maxPrice}
                        onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
                      />
                    </div>
                  </div>

                  {/* Property Type Filter */}
                  <div>
                    <Label className="text-slate-700">Property Category</Label>
                    <Select
                      value={filters.propertyType}
                      onValueChange={(value) => setFilters({...filters, propertyType: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="residential">🏠 Residential</SelectItem>
                        <SelectItem value="commercial">🏢 Commercial</SelectItem>
                        <SelectItem value="land">🏞️ Land & Open Spaces</SelectItem>
                        <SelectItem value="hospitality">🏨 Hospitality</SelectItem>
                        <SelectItem value="parking_misc">🚗 Parking & Misc</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Bedrooms Filter */}
                  <div>
                    <Label className="text-slate-700">Bedrooms</Label>
                    <Select
                      value={filters.bedrooms}
                      onValueChange={(value) => setFilters({...filters, bedrooms: value})}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Any</SelectItem>
                        <SelectItem value="0">Studio</SelectItem>
                        <SelectItem value="1">1 Bedroom</SelectItem>
                        <SelectItem value="2">2 Bedrooms</SelectItem>
                        <SelectItem value="3">3 Bedrooms</SelectItem>
                        <SelectItem value="4">4 Bedrooms</SelectItem>
                        <SelectItem value="5">5+ Bedrooms</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 pt-6 border-t mt-6">
                  {/* Amenities */}
                  <div>
                    <Label className="mb-3 block font-semibold text-slate-700">Amenities</Label>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="garage"
                          checked={filters.has_garage}
                          onCheckedChange={(checked) => setFilters({...filters, has_garage: checked})}
                        />
                        <Label htmlFor="garage" className="cursor-pointer font-normal flex items-center gap-2 text-slate-700">
                          <CarIcon className="w-4 h-4 text-slate-600" />
                          Has Garage
                        </Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="garden"
                          checked={filters.has_garden}
                          onCheckedChange={(checked) => setFilters({...filters, has_garden: checked})}
                        />
                        <Label htmlFor="garden" className="cursor-pointer font-normal flex items-center gap-2 text-slate-700">
                          <span className="text-slate-600">🌳</span>
                          Has Garden
                        </Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="fenced"
                          checked={filters.is_fenced}
                          onCheckedChange={(checked) => setFilters({...filters, is_fenced: checked})}
                        />
                        <Label htmlFor="fenced" className="cursor-pointer font-normal flex items-center gap-2 text-slate-700">
                          <Shield className="w-4 h-4 text-slate-600" />
                          Fenced Property
                        </Label>
                      </div>
                    </div>
                  </div>

                  {/* Utilities Included (conditional) */}
                  {filters.listingType !== "sale" && (
                    <div>
                      <Label className="mb-3 block font-semibold text-slate-700">Utilities Included</Label>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Checkbox
                            id="water"
                            checked={filters.water_included}
                            onCheckedChange={(checked) => setFilters({...filters, water_included: checked})}
                          />
                          <Label htmlFor="water" className="cursor-pointer font-normal flex items-center gap-2 text-slate-700">
                            <Droplets className="w-4 h-4 text-blue-600" />
                            Water Bill
                          </Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Checkbox
                            id="electricity"
                            checked={filters.electricity_included}
                            onCheckedChange={(checked) => setFilters({...filters, electricity_included: checked})}
                          />
                          <Label htmlFor="electricity" className="cursor-pointer font-normal flex items-center gap-2 text-slate-700">
                            <Zap className="w-4 h-4 text-yellow-600" />
                            Electricity Bill
                          </Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Checkbox
                            id="garbage"
                            checked={filters.garbage_included}
                            onCheckedChange={(checked) => setFilters({...filters, garbage_included: checked})}
                          />
                          <Label htmlFor="garbage" className="cursor-pointer font-normal flex items-center gap-2 text-slate-700">
                            <Trash2 className="w-4 h-4 text-green-600" />
                            Garbage Collection
                          </Label>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content (now only for properties grid) */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Properties Grid */}
        <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-slate-900">
                {filteredProperties.length} {filteredProperties.length === 1 ? 'Property' : 'Properties'} Found
              </h2>
            </div>

            {filteredProperties.length === 0 ? (
              <Card className="border-0 shadow-xl">
                <CardContent className="text-center py-16">
                  <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">No Properties Found</h3>
                  <p className="text-slate-600 mb-6">Try adjusting your filters or search criteria</p>
                  <Button onClick={clearFilters} variant="outline">
                    Clear All Filters
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProperties.map((property) => (
                  <Link key={property.id} to={createPageUrl(`Property?id=${property.id}`)}>
                    <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden cursor-pointer transform hover:-translate-y-2 h-full">
                      <div className="relative h-56 bg-slate-200">
                        {property.images && property.images.length > 0 ? (
                          <img
                            src={property.images[0]}
                            alt={property.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Building2 className="w-16 h-16 text-slate-400" />
                          </div>
                        )}
                        <div className="absolute top-3 left-3 flex gap-2">
                          <Badge className={property.listing_type === "rent" ? "bg-indigo-600" : "bg-purple-600"}>
                            {property.listing_type === "rent" ? "For Rent" : "For Sale"}
                          </Badge>
                        </div>
                        <Badge className="absolute top-3 right-3 bg-green-500">Available</Badge>
                      </div>
                      <CardContent className="p-6">
                        <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-2 min-h-[3.5rem]">{property.title}</h3>

                        {property.city && (
                          <div className="flex items-center gap-2 text-slate-600 mb-3">
                            <MapPin className="w-4 h-4 flex-shrink-0" />
                            <span className="text-sm line-clamp-1">
                              {property.neighborhood && `${property.neighborhood}, `}
                              {property.city}
                            </span>
                          </div>
                        )}

                        <div className="flex items-center gap-3 mb-4 text-sm text-slate-600 flex-wrap">
                          <div className="flex items-center gap-1">
                            <Bed className="w-4 h-4" />
                            <span>{property.bedrooms} bed</span>
                          </div>
                          {property.is_fenced && (
                            <div className="flex items-center gap-1">
                              <Shield className="w-4 h-4" />
                              <span>Fenced{property.fence_type && ` (${property.fence_type})`}</span>
                            </div>
                          )}
                          {property.has_garage && (
                            <Badge variant="secondary" className="text-xs">Garage</Badge>
                          )}
                          {property.water_included && (
                            <Badge variant="secondary" className="text-xs">Water</Badge>
                          )}
                          {property.electricity_included && (
                            <Badge variant="secondary" className="text-xs">Electricity</Badge>
                          )}
                          {property.garbage_included && (
                            <Badge variant="secondary" className="text-xs">Garbage</Badge>
                          )}
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t">
                          {/* Price display change: removed DollarSign icon, adjusted currency display */}
                          <div>
                            <span className="font-bold text-xl text-indigo-600">
                              {userCurrency} {property.listing_type === "rent"
                                ? property.rent_amount?.toLocaleString()
                                : property.sale_price?.toLocaleString()
                              }
                            </span>
                            {property.listing_type === "rent" && property.payment_frequency && (
                              <span className="text-sm text-slate-500 ml-1">
                                /{property.payment_frequency}
                              </span>
                            )}
                          </div>
                          <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                            View
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </div>
      </div>
    </div>
  );
}
