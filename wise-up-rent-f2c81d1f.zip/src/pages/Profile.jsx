
import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { User } from "@/api/entities";
import { Rating } from "@/api/entities";
import { Property } from "@/api/entities";
import { VendorRequest } from "@/api/entities"; // Changed from LandlordRequest
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { CheckCircle, Star, Edit2, X, Building2, MessageSquare, UserPlus, AlertCircle, Globe, DollarSign, Clock } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns"; // Added import for date formatting
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { countriesWithCurrency, getCurrencyForCountry, getCallingCodeForCountry } from "../components/profile/CountryCurrencyData";

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [ratings, setRatings] = useState([]);
  const [properties, setProperties] = useState([]);
  const [vendorRequest, setVendorRequest] = useState(null); // Changed from landlordRequest
  const [formData, setFormData] = useState({
    full_name: "",
    phone: "", // Stores local number part
    whatsapp: "", // Stores local number part
    bio: "",
    country: "",
    currency: ""
  });

  const extractLocalNumber = (fullNumber, country) => {
    if (!fullNumber || !country) return "";
    const callingCode = getCallingCodeForCountry(country);
    if (fullNumber.startsWith(callingCode) && callingCode !== "") {
      // Remove calling code and trim any leading/trailing spaces or hyphens
      return fullNumber.substring(callingCode.length).replace(/^[-\s]+|[-,.\s]+$/g, '').trim();
    }
    return fullNumber.trim(); // If no matching prefix, assume it's already a local number or full number without standard prefix
  };

  const loadUser = useCallback(async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);

    // Extract local number parts for formData, preserving original logic
    const localPhone = extractLocalNumber(currentUser.phone, currentUser.country);
    const localWhatsapp = extractLocalNumber(currentUser.whatsapp, currentUser.country);

    setFormData({
      full_name: currentUser.full_name || "",
      phone: localPhone,
      whatsapp: localWhatsapp,
      bio: currentUser.bio || "",
      country: currentUser.country || "",
      currency: currentUser.currency || ""
    });

    const userRatings = await Rating.filter({ rated_user_id: currentUser.id }, "-created_date");
    setRatings(userRatings);

    if (currentUser.account_type === "vendor") { // Changed from "landlord"
      const userProperties = await Property.filter({ vendor_id: currentUser.id }); // Changed from landlord_id
      setProperties(userProperties);
    }

    if (currentUser.account_type === "tenant") {
      const requests = await VendorRequest.filter({ user_id: currentUser.id }); // Changed from LandlordRequest
      if (requests.length > 0) {
        setVendorRequest(requests[0]); // Changed from setLandlordRequest
      }
    }

    setLoading(false);
  }, [setUser, setFormData, setRatings, setProperties, setVendorRequest, setLoading]); // Updated dependency for setVendorRequest

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  const handleCountryChange = (country) => {
    const currencyData = getCurrencyForCountry(country);
    setFormData(prevFormData => ({
      ...prevFormData,
      country: country,
      currency: currencyData ? currencyData.code : "",
      // Optionally, clear phone/whatsapp if the old numbers are unlikely to be valid for the new country
      // phone: "",
      // whatsapp: ""
    }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);

    const dataToSave = { ...formData };
    const callingCode = formData.country ? getCallingCodeForCountry(formData.country) : "";

    // Combine calling code with local number parts if they exist
    if (formData.phone) {
      dataToSave.phone = `${callingCode}${formData.phone.replace(/[\s-]/g, '')}`; // Remove spaces and hyphens from local number
    } else {
      dataToSave.phone = "";
    }

    if (formData.whatsapp) {
      dataToSave.whatsapp = `${callingCode}${formData.whatsapp.replace(/[\s-]/g, '')}`; // Remove spaces and hyphens from local number
    } else {
      dataToSave.whatsapp = "";
    }

    // Use the dedicated method for updating user profile data
    await User.updateMyUserData(dataToSave);

    setSuccess(true);
    setIsEditing(false);
    setTimeout(() => setSuccess(false), 3000);
    setSaving(false);
    loadUser(); // Reload user data to reflect changes
  };

  const handleCancel = () => {
    // Revert formData to the current user's data, extracting local numbers
    const localPhone = extractLocalNumber(user.phone, user.country);
    const localWhatsapp = extractLocalNumber(user.whatsapp, user.country);

    setFormData({
      full_name: user.full_name || "",
      phone: localPhone,
      whatsapp: localWhatsapp,
      bio: user.bio || "",
      country: user.country || "",
      currency: user.currency || ""
    });
    setIsEditing(false);
  };

  const handleRequestVendor = () => { // Changed from handleRequestLandlord
    navigate(createPageUrl("BecomeVendor")); // Changed from BecomeLandlord
  };

  const handleExtendSubscription = () => {
    if (user.trial_used) {
      // Go to subscription page for paid extension
      navigate(createPageUrl("BecomeVendor?action=extend"));
    } else {
      // Can still use trial
      navigate(createPageUrl("BecomeVendor"));
    }
  };

  const handleRenewSubscription = () => {
    // Always go to subscription page for renewal
    navigate(createPageUrl("BecomeVendor?action=renew"));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const currentCallingCode = formData.country ? getCallingCodeForCountry(formData.country) : "";

  return (
    <div className="p-6 md:p-8 max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Profile</h1>
        <p className="text-slate-600">Manage your account information and settings</p>
      </div>

      {success && (
        <Alert className="mb-6 border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-900">
            Profile updated successfully!
          </AlertDescription>
        </Alert>
      )}

      {vendorRequest && ( // Changed from landlordRequest
        <Alert className={`mb-6 ${
          vendorRequest.status === 'pending' ? 'border-yellow-200 bg-yellow-50' :
          vendorRequest.status === 'approved' ? 'border-green-200 bg-green-50' :
          'border-red-200 bg-red-50'
        }`}>
          <AlertCircle className={`h-4 w-4 ${
            vendorRequest.status === 'pending' ? 'text-yellow-600' :
            vendorRequest.status === 'approved' ? 'text-green-600' :
            'text-red-600'
          }`} />
          <AlertDescription className={
            vendorRequest.status === 'pending' ? 'text-yellow-900' :
            vendorRequest.status === 'approved' ? 'text-green-900' :
            'text-red-900'
          }>
            {vendorRequest.status === 'pending' && 'Your vendor request is pending admin approval.'} {/* Changed text */}
            {vendorRequest.status === 'approved' && 'Your vendor request has been approved! You can now list properties and items.'} {/* Changed text */}
            {vendorRequest.status === 'rejected' && 'Your vendor request was rejected. Please contact support for more information.'} {/* Changed text */}
          </AlertDescription>
        </Alert>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Profile Summary Card */}
        <Card className="border-0 shadow-xl lg:col-span-1">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-5xl">
                  {user.full_name?.charAt(0).toUpperCase()}
                </span>
              </div>
              <h3 className="font-bold text-2xl text-slate-900 mb-1">{user.full_name}</h3>
              <p className="text-slate-600 text-sm mb-3">{user.email}</p>
              <Badge className="mb-4 text-sm px-4 py-1 capitalize">
                {user.account_type === "admin" ? "Super Admin" : user.account_type}
              </Badge>

              {/* Vendor Subscription Status */}
              {user.account_type === "vendor" && user.subscription_end_date && (
                <Card className={`mt-6 border-2 ${
                  (() => {
                    const now = new Date();
                    const endDate = new Date(user.subscription_end_date);
                    const diffTime = endDate.getTime() - now.getTime(); // Use getTime() for consistent diff
                    const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    if (daysLeft <= 0) return 'border-red-200 bg-red-50';
                    if (daysLeft <= 5) return 'border-yellow-200 bg-yellow-50';
                    return 'border-green-200 bg-green-50';
                  })()
                }`}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className={`w-5 h-5 ${
                        (() => {
                          const now = new Date();
                          const endDate = new Date(user.subscription_end_date);
                          const diffTime = endDate.getTime() - now.getTime();
                          const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                          
                          if (daysLeft <= 0) return 'text-red-600';
                          if (daysLeft <= 5) return 'text-yellow-600';
                          return 'text-green-600';
                        })()
                      }`} />
                      <span className="font-semibold text-sm text-slate-700">Subscription Status</span>
                    </div>
                    {(() => {
                      const now = new Date();
                      const endDate = new Date(user.subscription_end_date);
                      const diffTime = endDate.getTime() - now.getTime();
                      const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                      
                      return (
                        <>
                          <div className={`text-3xl font-bold mb-1 ${
                            daysLeft <= 0 ? 'text-red-600' :
                            daysLeft <= 5 ? 'text-yellow-600' :
                            'text-green-600'
                          }`}>
                            {daysLeft <= 0 ? 'Expired' : `${daysLeft} days`}
                          </div>
                          <p className="text-xs text-slate-600 mb-2">
                            {daysLeft <= 0 
                              ? `Expired ${Math.abs(daysLeft)} days ago`
                              : daysLeft === 1 
                                ? 'Expires tomorrow' 
                                : 'remaining'
                            }
                          </p>
                          <div className="text-xs text-slate-500 mb-3">
                            {daysLeft <= 0 ? 'Expired' : 'Expires'}: {format(endDate, "MMM d, yyyy")}
                          </div>
                          
                          {/* Action Buttons */}
                          <div className="flex gap-2">
                            {daysLeft <= 0 ? (
                              <Button 
                                size="sm" 
                                className="w-full bg-red-600 hover:bg-red-700"
                                onClick={handleRenewSubscription}
                              >
                                Renew Subscription
                              </Button>
                            ) : daysLeft <= 10 ? ( // Display both Extend and Renew if less than 10 days left
                              <>
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  className="flex-1"
                                  onClick={handleExtendSubscription}
                                >
                                  Extend
                                </Button>
                                <Button 
                                  size="sm" 
                                  className="flex-1 bg-yellow-600 hover:bg-yellow-700"
                                  onClick={handleRenewSubscription}
                                >
                                  Renew
                                </Button>
                              </>
                            ) : ( // Display only Extend if more than 10 days left
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="w-full"
                                onClick={handleExtendSubscription}
                              >
                                Extend Subscription
                              </Button>
                            )}
                          </div>
                        </>
                      );
                    })()}
                  </CardContent>
                </Card>
              )}

              {/* PROMINENT Become Vendor Button - Shows for ALL tenants without pending request */}
              {user.account_type === "tenant" && !vendorRequest && ( // Changed from landlordRequest
                <Button
                  onClick={handleRequestVendor} // Changed from handleRequestLandlord
                  className="w-full mt-6 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 gap-2 py-6 text-lg shadow-lg"
                >
                  <UserPlus className="w-5 h-5" />
                  Become a Vendor {/* Changed text */}
                </Button>
              )}
              
              {user.rating_average > 0 && (
                <div className="mt-6 p-4 bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Star className="w-6 h-6 text-yellow-500 fill-yellow-500" />
                    <span className="font-bold text-3xl text-slate-900">{user.rating_average.toFixed(1)}</span>
                  </div>
                  <p className="text-sm text-slate-600">{user.rating_count} reviews</p>
                </div>
              )}

              {user.account_type === "vendor" && ( // Changed from "landlord"
                <div className="mt-6 p-4 bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Building2 className="w-6 h-6 text-indigo-600" />
                    <span className="font-bold text-3xl text-slate-900">{properties.length}</span>
                  </div>
                  <p className="text-sm text-slate-600">Properties Listed</p> {/* Kept 'Properties Listed' as it corresponds to the 'Property' entity */}
                </div>
              )}
            </div>

            <Separator className="my-6" />

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <span className="text-slate-500 w-20">Status:</span>
                <Badge variant="default" className="bg-green-500">
                  Active
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="text-slate-500 w-20">Joined:</span>
                <span className="font-medium">{format(new Date(user.created_date), "MMM d, yyyy")}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information & Bio Card */}
        <Card className="border-0 shadow-xl lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl">Contact Information</CardTitle>
              {!isEditing ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditing(true)}
                  className="gap-2"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit Profile
                </Button>
              ) : (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCancel}
                  className="gap-2"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <form onSubmit={handleSave} className="space-y-6">
                <div>
                  <Label htmlFor="full_name">Full Name</Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                    placeholder="Your full name"
                    required
                    className="mt-2"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="country" className="flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Country
                    </Label>
                    <Select
                      value={formData.country}
                      onValueChange={handleCountryChange}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue placeholder="Select your country" />
                      </SelectTrigger>
                      <SelectContent className="max-h-60">
                        {countriesWithCurrency.map((item) => (
                          <SelectItem key={item.country} value={item.country}>
                            {item.country}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="currency" className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      Currency
                    </Label>
                    <Input
                      id="currency"
                      value={formData.currency ? `${getCurrencyForCountry(formData.country)?.currency || ""} (${formData.currency})` : ""}
                      disabled
                      className="mt-2 bg-slate-50"
                      placeholder="Select country first"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      Auto-filled based on country
                    </p>
                  </div>
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <div className="flex items-center mt-2">
                    {formData.country && (
                      <span className="p-2 border border-r-0 rounded-l-md bg-gray-100 text-gray-700 text-sm">
                        {currentCallingCode}
                      </span>
                    )}
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      placeholder="e.g., 555 123 4567"
                      className={`flex-grow ${formData.country ? 'rounded-l-none' : ''}`}
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {formData.country 
                      ? `Your local number, starting with ${currentCallingCode} for international calls.` 
                      : "Select your country first to see the calling code"}
                  </p>
                </div>

                <div>
                  <Label htmlFor="whatsapp">WhatsApp Number</Label>
                  <div className="flex items-center mt-2">
                    {formData.country && (
                      <span className="p-2 border border-r-0 rounded-l-md bg-gray-100 text-gray-700 text-sm">
                        {currentCallingCode}
                      </span>
                    )}
                    <Input
                      id="whatsapp"
                      type="tel"
                      value={formData.whatsapp}
                      onChange={(e) => setFormData({...formData, whatsapp: e.target.value})}
                      placeholder="e.g., 555 123 4567"
                      className={`flex-grow ${formData.country ? 'rounded-l-none' : ''}`}
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {formData.country 
                      ? `Your local number, tenants can contact you via WhatsApp.` 
                      : "Select your country first to see the calling code"}
                  </p>
                </div>

                <div>
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    value={formData.bio}
                    onChange={(e) => setFormData({...formData, bio: e.target.value})}
                    placeholder="Tell us about yourself..."
                    className="min-h-32 mt-2"
                  />
                  <p className="text-xs text-slate-500 mt-1">Share a bit about yourself</p>
                </div>

                <Button
                  type="submit"
                  disabled={saving}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 py-6 text-lg"
                >
                  {saving ? "Saving Changes..." : "Save Changes"}
                </Button>
              </form>
            ) : (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-slate-500 text-sm flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Country
                    </Label>
                    <p className="text-lg font-medium text-slate-900 mt-1">
                      {user.country || <span className="text-slate-400">Not provided</span>}
                    </p>
                  </div>

                  <div>
                    <Label className="text-slate-500 text-sm flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      Currency
                    </Label>
                    <p className="text-lg font-medium text-slate-900 mt-1">
                      {user.currency ? (
                        <span>
                          {getCurrencyForCountry(user.country)?.currency || "Unknown"} ({user.currency})
                        </span>
                      ) : (
                        <span className="text-slate-400">Not provided</span>
                      )}
                    </p>
                  </div>
                </div>

                <div>
                  <Label className="text-slate-500 text-sm">Phone Number</Label>
                  <p className="text-lg font-medium text-slate-900 mt-1">
                    {/* User.phone is expected to store the full international number */}
                    {user.phone || <span className="text-slate-400">Not provided</span>}
                  </p>
                </div>

                <div>
                  <Label className="text-slate-500 text-sm">WhatsApp Number</Label>
                  <p className="text-lg font-medium text-slate-900 mt-1">
                    {/* User.whatsapp is expected to store the full international number */}
                    {user.whatsapp || <span className="text-slate-400">Not provided</span>}
                  </p>
                </div>

                <div>
                  <Label className="text-slate-500 text-sm">Bio</Label>
                  <p className="text-slate-900 mt-2 whitespace-pre-wrap">
                    {user.bio || <span className="text-slate-400">No bio added yet</span>}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Reviews Card */}
        {ratings.length > 0 && (
          <Card className="border-0 shadow-xl lg:col-span-3">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-600" />
                Reviews ({ratings.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {ratings.map((rating) => (
                  <div key={rating.id} className="p-4 border rounded-xl bg-slate-50">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-semibold text-sm">
                            {rating.rater_name?.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <span className="font-semibold text-slate-900">{rating.rater_name}</span>
                      </div>
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < rating.rating
                                ? "text-yellow-500 fill-yellow-500"
                                : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    {rating.comment && (
                      <p className="text-sm text-slate-600 mb-2">{rating.comment}</p>
                    )}
                    <p className="text-xs text-slate-400">
                      {new Date(rating.created_date).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
