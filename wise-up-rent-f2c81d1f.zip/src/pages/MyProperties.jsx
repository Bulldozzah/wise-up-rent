
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Property } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Building2, Eye, MapPin, DollarSign, Bed, Plus, Edit, Trash2, Home, Shield } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function MyProperties() {
  const [user, setUser] = useState(null);
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(null);
  const [filterType, setFilterType] = useState("all");
  const [stats, setStats] = useState({
    total: 0,
    forRent: 0,
    forSale: 0,
    available: 0,
    rented: 0,
    sold: 0,
    totalViews: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const currentUser = await User.me();
    setUser(currentUser);

    // If admin, show all properties. If vendor, show only their properties
    let userProperties;
    if (currentUser.account_type === "admin") {
      userProperties = await Property.list("-created_date");
    } else {
      // FIXED: Use vendor_id instead of landlord_id
      userProperties = await Property.filter({ vendor_id: currentUser.id }, "-created_date");
    }
    
    setProperties(userProperties);

    setStats({
      total: userProperties.length,
      forRent: userProperties.filter(p => p.listing_type === "rent").length,
      forSale: userProperties.filter(p => p.listing_type === "sale").length,
      available: userProperties.filter(p => p.status === "available").length,
      rented: userProperties.filter(p => p.status === "rented").length,
      sold: userProperties.filter(p => p.status === "sold").length,
      totalViews: userProperties.reduce((sum, p) => sum + (p.views || 0), 0)
    });

    setLoading(false);
  };

  const handleDelete = async (propertyId) => {
    setDeleting(propertyId);
    await Property.delete(propertyId);
    await loadData();
    setDeleting(null);
  };

  const handleStatusChange = async (propertyId, newStatus) => {
    await Property.update(propertyId, { status: newStatus });
    await loadData();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  const isAdmin = user.account_type === "admin";
  const userCurrency = user?.currency || "TZS"; // Get user's preferred currency, default to TZS

  const filteredProperties = properties.filter(p => {
    if (filterType === "all") return true;
    return p.listing_type === filterType;
  });

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2 flex items-center gap-2">
            {isAdmin && <Shield className="w-8 h-8 text-indigo-600" />}
            {isAdmin ? "All Properties" : "My Properties"}
          </h1>
          <p className="text-slate-600">
            {isAdmin ? "View and manage all rental and sale listings on the platform" : "Manage your rental and sale listings"}
          </p>
        </div>
        {!isAdmin && (
          <Link to={createPageUrl("AddProperty")}>
            <Button className="bg-indigo-600 hover:bg-indigo-700 gap-2 shadow-lg">
              <Plus className="w-5 h-5" />
              Add New Property
            </Button>
          </Link>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 mb-6">
        <Button
          variant={filterType === "all" ? "default" : "outline"}
          onClick={() => setFilterType("all")}
          className={filterType === "all" ? "bg-indigo-600 hover:bg-indigo-700 text-white" : "text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"}
        >
          All ({stats.total})
        </Button>
        <Button
          variant={filterType === "rent" ? "default" : "outline"}
          onClick={() => setFilterType("rent")}
          className={filterType === "rent" ? "bg-indigo-600 hover:bg-indigo-700 text-white" : "text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"}
        >
          For Rent ({stats.forRent})
        </Button>
        <Button
          variant={filterType === "sale" ? "default" : "outline"}
          onClick={() => setFilterType("sale")}
          className={filterType === "sale" ? "bg-indigo-600 hover:bg-indigo-700 text-white" : "text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"}
        >
          For Sale ({stats.forSale})
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card className="border-0 shadow-xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-indigo-100 text-sm mb-1">Total Properties</p>
                <p className="text-4xl font-bold">{stats.total}</p>
              </div>
              <Building2 className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-green-100 text-sm mb-1">Available</p>
                <p className="text-4xl font-bold">{stats.available}</p>
              </div>
              <Home className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-blue-100 text-sm mb-1">Rented/Sold</p>
                <p className="text-4xl font-bold">{stats.rented + stats.sold}</p>
              </div>
              <Building2 className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-orange-100 text-sm mb-1">Total Views</p>
                <p className="text-4xl font-bold">{stats.totalViews}</p>
              </div>
              <Eye className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Properties List */}
      {filteredProperties.length === 0 ? (
        <Card className="border-0 shadow-xl">
          <CardContent className="text-center py-16">
            <Building2 className="w-20 h-20 mx-auto mb-4 text-slate-300" />
            <h3 className="text-2xl font-semibold text-slate-900 mb-2">No Properties Yet</h3>
            <p className="text-slate-600 mb-8">
              {isAdmin ? "No properties have been listed on the platform yet" : "Start earning by listing your first property"}
            </p>
            {!isAdmin && (
              <Link to={createPageUrl("AddProperty")}>
                <Button className="bg-indigo-600 hover:bg-indigo-700 gap-2 shadow-lg">
                  <Plus className="w-5 h-5" />
                  Add Your First Property
                </Button>
              </Link>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProperties.map((property) => (
            <Card key={property.id} className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
              <div className="relative h-52 bg-slate-200">
                {property.images && property.images.length > 0 ? (
                  <img
                    src={property.images[0]}
                    alt={property.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Building2 className="w-16 h-16 text-slate-400" />
                  </div>
                )}
                <div className="absolute top-3 left-3">
                  <Badge className={property.listing_type === "rent" ? "bg-indigo-600" : "bg-purple-600"}>
                    For {property.listing_type === "rent" ? "Rent" : "Sale"}
                  </Badge>
                </div>
                <div className="absolute top-3 right-3">
                  <Badge
                    className={`${
                      property.status === "available" ? "bg-green-500" :
                      property.status === "rented" ? "bg-blue-500" :
                      property.status === "sold" ? "bg-gray-500" : "bg-orange-500"
                    }`}
                  >
                    {property.status}
                  </Badge>
                </div>
              </div>
              
              <CardContent className="p-6">
                <h3 className="font-bold text-xl text-slate-900 mb-3 line-clamp-2 min-h-[3.5rem]">
                  {property.title}
                </h3>
                
                {isAdmin && (
                  <div className="mb-3 text-sm text-slate-600">
                    <span className="font-semibold">Vendor:</span> {property.vendor_name}
                  </div>
                )}
                
                <div className="flex items-center gap-2 text-slate-600 mb-4">
                  <MapPin className="w-4 h-4 flex-shrink-0" />
                  <span className="text-sm line-clamp-1">
                    {property.neighborhood && `${property.neighborhood}, `}
                    {property.city}
                  </span>
                </div>

                <div className="flex items-center gap-4 mb-4 text-sm text-slate-600">
                  <div className="flex items-center gap-1">
                    <Bed className="w-4 h-4" />
                    <span>{property.bedrooms} bed</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    <span>{property.views || 0} views</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t mb-4">
                  <div>
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-5 h-5 text-indigo-600" />
                      <span className="font-bold text-xl text-indigo-600">
                        {property.listing_type === "rent" 
                          ? property.rent_amount?.toLocaleString() 
                          : property.sale_price?.toLocaleString()
                        }
                      </span>
                    </div>
                    <span className="text-xs text-slate-500">
                      {userCurrency} {/* Display user's preferred currency */}
                      {property.listing_type === "rent" && ` / ${property.payment_frequency}`}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Link to={createPageUrl(`Property?id=${property.id}`)} className="flex-1">
                    <Button size="sm" variant="outline" className="w-full gap-2">
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                  </Link>
                  
                  <Link to={createPageUrl(`EditProperty?id=${property.id}`)}>
                    <Button size="sm" variant="outline" className="gap-2">
                      <Edit className="w-4 h-4" />
                    </Button>
                  </Link>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Property?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone. This will permanently delete the property listing.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDelete(property.id)}
                          className="bg-red-600 hover:bg-red-700"
                          disabled={deleting === property.id}
                        >
                          {deleting === property.id ? "Deleting..." : "Delete"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>

                {/* Status Change Buttons */}
                <div className="mt-3 flex gap-2">
                  {property.status !== "available" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1 text-green-600 hover:bg-green-50"
                      onClick={() => handleStatusChange(property.id, "available")}
                    >
                      Mark Available
                    </Button>
                  )}
                  {property.listing_type === "rent" && property.status !== "rented" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1 text-blue-600 hover:bg-blue-50"
                      onClick={() => handleStatusChange(property.id, "rented")}
                    >
                      Mark Rented
                    </Button>
                  )}
                  {property.listing_type === "sale" && property.status !== "sold" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1 text-gray-600 hover:bg-gray-50"
                      onClick={() => handleStatusChange(property.id, "sold")}
                    >
                      Mark Sold
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
