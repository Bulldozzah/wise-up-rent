
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Eye, Bed, Building2 } from "lucide-react";

export default function MyLodges() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      if (currentUser.account_type !== "vendor" && currentUser.account_type !== "admin") {
        navigate(createPageUrl("Dashboard"));
        return;
      }

      setLoading(false);
    } catch (error) {
      console.error("Error loading user:", error);
      navigate(createPageUrl("Home"));
    }
  };

  const { data: lodges = [], isLoading: lodgesLoading } = useQuery({
    queryKey: ['my-lodges', user?.id],
    queryFn: () => {
      if (user?.account_type === "admin") {
        return base44.entities.Lodge.list("-created_date");
      }
      return base44.entities.Lodge.filter({ owner_id: user.id }, "-created_date");
    },
    enabled: !!user
  });

  const deleteLodgeMutation = useMutation({
    mutationFn: (id) => base44.entities.Lodge.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-lodges'] });
      alert("Lodge deleted successfully!");
    }
  });

  const handleDelete = (lodgeId) => {
    if (confirm("Are you sure you want to delete this lodge? This will also delete all rooms.")) {
      deleteLodgeMutation.mutate(lodgeId);
    }
  };

  if (loading || lodgesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">My Lodges</h1>
          <p className="text-slate-600">Manage your hotel, motel, and lodge listings</p>
        </div>
        <Button
          onClick={() => navigate(createPageUrl("AddLodge"))}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Lodge
        </Button>
      </div>

      {lodges.length === 0 ? (
        <Card className="border-0 shadow-xl">
          <CardContent className="text-center py-16">
            <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-900 mb-2">No Lodges Yet</h3>
            <p className="text-slate-600 mb-6">Start by adding your first lodge or hotel</p>
            <Button
              onClick={() => navigate(createPageUrl("AddLodge"))}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Lodge
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {lodges.map((lodge) => (
            <Card key={lodge.id} className="border-0 shadow-xl overflow-hidden group transform hover:-translate-y-1 transition-transform duration-300">
              <div className="relative h-72 bg-slate-200">
                {lodge.images && lodge.images.length > 0 ? (
                  <img
                    src={lodge.images[0]}
                    alt={lodge.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Building2 className="w-16 h-16 text-slate-400" />
                  </div>
                )}
                
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>

                <Badge className={`absolute top-3 right-3 border border-white/20 ${
                  lodge.status === 'active' ? 'bg-green-500' :
                  lodge.status === 'inactive' ? 'bg-red-500' :
                  'bg-yellow-500'
                }`}>
                  {lodge.status}
                </Badge>
                
                {/* Content over the banner */}
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                  <h3 className="font-bold text-2xl drop-shadow-md mb-1 line-clamp-2">{lodge.name}</h3>
                  <p className="text-sm text-slate-200 drop-shadow-md mb-3 line-clamp-2">
                    {lodge.city}{lodge.state && `, ${lodge.state}`}
                  </p>
                  
                  {/* Buttons appear on hover */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 space-y-2">
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="flex-1 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(createPageUrl(`LodgeDetails?id=${lodge.id}`));
                        }}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      <Button
                        size="sm"
                        className="flex-1 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(createPageUrl(`ManageRooms?lodgeId=${lodge.id}`));
                        }}
                      >
                        <Bed className="w-4 h-4 mr-1" />
                        Rooms
                      </Button>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="flex-1 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(createPageUrl(`AddLodge?id=${lodge.id}`));
                        }}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        className="bg-red-500/80 hover:bg-red-500"
                        onClick={(e) => {
                          e.stopPropagation(); // Prevent card navigation
                          handleDelete(lodge.id);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
