
import React, { useState, useEffect, useCallback } from "react";
import { Listing } from "@/api/entities";
import { User } from "@/api/entities";
import { Rating } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription, AlertCircle } from "@/components/ui/alert";
import {
  MapPin,
  Star,
  Check,
  ChevronLeft,
  ChevronRight,
  ArrowLeft,
  Car,
  Music,
  Laptop,
  Shirt,
  Wrench,
  Camera,
  Package,
  Settings,
  DollarSign,
  Trash2,
  Phone,
  MessageSquare,
  Mail
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import ContactButtons from "../components/property/ContactButtons";
import RatingSection from "../components/property/RatingSection";
import ImageGallery from "../components/property/ImageGallery";

const categoryIcons = {
  transport_vehicles: Car,
  events_entertainment: Music,
  home_office_equipment: Laptop,
  personal_lifestyle: Shirt,
  construction_tools: Wrench,
  media_technology: Camera
};

const categoryLabels = {
  transport_vehicles: "Transport & Vehicles",
  events_entertainment: "Events & Entertainment",
  home_office_equipment: "Home & Office Equipment",
  personal_lifestyle: "Personal & Lifestyle",
  construction_tools: "Construction & Tools",
  media_technology: "Media & Technology"
};

export default function ListingDetailsPage() {
  const navigate = useNavigate();
  const [listing, setListing] = useState(null);
  const [owner, setOwner] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [ratings, setRatings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [ownerSubscriptionExpired, setOwnerSubscriptionExpired] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const listingId = urlParams.get("id");

      if (!listingId) {
        navigate(createPageUrl("BrowseItems"));
        return;
      }

      const listingData = await Listing.get(listingId);
      setListing(listingData);

      let ownerData = {
        id: listingData.owner_id,
        full_name: listingData.owner_name,
        email: listingData.owner_email,
        phone: listingData.owner_phone,
        whatsapp: listingData.owner_whatsapp,
        rating_average: 0,
        rating_count: 0
      };
      
      let isExpiredSubscription = false;
      
      try {
        const userData = await User.get(listingData.owner_id);
        
        if (userData.subscription_end_date) {
          isExpiredSubscription = new Date(userData.subscription_end_date) < new Date();
        }
        
        // Always update ownerData with the latest contact info from user profile, regardless of subscription status
        // The display logic will handle showing/hiding based on isExpiredSubscription and viewer's role.
        if (userData.email) ownerData.email = userData.email;
        if (userData.phone) ownerData.phone = userData.phone;
        if (userData.whatsapp) ownerData.whatsapp = userData.whatsapp;
        
      } catch (userError) {
        console.log("Could not fetch user data for contact info. Using listing data contact info as fallback.", userError);
      }
      
      setOwnerSubscriptionExpired(isExpiredSubscription);
      
      if (listingData.owner_id) {
        try {
          const ownerRatings = await Rating.filter({ rated_user_id: listingData.owner_id }, "-created_date");
          setRatings(ownerRatings);
          
          if (ownerRatings.length > 0) {
            const avgRating = ownerRatings.reduce((sum, r) => sum + r.rating, 0) / ownerRatings.length;
            ownerData.rating_average = avgRating;
            ownerData.rating_count = ownerRatings.length;
          }
        } catch (error) {
          console.error("Error loading ratings:", error);
        }
      }
      
      setOwner(ownerData);

      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        setCurrentUser(null);
      }

      setLoading(false);
    } catch (error) {
      console.error("Error loading listing:", error);
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const nextImage = () => {
    if (listing.images) {
      setCurrentImageIndex((prev) => (prev + 1) % listing.images.length);
    }
  };

  const prevImage = () => {
    if (listing.images) {
      setCurrentImageIndex((prev) => (prev - 1 + listing.images.length) % listing.images.length);
    }
  };

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this item? This action cannot be undone.")) {
      return;
    }

    setDeleting(true);
    try {
      await Listing.delete(listing.id);
      navigate(createPageUrl("MyListings"));
    } catch (error) {
      console.error("Error deleting listing:", error);
      alert("Error deleting item. Please try again.");
      setDeleting(false);
    }
  };

  const handleStatusChange = async (newStatus) => {
    if (!confirm(`Are you sure you want to mark this item as "${newStatus}"?`)) {
      return;
    }

    setUpdatingStatus(true);
    try {
      await Listing.update(listing.id, { status: newStatus });
      await loadData();
    } catch (error) {
      console.error("Error updating status:", error);
      alert("Error updating status. Please try again.");
    }
    setUpdatingStatus(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="border-0 shadow-xl">
          <CardContent className="pt-6 text-center">
            <Package className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-900 mb-2">Item not found</h3>
            <Button onClick={() => navigate(createPageUrl("BrowseItems"))} className="mt-4">
              Browse Items
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const userCurrency = currentUser?.currency || "ZMW";
  const CategoryIcon = categoryIcons[listing.category] || Package;
  const isOwner = currentUser && (currentUser.id === listing.owner_id || currentUser.account_type === "admin");
  
  // Check if contact info should be hidden (expired owner AND viewer is not the owner)
  const shouldHideContactInfo = ownerSubscriptionExpired && !isOwner;

  return (
    <div className="pb-12">
      {/* Image Gallery */}
      <div className="relative h-96 bg-slate-900">
        {listing.images && listing.images.length > 0 ? (
          <>
            <img
              src={listing.images[currentImageIndex]}
              alt={listing.title}
              className="w-full h-full object-cover opacity-90"
            />
            {listing.images.length > 1 && (
              <>
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                  onClick={prevImage}
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                  onClick={nextImage}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {listing.images.map((_, index) => (
                    <div
                      key={index}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentImageIndex ? "bg-white w-8" : "bg-white/50"
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
            <div className="absolute bottom-4 right-4">
              <ImageGallery images={listing.images} propertyTitle={listing.title} />
            </div>
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <CategoryIcon className="w-24 h-24 text-slate-400" />
          </div>
        )}

        <Button
          variant="outline"
          className="absolute top-4 left-4 bg-white/90 hover:bg-white"
          onClick={() => navigate(createPageUrl("BrowseItems"))}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Browse
        </Button>
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-0 shadow-2xl">
              <CardHeader>
                <div className="flex justify-between items-start flex-wrap gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <Badge className={listing.listing_type === "rent" ? "bg-indigo-600" : "bg-purple-600"}>
                        For {listing.listing_type === "rent" ? "Rent" : "Sale"}
                      </Badge>
                      <Badge className={`${
                        listing.status === "available" ? "bg-green-500" :
                        listing.status === "rented" ? "bg-blue-500" :
                        listing.status === "sold" ? "bg-gray-500" :
                        listing.status === "reserved" ? "bg-yellow-500" :
                        "bg-orange-500"
                      }`}>
                        {listing.status}
                      </Badge>
                      {listing.condition && (
                        <Badge variant="outline" className="capitalize">
                          {listing.condition.replace('_', ' ')}
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-3xl mb-2">{listing.title}</CardTitle>
                    <div className="flex items-center gap-2 text-slate-600 mb-2 flex-wrap">
                      <CategoryIcon className="w-5 h-5" />
                      <span>{categoryLabels[listing.category]}</span>
                      {listing.subcategory && <span className="text-slate-400">• {listing.subcategory}</span>}
                    </div>
                    {listing.city && (
                      <div className="flex items-center gap-2 text-slate-600">
                        <MapPin className="w-5 h-5" />
                        <span>{listing.city}{listing.district && `, ${listing.district}`}</span>
                      </div>
                    )}
                  </div>

                  {isOwner && (
                    <div className="flex flex-col gap-2">
                      <Select value={listing.status} onValueChange={handleStatusChange} disabled={updatingStatus}>
                        <SelectTrigger className="w-48">
                          <SelectValue placeholder="Update Status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="available">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-green-500" />
                              Available
                            </div>
                          </SelectItem>
                          <SelectItem value="rented">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-blue-500" />
                              Rented
                            </div>
                          </SelectItem>
                          <SelectItem value="sold">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-gray-500" />
                              Sold
                            </div>
                          </SelectItem>
                          <SelectItem value="reserved">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-yellow-500" />
                              Reserved
                            </div>
                          </SelectItem>
                          <SelectItem value="maintenance">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-orange-500" />
                              Maintenance
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>

                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-600 border-red-300 hover:bg-red-50"
                        onClick={handleDelete}
                        disabled={deleting}
                      >
                        {deleting ? (
                          <>
                            <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin mr-2" />
                            Deleting...
                          </>
                        ) : (
                          <>
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Item
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-6 h-6 text-indigo-600" />
                  <div>
                    <p className="text-3xl font-bold text-slate-900">
                      {userCurrency} {listing.listing_type === "rent"
                        ? listing.rent_amount?.toLocaleString()
                        : listing.sale_price?.toLocaleString()
                      }
                    </p>
                    <p className="text-slate-600">
                      {listing.listing_type === "rent" && `per ${listing.payment_frequency || 'rental period'}`}
                      {listing.listing_type === "sale" && "total price"}
                    </p>
                  </div>
                </div>

                {listing.listing_type === "rent" && listing.security_deposit && (
                  <div>
                    <p className="text-sm text-slate-600">Security Deposit</p>
                    <p className="text-xl font-semibold">{userCurrency} {listing.security_deposit.toLocaleString()}</p>
                  </div>
                )}

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-3">Description</h3>
                  <p className="text-slate-600 whitespace-pre-wrap">{listing.description}</p>
                </div>

                <Separator />

                <div>
                  <h3 className="font-semibold text-lg mb-4">Item Details</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {listing.brand && (
                      <div className="flex items-center gap-3">
                        <Package className="w-5 h-5 text-indigo-600" />
                        <span><strong>Brand:</strong> {listing.brand}</span>
                      </div>
                    )}
                    {listing.model && (
                      <div className="flex items-center gap-3">
                        <Settings className="w-5 h-5 text-indigo-600" />
                        <span><strong>Model:</strong> {listing.model}</span>
                      </div>
                    )}
                    {listing.year && (
                      <div className="flex items-center gap-3">
                        <span><strong>Year:</strong> {listing.year}</span>
                      </div>
                    )}
                    {listing.quantity_available && (
                      <div className="flex items-center gap-3">
                        <span><strong>Available:</strong> {listing.quantity_available} unit(s)</span>
                      </div>
                    )}
                  </div>
                </div>

                {listing.listing_type === "rent" && (
                  <>
                    <Separator />
                    <div>
                      <h3 className="font-semibold text-lg mb-4">Rental Terms</h3>
                      <div className="grid md:grid-cols-2 gap-3">
                        {listing.security_deposit && (
                          <div className="flex items-center gap-3">
                            <span><strong>{userCurrency} {listing.security_deposit.toLocaleString()}</strong> Security Deposit</span>
                          </div>
                        )}
                        {listing.minimum_rental_period && (
                          <div className="flex items-center gap-3">
                            <span><strong>Minimum:</strong> {listing.minimum_rental_period}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}

                {(listing.delivery_available || listing.setup_included || listing.operator_included) && (
                  <>
                    <Separator />
                    <div>
                      <h3 className="font-semibold text-lg mb-4">Additional Services</h3>
                      <div className="grid md:grid-cols-2 gap-3">
                        {listing.delivery_available && (
                          <div className="flex items-center gap-2">
                            <Check className="w-4 h-4 text-green-600" />
                            <span>Delivery/Transport Available</span>
                          </div>
                        )}
                        {listing.setup_included && (
                          <div className="flex items-center gap-2">
                            <Check className="w-4 h-4 text-green-600" />
                            <span>Setup/Installation Included</span>
                          </div>
                        )}
                        {listing.operator_included && (
                          <div className="flex items-center gap-2">
                            <Check className="w-4 h-4 text-green-600" />
                            <span>Operator/Driver Included</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}

                {listing.address && (
                  <>
                    <Separator />
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Location</h3>
                      <div className="flex items-start gap-2 text-slate-600">
                        <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0" />
                        <span>{listing.address}</span>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Owner Info & Contact */}
          <div className="space-y-6">
            {owner && owner.full_name ? (
              <Card className="border-0 shadow-2xl sticky top-6">
                <CardHeader className="bg-gradient-to-br from-purple-50 to-indigo-50">
                  <CardTitle className="flex items-center gap-2">
                    <Package className="w-5 h-5 text-purple-600" />
                    Item Owner
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 pt-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center shadow-lg">
                      <span className="text-white font-bold text-2xl">
                        {owner?.full_name?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-xl text-slate-900">{owner?.full_name}</p>
                      {owner?.rating_average > 0 && (
                        <div className="flex items-center gap-1 mt-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                          <span className="font-semibold">{owner.rating_average.toFixed(1)}</span>
                          <span className="text-sm text-slate-500">({owner.rating_count} reviews)</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator />

                  {shouldHideContactInfo ? (
                    <Alert className="border-red-200 bg-red-50">
                      <AlertCircle className="h-4 w-4 text-red-600" />
                      <AlertDescription className="text-red-900 text-sm">
                        This vendor's subscription has expired. Contact information is temporarily unavailable until they renew their subscription.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <>
                      {/* Contact Information Display */}
                      <div className="space-y-3 bg-slate-50 p-4 rounded-lg">
                        <h3 className="font-semibold text-slate-900 mb-3">Contact Information</h3>
                        
                        {owner.phone && (
                          <div className="flex items-center gap-2 text-slate-700">
                            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                              <Phone className="w-4 h-4 text-purple-600" />
                            </div>
                            <div>
                              <p className="text-xs text-slate-500">Phone</p>
                              <p className="font-medium">{owner.phone}</p>
                            </div>
                          </div>
                        )}

                        {owner.whatsapp && (
                          <div className="flex items-center gap-2 text-slate-700">
                            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                              <MessageSquare className="w-4 h-4 text-green-600" />
                            </div>
                            <div>
                              <p className="text-xs text-slate-500">WhatsApp</p>
                              <p className="font-medium">{owner.whatsapp}</p>
                            </div>
                          </div>
                        )}

                        {owner.email && (
                          <div className="flex items-center gap-2 text-slate-700">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <Mail className="w-4 h-4 text-blue-600" />
                            </div>
                            <div>
                              <p className="text-xs text-slate-500">Email</p>
                              <p className="font-medium text-sm break-all">{owner.email}</p>
                            </div>
                          </div>
                        )}
                        {!(owner.phone || owner.whatsapp || owner.email) && (
                          <p className="text-sm text-slate-500 text-center py-2">Owner has not provided contact information yet.</p>
                        )}
                      </div>

                      <Separator />

                      {/* Contact Buttons */}
                      <div>
                        <h3 className="font-semibold text-slate-900 mb-3">Get In Touch</h3>
                        <ContactButtons landlord={owner} property={listing} />
                      </div>
                    </>
                  )}

                  <Separator />

                  {/* Rating Section */}
                  <RatingSection
                    property={listing}
                    landlord={owner}
                    currentUser={currentUser}
                    ratings={ratings}
                    onRatingSubmitted={loadData}
                  />
                </CardContent>
              </Card>
            ) : (
              <Card className="border-0 shadow-2xl sticky top-6">
                <CardContent className="pt-6 text-center">
                  <p className="text-slate-500">Owner information not available</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
