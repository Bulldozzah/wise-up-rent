import { base44 } from './base44Client';


export const LandlordRequest = base44.entities.LandlordRequest;

export const Property = base44.entities.Property;

export const Rating = base44.entities.Rating;

export const Listing = base44.entities.Listing;

export const VendorRequest = base44.entities.VendorRequest;

export const Ad = base44.entities.Ad;

export const Feedback = base44.entities.Feedback;

export const Lodge = base44.entities.Lodge;

export const Room = base44.entities.Room;



// auth sdk:
export const User = base44.auth;